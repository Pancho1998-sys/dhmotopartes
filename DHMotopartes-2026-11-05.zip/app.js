/* ==========================================================================
   DHMotopartes - Core Logic & State Management
   ========================================================================== */

// App State Definition
const DEFAULT_STATE = {
    products: [],
    cart: [],
    sales: [],
    customers: [],
    suppliers: [],
    cashMovements: [],
    cashClosures: [],
    receptions: [],
    settings: {
        storeName: "Bigtech",
        storeAddress: "Av. Libertador 2450, Ciudad",
        storePhone: "+54 9 11 5555-1234",
        storeAlias: "DHMOTOPARTES",
        storeHolder: "DANIEL OSCAR HIDALGO",
        currency: "$",
        storeTax: 15,
        categories: ['Sistema Eléctrico', 'Repuestos de Motor', 'Frenos', 'Transmisión', 'Herramientas', 'Accesorios', 'Aceites'],
        geminiApiKey: "",
        logo: "",
        cardBgType: "default",
        cardBgColor: "#1f2937",
        cardBgColorHover: "#26354a",
        cardBgImage: ""
    }
};

let state = JSON.parse(JSON.stringify(DEFAULT_STATE));

// Dynamic Database Key helper
function getStorageKey() {
    return myStoreId ? `dhmotopartes_db_${myStoreId}` : 'dhmotopartes_db';
}

function resetStateToDefault() {
    state = JSON.parse(JSON.stringify(DEFAULT_STATE));
    // Clear temporary brand variables to prevent assets leaking between stores
    tempLogoBase64 = null;
    tempCardBgImageBase64 = null;
    tempProductImageBase64 = "";
    activeCatalogCategory = '';
    // Reset pagination counters
    inventoryPage = 1;
    customersPage = 1;
    suppliersPage = 1;
    historyPage = 1;
    cajaPage = 1;
}

function ensureStateProperties(loadedState) {
    if (!loadedState) return JSON.parse(JSON.stringify(DEFAULT_STATE));
    if (!loadedState.products) {
        loadedState.products = [];
    } else {
        loadedState.products.forEach(p => {
            if (p.priceWholesale === undefined) {
                p.priceWholesale = p.priceDiscount !== undefined ? p.priceDiscount : 0;
            }
            if (p.priceDiscount === undefined) {
                p.priceDiscount = p.priceWholesale;
            }
            if (p.isCombo === undefined) p.isCombo = false;
            if (!p.components) p.components = [];
            if (p.stockWholesale === undefined) p.stockWholesale = 0;
            if (p.stockMinWholesale === undefined) p.stockMinWholesale = 5;
        });
    }
    if (!loadedState.cart) loadedState.cart = [];
    if (!loadedState.sales) loadedState.sales = [];
    if (!loadedState.customers) {
        loadedState.customers = [];
    } else {
        loadedState.customers.forEach(c => {
            if (c.deuda === undefined) c.deuda = 0;
            if (c.hasCreditAccount === undefined) c.hasCreditAccount = true;
            if (c.creditLimit === undefined) c.creditLimit = 0;
            if (!c.ctaCteMovements) c.ctaCteMovements = [];
        });
    }
    if (!loadedState.suppliers) loadedState.suppliers = [];
    if (!loadedState.cashMovements) loadedState.cashMovements = [];
    if (!loadedState.cashClosures) loadedState.cashClosures = [];
    if (!loadedState.receptions) loadedState.receptions = [];
    if (!loadedState.settings) {
        loadedState.settings = JSON.parse(JSON.stringify(DEFAULT_STATE.settings));
    } else {
        const defaultSettings = DEFAULT_STATE.settings;
        for (let key in defaultSettings) {
            if (loadedState.settings[key] === undefined) {
                loadedState.settings[key] = defaultSettings[key];
            }
        }
    }
    if (loadedState.settings.geminiApiKey === undefined) {
        loadedState.settings.geminiApiKey = "";
    }
    if (!loadedState.settings.storeAlias) {
        loadedState.settings.storeAlias = "DHMOTOPARTES";
    }
    if (!loadedState.settings.storeHolder) {
        loadedState.settings.storeHolder = "DANIEL OSCAR HIDALGO";
    }
    // Ensure 'Aceites' is in the categories list
    if (loadedState.settings.categories && !loadedState.settings.categories.includes('Aceites')) {
        loadedState.settings.categories.push('Aceites');
    }
    return loadedState;
}

let supabaseSyncActive = false;
let isSyncing = false;

// Temporary branding variables
let tempLogoBase64 = null;
let tempCardBgImageBase64 = null;
let tempProductImageBase64 = "";
let activeCatalogCategory = '';
let activeSaasStoreSettings = null;

// Pagination state
let inventoryPage = 1;
const itemsPerPage = 8;
let customersPage = 1;
let suppliersPage = 1;
let historyPage = 1;
let cajaPage = 1;
let posPage = 1;
const posItemsPerPage = 16;

// Debounce utility for input event performance optimization
function debounce(func, delay = 200) {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func(...args), delay);
    };
}

// Dynamic loader for SheetJS (XLSX) to optimize initial page weight
let xlsxLoadingPromise = null;
function ensureXLSX() {
    if (window.XLSX) {
        return Promise.resolve(window.XLSX);
    }
    if (xlsxLoadingPromise) {
        return xlsxLoadingPromise;
    }
    xlsxLoadingPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'xlsx.full.min.js';
        script.onload = () => {
            console.log("SheetJS (XLSX) cargado dinámicamente con éxito.");
            resolve(window.XLSX);
        };
        script.onerror = (err) => {
            xlsxLoadingPromise = null; // permitir reintento
            console.error("Error al cargar SheetJS (XLSX) dinámicamente:", err);
            reject(new Error("No se pudo cargar el módulo de Excel. Por favor, reintente."));
        };
        document.head.appendChild(script);
    });
    return xlsxLoadingPromise;
}

// Barcode scanner buffer
let barcodeBuffer = '';
let lastKeyTime = 0;

/* ==========================================================================
   Initialization & Authentication
   ========================================================================== */
document.addEventListener('DOMContentLoaded', async () => {
    initFacturador();
    await setupAuthentication();
    initRouter();
    initDatetime();
    setupEventListeners();
    setupBarcodeListener();
    // setupCajeroRegistration();

    // Listen for custom hash changes
    window.addEventListener('hashchange', handleRoute);

    // Listen for recovery of internet connection
    window.addEventListener('online', async () => {
        console.log("Internet connection restored. Attempting to sync offline data...");
        if (myStoreId && localStorage.getItem('dhmotopartes_needs_sync_' + myStoreId) === 'true' && !isSyncing) {
            await saveDatabase();
        }
    });

    // Check periodically (every 30 seconds) if sync is needed and we are online
    setInterval(async () => {
        if (myStoreId && localStorage.getItem('dhmotopartes_needs_sync_' + myStoreId) === 'true' && !isSyncing) {
            const session = supabaseClient ? (await supabaseClient.auth.getSession()).data.session : null;
            if (supabaseInitialized && session && session.user) {
                console.log("Periodic sync check: Unsynced changes detected. Attempting sync...");
                await saveDatabase();
            }
        }
    }, 30000);
});

// Update connection status label on sidebar
function updateSidebarStatus(status, text) {
    const dot = document.getElementById('store-status-dot');
    const label = document.getElementById('store-status-text');
    if (dot) {
        if (status === 'online') {
            dot.className = "status-dot online pulse";
        } else if (status === 'pending') {
            dot.className = "status-dot pending pulse";
        } else {
            dot.className = "status-dot offline";
        }
    }
    if (label) {
        label.textContent = text;
    }
}

function setupSupabaseRealtime() {
    if (supabaseSyncActive || !myStoreId || !supabaseInitialized) return;
    
    supabaseClient.channel('public:store_states')
        .on(
            'postgres_changes',
            { event: 'UPDATE', schema: 'public', table: 'store_states', filter: `store_id=eq.${myStoreId}` },
            (payload) => {
                console.log("Realtime state update received from Supabase");
                if (localStorage.getItem('dhmotopartes_needs_sync_' + myStoreId) !== 'true') {
                    if (payload.new && payload.new.state) {
                        state = ensureStateProperties(payload.new.state);
                        syncSettingsInputs();
                        renderApp();
                    }
                } else {
                    console.log("Realtime update ignored: local changes are pending sync.");
                }
            }
        )
        .subscribe();

    supabaseSyncActive = true;
}

let currentUserRole = 'usuario';
let currentUserProfile = null;
let myStoreId = null;
let isExecutable = false;

// Setup Supabase Auth & Login UI flow
async function setupAuthentication() {
    const loginOverlay = document.getElementById('login-overlay');
    const loginForm = document.getElementById('login-form');
    const loginEmail = document.getElementById('login-email');
    const loginPassword = document.getElementById('login-password');
    const loginError = document.getElementById('login-error-message');
    const loginStatus = document.getElementById('login-status-notice');
    const loginBtnLocal = document.getElementById('login-btn-local');
    const btnLogout = document.getElementById('btn-logout');

    if (loginBtnLocal) {
        loginBtnLocal.onclick = () => {
            // Hide standard login form, show local role selection
            const loginForm = document.getElementById('login-form');
            const localLoginSection = document.getElementById('local-login-section');
            if (loginForm && localLoginSection) {
                loginForm.style.display = 'none';
                localLoginSection.style.display = 'block';
            }
        };
    }

    const localLoginConfirmBtn = document.getElementById('local-login-confirm-btn');
    if (localLoginConfirmBtn) {
        localLoginConfirmBtn.onclick = async () => {
            const roleSelect = document.getElementById('local-role-select');
            currentUserRole = roleSelect ? roleSelect.value : 'superadmin';
            
            // Set dummy user profile locally
            currentUserProfile = {
                first_name: "Usuario",
                last_name: "Local",
                dni: "",
                role: currentUserRole,
                store_id: null
            };
            myStoreId = null;

            if (loginOverlay) {
                loginOverlay.classList.remove('active');
                loginOverlay.style.display = 'none';
            }

            // Show/hide navigation tabs
            const allNavIds = ['nav-dashboard', 'nav-pos', 'nav-inventario', 'nav-clientes', 'nav-proveedores', 'nav-historial', 'nav-caja', 'nav-configuracion'];
            allNavIds.forEach(id => {
                const el = document.getElementById(id);
                if (el && el.parentElement) el.parentElement.style.display = 'block';
            });

            if (currentUserRole === 'cajero') {
                const navItemsToHide = ['nav-dashboard', 'nav-inventario', 'nav-clientes', 'nav-proveedores', 'nav-historial', 'nav-caja', 'nav-configuracion'];
                navItemsToHide.forEach(id => {
                    const el = document.getElementById(id);
                    if (el && el.parentElement) el.parentElement.style.display = 'none';
                });
                if (window.location.hash === '#dashboard' || window.location.hash === '') {
                    window.location.hash = '#pos';
                }
            } else {
                if (window.location.hash === '' || window.location.hash === '#pos') {
                    window.location.hash = '#dashboard';
                }
            }

            await loadDatabase();
            renderApp();
        };
    }

    const localLoginBackBtn = document.getElementById('local-login-back-btn');
    if (localLoginBackBtn) {
        localLoginBackBtn.onclick = () => {
            const loginForm = document.getElementById('login-form');
            const localLoginSection = document.getElementById('local-login-section');
            if (loginForm && localLoginSection) {
                loginForm.style.display = 'block';
                localLoginSection.style.display = 'none';
            }
        };
    }

    // Detectar si estamos en el ejecutable compilado (.exe)
    try {
        if (window.location.protocol !== 'file:') {
            const res = await fetch('/api/info');
            if (res.ok) {
                const data = await res.json();
                isExecutable = !!data.frozen;
            }
        }
    } catch (e) {
        console.warn("No se pudo conectar al servidor de control de entorno. Asumiendo desarrollo.", e);
    }

    // Set up logout button click listener
    if (btnLogout) {
        btnLogout.addEventListener('click', async () => {
            if (supabaseInitialized && supabaseClient) {
                resetStateToDefault();
                await supabaseClient.auth.signOut();
                playScanSound('warning');
            } else {
                alert("Sesión local finalizada.");
                window.location.reload();
            }
        });
    }

    if (!supabaseInitialized) {
        // Supabase is not configured yet.
        if (loginOverlay) {
            loginOverlay.classList.add('active');
            loginOverlay.style.display = 'flex';
        }
        
        if (isExecutable) {
            if (loginStatus) {
                loginStatus.innerHTML = `⚠️ <strong>Acceso denegado: Base de datos no configurada.</strong><br>Contacte al administrador del sistema para configurar Supabase.`;
            }
            if (loginBtnLocal) {
                loginBtnLocal.style.display = 'none';
            }
        } else {
            if (loginStatus) {
                loginStatus.innerHTML = `⚠️ <strong>Base de datos en la nube no configurada.</strong><br>Completa las credenciales en <code>supabase-config.js</code> para conectar el sistema a internet.`;
            }
            if (loginBtnLocal) {
                loginBtnLocal.style.display = 'block';
            }
        }
        // Disable submit button since there is no Supabase to authenticate against
        const btnSubmit = document.getElementById('login-btn-submit');
        if (btnSubmit) btnSubmit.disabled = true;
        return;
    }

    // Supabase is configured!
    if (loginOverlay) {
        loginOverlay.classList.add('active');
        loginOverlay.style.display = 'flex';
    }
    if (loginStatus) {
        loginStatus.textContent = "Ingresa tus credenciales para acceder a la base de datos remota.";
    }

    // Mostrar siempre el botón de modo local para permitir trabajo sin conexión
    if (loginBtnLocal) {
        loginBtnLocal.style.display = 'block';
    }

    supabaseClient.auth.onAuthStateChange(async (event, session) => {
        if (session && session.user) {
            const user = session.user;
            console.log("Usuario autenticado en Supabase:", user.email);
            try {
                // Fetch profile and check role
                let { data: profile, error } = await supabaseClient
                    .from('user_profiles')
                    .select('first_name, last_name, dni, role, store_id, stores (name)')
                    .eq('id', user.id)
                    .single();
 
                if (error || !profile) {
                    console.error("Error al obtener perfil, reintentando...", error);
                    // Check if we are offline or if it is a fetch connection error
                    const isOfflineError = !window.navigator.onLine || error?.message?.includes('Fetch') || error?.code === 'PGRST102' || error?.status === 0;
                    if (isOfflineError) {
                        const cached = localStorage.getItem('dhmotopartes_cached_profile');
                        if (cached) {
                            try {
                                profile = JSON.parse(cached);
                                console.log("Modo offline: Usando perfil de usuario cacheado.");
                            } catch (e) {
                                console.error("Error parsing cached profile:", e);
                            }
                        }
                    }
                    
                    if (!profile) {
                        await new Promise(r => setTimeout(r, 800));
                        const { data: retryProfile } = await supabaseClient
                            .from('user_profiles')
                            .select('first_name, last_name, dni, role, store_id, stores (name)')
                            .eq('id', user.id)
                            .single();
                        if (!retryProfile) {
                            // Check cache one more time
                            const cached = localStorage.getItem('dhmotopartes_cached_profile');
                            if (cached) {
                                try {
                                    profile = JSON.parse(cached);
                                    console.log("Modo offline (reintento): Usando perfil de usuario cacheado.");
                                } catch (e) {
                                    console.error("Error parsing cached profile:", e);
                                }
                            }
                            
                            if (!profile) {
                                alert("Error al cargar perfil de usuario en la base de datos.");
                                await supabaseClient.auth.signOut();
                                return;
                            }
                        } else {
                            profile = retryProfile;
                        }
                    }
                }

                // Cache profile if successfully retrieved or read
                if (profile) {
                    localStorage.setItem('dhmotopartes_cached_profile', JSON.stringify(profile));
                }

                // Authorize
                if (profile.role !== 'admin' && profile.role !== 'superadmin' && profile.role !== 'saas_admin' && profile.role !== 'cajero') {
                    alert("Acceso denegado: Este panel es exclusivo para Cajeros, Administradores, Superadministradores o SaaS Admin.");
                    await supabaseClient.auth.signOut();
                    return;
                }

                if (profile.role !== 'saas_admin' && !profile.store_id) {
                    alert("Error: Tu cuenta no está vinculada a ninguna tienda (store_id nulo). Contacta al administrador.");
                    await supabaseClient.auth.signOut();
                    return;
                }

                currentUserRole = profile.role;
                currentUserProfile = profile;
                myStoreId = profile.store_id;

                const initials = ((profile.first_name || '')[0] || '') + ((profile.last_name || '')[0] || '');
                const emailInitials = initials.toUpperCase() || user.email.slice(0, 2).toUpperCase();

                const avatarEl = document.getElementById('user-avatar');
                const nameEl = document.getElementById('user-name-display');

                if (avatarEl) avatarEl.textContent = emailInitials;
                if (nameEl) nameEl.textContent = `${profile.first_name || ''} ${profile.last_name || ''}`.trim() || user.email.split('@')[0];
                if (btnLogout) btnLogout.style.display = 'inline-flex';

                if (loginOverlay) {
                    loginOverlay.classList.remove('active');
                    loginOverlay.style.display = 'none';
                }

                // Reset all navigation display to block first
                const allNavIds = ['nav-dashboard', 'nav-pos', 'nav-inventario', 'nav-clientes', 'nav-proveedores', 'nav-historial', 'nav-caja', 'nav-configuracion'];
                allNavIds.forEach(id => {
                    const el = document.getElementById(id);
                    if (el && el.parentElement) el.parentElement.style.display = 'block';
                });

                // Show/Hide panels based on role
                if (currentUserRole === 'cajero') {
                    const navItemsToHide = ['nav-dashboard', 'nav-inventario', 'nav-clientes', 'nav-proveedores', 'nav-historial', 'nav-caja', 'nav-configuracion'];
                    navItemsToHide.forEach(id => {
                        const el = document.getElementById(id);
                        if (el && el.parentElement) el.parentElement.style.display = 'none';
                    });
                    if (window.location.hash === '#dashboard' || window.location.hash === '') {
                        window.location.hash = '#pos';
                    }
                } else if (currentUserRole === 'saas_admin') {
                    const navItemsToHide = ['nav-pos', 'nav-inventario', 'nav-clientes', 'nav-proveedores', 'nav-caja', 'nav-configuracion'];
                    navItemsToHide.forEach(id => {
                        const el = document.getElementById(id);
                        if (el && el.parentElement) el.parentElement.style.display = 'none';
                    });
                    const targetView = window.location.hash.replace('#', '');
                    const forbiddenViewsForSaaSAdmin = ['pos', 'inventario', 'clientes', 'proveedores', 'caja', 'configuracion'];
                    if (window.location.hash === '' || forbiddenViewsForSaaSAdmin.includes(targetView)) {
                        window.location.hash = '#dashboard';
                    }
                }

                // Show/Hide SaaS panel link if global admin
                const navSaas = document.getElementById('nav-item-saas');
                if (navSaas) {
                    if (currentUserRole === 'saas_admin') {
                        navSaas.style.display = 'block';
                        loadSaasStores();
                    } else {
                        navSaas.style.display = 'none';
                    }
                }

                // Show/Hide cashier management if superadmin
                const cajerosPanel = document.getElementById('superadmin-cajeros-panel');
                if (cajerosPanel) {
                    if (currentUserRole === 'superadmin') {
                        cajerosPanel.style.display = 'block';
                        renderCajerosList();
                    } else {
                        cajerosPanel.style.display = 'none';
                    }
                }

                // Load DB from Supabase (Skip loading store DB if saas_admin)
                if (currentUserRole !== 'saas_admin') {
                    await loadDatabase();
                } else {
                    applyBrandSettings();
                }


            } catch (err) {
                console.error("Auth state processing failed:", err);
            }
        } else {
            console.log("Usuario desautenticado.");
            currentUserRole = 'usuario';
            currentUserProfile = null;
            myStoreId = null;
            resetStateToDefault();
            renderApp();

            if (loginOverlay) {
                loginOverlay.classList.add('active');
                loginOverlay.style.display = 'flex';
            }
            if (btnLogout) btnLogout.style.display = 'none';

            // Clean active sync state if logging out
            supabaseSyncActive = false;
            // Clear realtime channel
            try {
                supabaseClient.channel('public:store_states').unsubscribe();
            } catch (e) { }
        }
    });

    // Handle login form submit
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = loginEmail.value.trim();
            const password = loginPassword.value;

            if (loginError) loginError.style.display = 'none';
            const btnSubmit = document.getElementById('login-btn-submit');
            if (btnSubmit) {
                btnSubmit.disabled = true;
                btnSubmit.innerHTML = `<i data-lucide="loader" class="animate-spin" style="animation: spin 1s linear infinite;"></i> Cargando...`;
                if (window.lucide) lucide.createIcons();
            }

            try {
                const { data, error } = await supabaseClient.auth.signInWithPassword({
                    email,
                    password
                });

                if (error) throw error;
                playScanSound('success');
            } catch (error) {
                console.error("Error al iniciar sesión:", error);
                playScanSound('fail');
                if (loginError) {
                    loginError.style.display = 'block';
                    loginError.textContent = "Error: " + getFriendlyAuthErrorMessage(error);
                }
            } finally {
                if (btnSubmit) {
                    btnSubmit.disabled = false;
                    btnSubmit.innerHTML = `<i data-lucide="log-in"></i> Acceder al Sistema`;
                    if (window.lucide) lucide.createIcons();
                }
            }
        });
    }
}

function getFriendlyAuthErrorMessage(error) {
    if (!error) return 'Error desconocido.';
    const message = error.message.toLowerCase();
    if (message.includes('failed to fetch') || message.includes('networkerror') || message.includes('enotfound')) {
        return 'No se pudo conectar con la base de datos en la nube (el proyecto de Supabase puede estar pausado o sin internet). Haz clic en el botón "Trabajar sin Conexión (Modo Local)" que ves debajo para ingresar.';
    }
    if (message.includes('invalid login credentials') || message.includes('invalid credentials')) {
        return 'Correo o contraseña incorrectos.';
    }
    if (message.includes('email not confirmed')) {
        return 'El correo electrónico no ha sido verificado.';
    }
    return error.message;
}

// Sync settings inputs with state settings
function syncSettingsInputs() {
    if (state.settings) {
        const nameEl = document.getElementById('set-store-name');
        const addrEl = document.getElementById('set-store-address');
        const phoneEl = document.getElementById('set-store-phone');
        const whatsappEl = document.getElementById('set-store-whatsapp');
        const instagramEl = document.getElementById('set-store-instagram');
        const descEl = document.getElementById('set-store-description');
        const currEl = document.getElementById('set-store-currency');
        const taxEl = document.getElementById('set-store-tax');

        if (nameEl) nameEl.value = state.settings.storeName || "";
        if (addrEl) addrEl.value = state.settings.storeAddress || "";
        if (phoneEl) phoneEl.value = state.settings.storePhone || "";
        if (whatsappEl) whatsappEl.value = state.settings.whatsapp || "";
        if (instagramEl) instagramEl.value = state.settings.instagram || "";
        if (descEl) descEl.value = state.settings.brandDescription || "";
        if (currEl) currEl.value = state.settings.currency || "";
        if (taxEl) taxEl.value = state.settings.storeTax || 0;
        const geminiKeyEl = document.getElementById('set-gemini-api-key');
        if (geminiKeyEl) geminiKeyEl.value = state.settings.geminiApiKey || "";

        // Brand & Design Sync
        const cardBgType = state.settings.cardBgType || "default";
        const cardBgColor = state.settings.cardBgColor || "#1f2937";
        const cardBgColorHover = state.settings.cardBgColorHover || "#26354a";
        const logo = state.settings.logo || "";
        const cardBgImage = state.settings.cardBgImage || "";

        tempLogoBase64 = logo;
        tempCardBgImageBase64 = cardBgImage;

        const cardBgTypeSelect = document.getElementById('set-card-bg-type');
        const cardBgColorInput = document.getElementById('set-card-bg-color');
        const cardBgColorHoverInput = document.getElementById('set-card-bg-hover');

        if (cardBgTypeSelect) cardBgTypeSelect.value = cardBgType;
        if (cardBgColorInput) cardBgColorInput.value = cardBgColor;
        if (cardBgColorHoverInput) cardBgColorHoverInput.value = cardBgColorHover;

        // Toggle groups visibility
        const colorGroup = document.getElementById('card-bg-color-group');
        const imageGroup = document.getElementById('card-bg-image-group');
        if (colorGroup) colorGroup.style.display = (cardBgType === 'color') ? 'block' : 'none';
        if (imageGroup) imageGroup.style.display = (cardBgType === 'image') ? 'block' : 'none';

        // Logo uploader UI sync
        const logoDropzone = document.getElementById('brand-logo-dropzone');
        const logoPreviewContainer = document.getElementById('brand-logo-preview-container');
        const logoPreviewImg = document.getElementById('brand-logo-preview-img');

        if (logo) {
            if (logoPreviewImg) logoPreviewImg.src = logo;
            if (logoPreviewContainer) logoPreviewContainer.style.display = 'flex';
            if (logoDropzone) logoDropzone.style.display = 'none';
        } else {
            if (logoPreviewContainer) logoPreviewContainer.style.display = 'none';
            if (logoDropzone) logoDropzone.style.display = 'block';
        }

        // Card BG uploader UI sync
        const cardBgDropzone = document.getElementById('card-bg-dropzone');
        const cardBgPreviewContainer = document.getElementById('card-bg-preview-container');
        const cardBgPreviewImg = document.getElementById('card-bg-preview-img');

        if (cardBgImage) {
            if (cardBgPreviewImg) cardBgPreviewImg.src = cardBgImage;
            if (cardBgPreviewContainer) cardBgPreviewContainer.style.display = 'flex';
            if (cardBgDropzone) cardBgDropzone.style.display = 'none';
        } else {
            if (cardBgPreviewContainer) cardBgPreviewContainer.style.display = 'none';
            if (cardBgDropzone) cardBgDropzone.style.display = 'block';
        }

        // Render categories UI in settings
        renderCategorySettings();
        applyBrandSettings();
    }
}

// Sync fiscal settings inputs with loaded fiscal config
async function syncFiscalSettingsInputs() {
    try {
        const config = await loadFiscalConfig();
        const cuitEl = document.getElementById('set-fiscal-cuit');
        const posEl = document.getElementById('set-fiscal-pos');
        const ivaEl = document.getElementById('set-fiscal-iva');
        const envEl = document.getElementById('set-fiscal-env');
        const certEl = document.getElementById('set-fiscal-cert');
        const keyEl = document.getElementById('set-fiscal-key');

        if (config) {
            if (cuitEl) cuitEl.value = config.cuit || "";
            if (posEl) posEl.value = config.pos_number || 1;
            if (ivaEl) ivaEl.value = config.iva_condition || "";
            if (envEl) envEl.value = config.environment || "homologacion";
            if (certEl) certEl.value = config.certificate_text || "";
            if (keyEl) keyEl.value = config.private_key_text || "";

            // Mostrar advertencia si el certificado expira pronto (< 30 días)
            const warningId = 'fiscal-cert-warning';
            let warningEl = document.getElementById(warningId);
            if (config.cert_expires_at) {
                const expDate = new Date(config.cert_expires_at);
                const daysLeft = Math.ceil((expDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
                
                if (daysLeft <= 30) {
                    if (!warningEl) {
                        warningEl = document.createElement('div');
                        warningEl.id = warningId;
                        warningEl.className = 'alert alert-warning';
                        warningEl.style.cssText = 'background: rgba(245, 158, 11, 0.15); border: 1px solid #f59e0b; padding: 10px; border-radius: 6px; color: #f59e0b; margin-bottom: 15px; font-size: 13px; display: flex; align-items: center; gap: 8px;';
                        const form = document.getElementById('settings-fiscal-form');
                        if (form) form.insertBefore(warningEl, form.firstChild);
                    }
                    warningEl.innerHTML = `⚠️ <span>El certificado digital expira en <strong>${daysLeft} días</strong> (el ${expDate.toLocaleDateString()}). Renuévelo pronto para evitar interrupción del servicio.</span>`;
                    warningEl.style.display = 'flex';
                } else {
                    if (warningEl) warningEl.style.display = 'none';
                }
            } else {
                if (warningEl) warningEl.style.display = 'none';
            }
        } else {
            if (cuitEl) cuitEl.value = "";
            if (posEl) posEl.value = 1;
            if (ivaEl) ivaEl.value = "";
            if (envEl) envEl.value = "homologacion";
            if (certEl) certEl.value = "";
            if (keyEl) keyEl.value = "";
            const warningEl = document.getElementById('fiscal-cert-warning');
            if (warningEl) warningEl.style.display = 'none';
        }
    } catch (e) {
        console.error("Error al sincronizar inputs fiscales:", e);
    }
}

// Load DB from Supabase or fallback to LocalStorage/Demo Data
// Load DB from Supabase or fallback to LocalStorage/Demo Data
async function loadDatabase() {
    if (supabaseSyncActive && myStoreId) {
        console.log("Database already loaded and synced with Supabase. Skipping reload.");
        return;
    }
    resetStateToDefault(); // Clean local memory first to prevent leakage
    const session = supabaseClient ? (await supabaseClient.auth.getSession()).data.session : null;
    
    // Check if we have unsynced local data that must be pushed first
    const needsSync = myStoreId && localStorage.getItem('dhmotopartes_needs_sync_' + myStoreId) === 'true';
    
    if (needsSync) {
        console.log("Unsynced local changes detected. Loading from LocalStorage first to prevent data loss.");
        const localData = localStorage.getItem(getStorageKey());
        if (localData) {
            try {
                state = ensureStateProperties(JSON.parse(localData));
                syncSettingsInputs();
                renderApp();
                
                // If we are online, attempt to sync now
                if (supabaseInitialized && session && session.user) {
                    updateSidebarStatus('pending', "Sincronizando...");
                    await saveDatabase();
                } else {
                    updateSidebarStatus('pending', "Modo Offline (Pendiente)");
                }
                
                // Set up subscription after successful sync
                if (localStorage.getItem('dhmotopartes_needs_sync_' + myStoreId) !== 'true') {
                    setupSupabaseRealtime();
                }
                return;
            } catch (e) {
                console.error("Error parsing local database during offline recovery:", e);
            }
        }
    }

    if (supabaseInitialized && session && session.user) {
        try {
            if (!supabaseSyncActive && myStoreId) {
                // Load current global state
                const { data, error } = await supabaseClient
                    .from('store_states')
                    .select('state')
                    .eq('store_id', myStoreId)
                    .single();

                if (error) {
                    console.error("Error loading state from Supabase:", error);
                    if (error.code === 'PGRST116') {
                        // Store state row doesn't exist yet, we will create it when saving
                        console.log("No existe estado previo para esta tienda. Iniciando vacío.");
                        state.products = [];
                        state.sales = [];
                        state.customers = [];
                        state.cashMovements = [];
                        state.suppliers = [];
                        if (currentUserProfile && currentUserProfile.stores && currentUserProfile.stores.name) {
                            state.settings.storeName = currentUserProfile.stores.name;
                        }
                        syncSettingsInputs();
                        renderApp();
                    }
                } else if (data && data.state) {
                    state = ensureStateProperties(data.state);
                    if (currentUserProfile && currentUserProfile.stores && currentUserProfile.stores.name) {
                        if (!state.settings.storeName || state.settings.storeName === "Bigtech") {
                            state.settings.storeName = currentUserProfile.stores.name;
                        }
                    }
                    syncSettingsInputs();
                    renderApp();
                }

                setupSupabaseRealtime();
            }
            updateSidebarStatus('online', "Conectado Nube");
            return;
        } catch (e) {
            console.error("Error setting up Supabase sync:", e);
        }
    }

    // Public Guest Visitor Mode (Unauthenticated Web Catalog)
    if (supabaseInitialized && (!session || !session.user)) {
        try {
            const publicStoreId = '3cd7c0ff-735b-430f-8da6-c538e4d5ed77';
            const { data, error } = await supabaseClient.rpc('get_public_catalog', { target_store_id: publicStoreId });
            if (!error && data) {
                if (data.products && data.products.length > 0) {
                    state.products = data.products;
                }
                if (data.categories && data.categories.length > 0) {
                    state.settings.categories = data.categories;
                }
                console.log("Catálogo público de DHMotopartes cargado desde la nube con éxito.");
                syncSettingsInputs();
                syncFiscalSettingsInputs();
                return;
            }
        } catch (pubErr) {
            console.warn("No se pudo cargar el catálogo público remoto:", pubErr);
        }
    }

    updateSidebarStatus('offline', "Modo Local");
    let loadedLocal = false;
    
    // First try to fetch from local Python server API (/api/db)
    try {
        const response = await fetch('/api/db', {
            method: 'GET',
            headers: { 'Cache-Control': 'no-cache' }
        });
        if (response.ok) {
            const serverDb = await response.json();
            if (serverDb && (serverDb.products || serverDb.sales)) {
                state = ensureStateProperties(serverDb);
                localStorage.setItem(getStorageKey(), JSON.stringify(state));
                console.log("Base de datos cargada con éxito desde el servidor local API (/api/db)");
                loadedLocal = true;
            }
        }
    } catch (err) {
        console.warn("Servidor local API no disponible. Usando LocalStorage:", err);
    }

    if (!loadedLocal) {
        const localData = localStorage.getItem(getStorageKey());
        if (localData) {
            try {
                state = ensureStateProperties(JSON.parse(localData));
            } catch (e) {
                console.error("Error al procesar base de datos local. Usando datos vacíos.", e);
                state = ensureStateProperties(null);
                if (!myStoreId) {
                    loadDemoData();
                }
            }
        } else {
            state = ensureStateProperties(null);
            if (!myStoreId) {
                loadDemoData();
            }
        }
    }
    syncSettingsInputs();
    syncFiscalSettingsInputs();
}

// Save DB state to LocalStorage and background push to Supabase
async function saveDatabase(retryCount = 0) {
    if (currentUserRole === 'saas_admin') return;
    if (retryCount > 3) {
        console.error("Demasiadas colisiones de red, abortando guardado.");
        isSyncing = false;
        return;
    }

    // Save to LocalStorage immediately to guarantee no data loss
    localStorage.setItem(getStorageKey(), JSON.stringify(state));

    const session = supabaseClient ? (await supabaseClient.auth.getSession()).data.session : null;
    if (supabaseInitialized && session && session.user && myStoreId) {
        isSyncing = true;
        try {
            let oldVersion = state.version || 0;
            state.version = oldVersion + 1;

            if (oldVersion === 0) {
                // Primera vez que se guarda (creacion)
                const { error } = await supabaseClient
                    .from('store_states')
                    .upsert({ store_id: myStoreId, state: state, updated_at: new Date().toISOString() });
                if (error) throw error;
            } else {
                // Actualización con Bloqueo Optimista (Optimistic Locking)
                const { data, error } = await supabaseClient
                    .from('store_states')
                    .update({ state: state, updated_at: new Date().toISOString() })
                    .eq('store_id', myStoreId)
                    .eq('state->>version', oldVersion.toString())
                    .select();

                if (error) throw error;

                if (!data || data.length === 0) {
                    // COLISION DETECTADA: Otra computadora guardó antes.
                    console.warn("Colisión detectada. Fusionando datos automáticamente...");
                    state.version = oldVersion; // Revertir versión local

                    // 1. Obtener estado más reciente de la nube
                    const dbRes = await supabaseClient.from('store_states').select('state').eq('store_id', myStoreId).single();
                    if (dbRes.error) throw dbRes.error;
                    let dbState = ensureStateProperties(dbRes.data.state);

                    // 2. Fusionar los datos locales nuevos en el dbState
                    const dbSaleIds = new Set((dbState.sales || []).map(s => s.id));
                    const newLocalSales = (state.sales || []).filter(s => !dbSaleIds.has(s.id));
                    
                    const dbCashIds = new Set((dbState.cashMovements || []).map(m => m.id));
                    const newLocalCash = (state.cashMovements || []).filter(m => !dbCashIds.has(m.id));

                    const dbCustIds = new Set((dbState.customers || []).map(c => c.id));
                    const newLocalCust = (state.customers || []).filter(c => !dbCustIds.has(c.id));

                    const dbSuppIds = new Set((dbState.suppliers || []).map(s => s.id));
                    const newLocalSupp = (state.suppliers || []).filter(s => !dbSuppIds.has(s.id));

                    const dbProdIds = new Set((dbState.products || []).map(p => p.id));
                    const newLocalProducts = (state.products || []).filter(p => !dbProdIds.has(p.id));

                    // Clonamos dbState para que sea nuestro nuevo state base
                    let mergedState = JSON.parse(JSON.stringify(dbState));
                    if (!mergedState.sales) mergedState.sales = [];
                    if (!mergedState.cashMovements) mergedState.cashMovements = [];
                    if (!mergedState.customers) mergedState.customers = [];
                    if (!mergedState.suppliers) mergedState.suppliers = [];
                    if (!mergedState.products) mergedState.products = [];

                    // Añadimos lo nuestro
                    mergedState.sales.push(...newLocalSales);
                    mergedState.cashMovements.push(...newLocalCash);
                    mergedState.customers.push(...newLocalCust);
                    mergedState.suppliers.push(...newLocalSupp);
                    mergedState.products.push(...newLocalProducts);

                    // Ajustamos el stock en base a nuestras ventas nuevas que no estaban en la BD
                    for (let sale of newLocalSales) {
                        if(sale.items) {
                            for (let item of sale.items) {
                                let prod = mergedState.products.find(p => p.id === item.id);
                                if (prod) {
                                    const saleStockSource = sale.stockSource || 'local';
                                    if (saleStockSource === 'wholesale') {
                                        prod.stockWholesale = Math.max(0, Math.round(((prod.stockWholesale || 0) - item.quantity) * 1000) / 1000);
                                    } else {
                                        prod.stock = Math.max(0, Math.round((prod.stock - item.quantity) * 1000) / 1000);
                                    }
                                }
                            }
                        }
                    }

                    // 3. Asumimos el nuevo estado y reintentamos guardar
                    state = mergedState;
                    localStorage.setItem(getStorageKey(), JSON.stringify(state)); // Guardar estado fusionado en local
                    syncSettingsInputs();
                    renderApp();
                    
                    isSyncing = false;
                    return saveDatabase(retryCount + 1);
                }
            }

            // Si llegamos acá, se guardó bien en la nube. Actualizamos localStorage y limpiamos bandera de sync.
            localStorage.removeItem('dhmotopartes_needs_sync_' + myStoreId);
            localStorage.setItem(getStorageKey(), JSON.stringify(state));
            updateSidebarStatus('online', "Conectado Nube");
            console.log("Database synchronized to Supabase successfully.");
            setupSupabaseRealtime();
        } catch (err) {
            console.error("Could not sync to Supabase:", err);
            // Revertir versión si hubo error de red
            if (state.version) state.version -= 1;
            localStorage.setItem('dhmotopartes_needs_sync_' + myStoreId, 'true');
            localStorage.setItem(getStorageKey(), JSON.stringify(state));
            updateSidebarStatus('pending', "Modo Offline (Pendiente)");
        } finally {
            isSyncing = false;
        }
    } else {
        // En Modo Local sin conexión
        localStorage.setItem(getStorageKey(), JSON.stringify(state));
        fetch('/api/db', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(state)
        }).catch(err => {
            console.warn("Could not save to remote local server, saved to LocalStorage only:", err);
        });
    }
}

// Populate database with mock data for motorcycle shop
function loadDemoData() {
    state.products = [
        { id: "p1", sku: "REP-BUJ-NGK", name: "Bujía NGK CPR8EA-9 (Honda Titan/FZ16)", category: "Sistema Eléctrico", cost: 450, price: 850, stock: 42, stockMin: 10, image: "" },
        { id: "p2", sku: "REP-FIL-ACE", name: "Filtro de Aceite Honda Tornado XR 250", category: "Repuestos de Motor", cost: 650, price: 1200, stock: 22, stockMin: 5, image: "" },
        { id: "p3", sku: "REP-PAS-FRE", name: "Pastillas de Freno Cobreq YBR 125/Fazer", category: "Frenos", cost: 1100, price: 2200, stock: 15, stockMin: 8, image: "" },
        { id: "p4", sku: "REP-KIT-TRA", name: "Kit Transmisión Completo Rouser NS 200 (DID)", category: "Transmisión", cost: 7800, price: 12500, stock: 4, stockMin: 3, image: "" },
        { id: "p5", sku: "HER-LLA-ALL", name: "Juego de Llaves Allen L-Wrench (9 Piezas)", category: "Herramientas", cost: 2700, price: 4500, stock: 12, stockMin: 4, image: "" },
        { id: "p6", sku: "HER-EXT-VOL", name: "Extractor de Volante Magneto Universal", category: "Herramientas", cost: 3800, price: 6200, stock: 2, stockMin: 2, image: "" },
        { id: "p7", sku: "ACC-CAS-REV", name: "Casco Rebatible Hawk Revo Negro Mate L", category: "Accesorios", cost: 19000, price: 28900, stock: 6, stockMin: 2, image: "" },
        { id: "p8", sku: "REP-CAB-EMB", name: "Cable de Embrague Corven Triax 150", category: "Transmisión", cost: 500, price: 1100, stock: 0, stockMin: 5, image: "" },
        { id: "p9", sku: "REP-BTE-YUAS", name: "Batería Yuasa 12V 7Ah YTX7L-BS", category: "Sistema Eléctrico", cost: 13500, price: 19500, stock: 9, stockMin: 3, image: "" },
        { id: "p10", sku: "HER-COR-CAD", name: "Corta Cadena Profesional Mecánico", category: "Herramientas", cost: 2000, price: 3400, stock: 15, stockMin: 5, image: "" }
    ];

    state.customers = [
        { id: "c1", name: "Martín Gómez (Taller El Rayo)", phone: "+54 9 11 4444-5555", email: "tallerelrayo@gmail.com", points: 150, dateRegistered: "2026-01-15" },
        { id: "c2", name: "Sofía Rodríguez", phone: "+54 9 11 9999-8888", email: "sofia.rod@outlook.com", points: 45, dateRegistered: "2026-03-22" },
        { id: "c3", name: "Juan Carlos Depetris", phone: "+54 9 11 3333-2222", email: "jc.depetris@yahoo.com.ar", points: 10, dateRegistered: "2026-04-10" }
    ];

    // Generate sales for the last 7 days to populate the chart
    state.sales = [];
    const today = new Date();
    const daysData = [
        { daysAgo: 6, total: 32000, qty: 3 },
        { daysAgo: 5, total: 45000, qty: 4 },
        { daysAgo: 4, total: 18000, qty: 2 },
        { daysAgo: 3, total: 62000, qty: 5 },
        { daysAgo: 2, total: 41000, qty: 4 },
        { daysAgo: 1, total: 83000, qty: 7 },
        { daysAgo: 0, total: 54000, qty: 4 }
    ];

    daysData.forEach(day => {
        const saleDate = new Date(today);
        saleDate.setDate(today.getDate() - day.daysAgo);

        state.sales.push({
            id: `V-100${day.daysAgo}`,
            date: saleDate.toISOString(),
            customerId: "c1",
            customerName: "Martín Gómez (Taller El Rayo)",
            items: [
                { id: "p1", name: "Bujía NGK CPR8EA-9", price: 850, quantity: 4 },
                { id: "p4", name: "Kit Transmisión NS 200", price: 12500, quantity: 1 }
            ],
            subtotal: 15900,
            discount: 0,
            tax: 2385,
            total: 18285,
            paymentMethod: "card",
            amountReceived: 18285,
            changeReturned: 0,
            status: "completed"
        });

        // Adjust the total sum for demo purposes
        state.sales[state.sales.length - 1].total = day.total;
    });

    state.cashMovements = [
        {
            id: "cm_demo_1",
            date: new Date(today.getTime() - 3600000 * 24 * 3).toISOString(), // 3 days ago
            type: "inflow",
            amount: 5000.00,
            concept: "Apertura de caja - Caja Inicial",
            notes: "Caja chica de apertura"
        },
        {
            id: "cm_demo_2",
            date: new Date(today.getTime() - 3600000 * 24 * 2).toISOString(), // 2 days ago
            type: "outflow",
            amount: 1500.00,
            concept: "Pago de flete / Envío de repuestos urgentes",
            notes: "Flete Moto Express"
        }
    ];

    state.cart = [];
    saveDatabase();
}

/* ==========================================================================
   Routing
   ========================================================================== */
function initRouter() {
    // If no hash, default to dashboard
    if (!window.location.hash) {
        window.location.hash = '#dashboard';
    }
    handleRoute();
}

function handleRoute() {
    const hash = window.location.hash || '#dashboard';
    const views = ['dashboard', 'pos', 'inventario', 'clientes', 'proveedores', 'historial', 'caja', 'configuracion', 'saas', 'catalogo'];

    // Parse target view
    let targetView = hash.replace('#', '');

    if (!views.includes(targetView)) return;

    // Fullscreen and Preview Banner handling for Catalog
    const banner = document.getElementById('catalog-preview-banner');
    if (targetView === 'catalogo') {
        document.body.classList.add('catalog-fullscreen');
        if (banner) banner.style.display = 'flex';
    } else {
        document.body.classList.remove('catalog-fullscreen');
        if (banner) banner.style.display = 'none';
    }

    // Route protection for cajero
    if (currentUserRole === 'cajero' && targetView !== 'pos' && targetView !== 'catalogo') {
        window.location.hash = '#pos';
        return;
    }

    // Route protection for saas_admin
    if (currentUserRole === 'saas_admin') {
        const forbiddenViewsForSaaSAdmin = ['pos', 'inventario', 'clientes', 'proveedores', 'caja', 'configuracion'];
        if (forbiddenViewsForSaaSAdmin.includes(targetView)) {
            window.location.hash = '#dashboard';
            return;
        }
    }

    // Hide/Show backups configuration panel dynamically based on role
    if (targetView === 'configuracion') {
        const backupPanel = document.getElementById('config-respaldo-panel');
        if (backupPanel) {
            if (currentUserRole === 'saas_admin') {
                backupPanel.style.display = 'none';
            } else {
                backupPanel.style.display = ''; // Restore default
            }
        }
        syncFiscalSettingsInputs();
    }

    // Toggle active link in sidebar
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === hash) {
            link.classList.add('active');
        }
    });

    // Toggle active view container
    document.querySelectorAll('.app-view').forEach(view => {
        view.classList.remove('active-view');
        if (view.id === `view-${targetView}`) {
            view.classList.add('active-view');
        }
    });

    // Update Header Title
    const titleMap = {
        'dashboard': 'Panel de Control',
        'pos': 'Punto de Venta (POS)',
        'inventario': 'Control de Inventario',
        'clientes': 'Clientes CRM',
        'proveedores': 'Gestión de Proveedores',
        'historial': 'Historial de Ventas',
        'caja': 'Control de Caja y Movimientos',
        'configuracion': 'Configuración del Sistema',
        'saas': 'Panel SaaS Global',
        'catalogo': 'Catálogo de Clientes'
    };

    document.getElementById('page-title').textContent = titleMap[targetView] || 'DHMotopartes';

    // Close sidebar on mobile after choosing a link
    document.getElementById('app-sidebar').classList.remove('mobile-open');

    // Perform route-specific re-renders
    if (targetView === 'dashboard') {
        renderDashboard();
    } else if (targetView === 'pos') {
        renderPOS();
    } else if (targetView === 'inventario') {
        renderInventory();
    } else if (targetView === 'clientes') {
        renderCustomers();
    } else if (targetView === 'proveedores') {
        renderSuppliers();
    } else if (targetView === 'historial') {
        renderHistory();
    } else if (targetView === 'caja') {
        renderCaja();
    } else if (targetView === 'catalogo') {
        renderCatalog();
    } else if (targetView === 'saas') {
        if (currentUserRole === 'saas_admin') {
            loadSaasStores();
        } else {
            alert("No tienes permisos para acceder a esta sección.");
            window.location.hash = '#dashboard';
        }
    }
}

/* ==========================================================================
   Audio Synthesis Beeps
   ========================================================================== */
function playScanSound(type = 'success') {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        if (type === 'success') {
            osc.frequency.setValueAtTime(1000, ctx.currentTime); // High pitched beep
            gain.gain.setValueAtTime(0.08, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08); // very short
            osc.start(ctx.currentTime);
            osc.stop(ctx.currentTime + 0.08);
        } else if (type === 'warning') {
            osc.frequency.setValueAtTime(600, ctx.currentTime); // Alert chime
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
            osc.start(ctx.currentTime);
            osc.stop(ctx.currentTime + 0.15);
        } else {
            osc.frequency.setValueAtTime(250, ctx.currentTime); // Low pitch fail buzz
            gain.gain.setValueAtTime(0.12, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
            osc.start(ctx.currentTime);
            osc.stop(ctx.currentTime + 0.25);
        }
    } catch (e) {
        console.warn("Web Audio API is not supported or blocked by browser permissions", e);
    }
}

/* ==========================================================================
   Global Event Listeners Setup
   ========================================================================== */
function setupEventListeners() {
    // Sidebar Toggle (Mobile & Desktop)
    const sidebarToggleBtn = document.getElementById('sidebar-toggle-btn');
    if (sidebarToggleBtn) {
        sidebarToggleBtn.addEventListener('click', () => {
            const sidebar = document.getElementById('app-sidebar');
            if (window.innerWidth <= 768) {
                sidebar.classList.add('mobile-open');
            } else {
                sidebar.classList.toggle('collapsed');
                localStorage.setItem('sidebar-collapsed', sidebar.classList.contains('collapsed'));
            }
        });
    }

    const sidebarCloseBtn = document.getElementById('sidebar-close-btn');
    if (sidebarCloseBtn) {
        sidebarCloseBtn.addEventListener('click', () => {
            document.getElementById('app-sidebar').classList.remove('mobile-open');
        });
    }

    // Apply saved sidebar collapsed state on load (for desktop)
    const isCollapsed = localStorage.getItem('sidebar-collapsed') === 'true';
    const sidebar = document.getElementById('app-sidebar');
    if (isCollapsed && window.innerWidth > 768 && sidebar) {
        sidebar.classList.add('collapsed');
    }

    // Theme Toggle
    document.getElementById('theme-toggle-btn').addEventListener('click', toggleTheme);
    document.getElementById('theme-btn-dark').addEventListener('click', () => applyThemeMode('dark'));
    document.getElementById('theme-btn-light').addEventListener('click', () => applyThemeMode('light'));

    // Theme Accent Pickers
    document.getElementById('accent-pickers-container').addEventListener('click', (e) => {
        if (e.target.classList.contains('color-dot')) {
            document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('active'));
            e.target.classList.add('active');
            applyAccentTheme(e.target.dataset.color);
        }
    });

    // Close modal triggers
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
        btn.addEventListener('click', () => {
            const modalId = btn.getAttribute('data-close-modal');
            closeModal(modalId);
        });
    });

    // POS Search & Clear Inputs
    const posSearchInput = document.getElementById('pos-search-input');
    const posClearSearch = document.getElementById('pos-clear-search');
    const debouncedRenderPOSGrid = debounce(renderPOSProductGrid, 150);
    posSearchInput.addEventListener('input', () => {
        if (posSearchInput.value) {
            posClearSearch.style.display = 'block';
        } else {
            posClearSearch.style.display = 'none';
        }
        posPage = 1; // Reset to page 1 on search
        debouncedRenderPOSGrid();
    });
    posClearSearch.addEventListener('click', () => {
        posSearchInput.value = '';
        posClearSearch.style.display = 'none';
        posSearchInput.focus();
        posPage = 1; // Reset to page 1
        renderPOSProductGrid();
    });

    // POS Cart Action Buttons
    document.getElementById('cart-clear-btn').addEventListener('click', clearCart);
    document.getElementById('cart-apply-discount-btn').addEventListener('click', () => openModal('modal-discount'));
    document.getElementById('cart-checkout-btn').addEventListener('click', openCheckoutModal);

    // Price List and Customer selection auto-switch listeners in POS
    const cartPriceListSelect = document.getElementById('cart-price-list-select');
    const cartStockSourceSelect = document.getElementById('cart-stock-source-select');

    if (cartPriceListSelect) {
        cartPriceListSelect.addEventListener('change', () => {
            if (cartStockSourceSelect) {
                cartStockSourceSelect.value = cartPriceListSelect.value === 'priceWholesale' ? 'wholesale' : 'local';
            }
            window.changeCartPriceList();
        });
    }

    if (cartStockSourceSelect) {
        cartStockSourceSelect.addEventListener('change', () => {
            renderCart();
            renderPOSProductGrid();
        });
    }

    const cartCustomerSelect = document.getElementById('cart-customer-select');
    if (cartCustomerSelect) {
        cartCustomerSelect.addEventListener('change', () => {
            const customerId = cartCustomerSelect.value;
            if (customerId !== "0") {
                const customer = state.customers.find(c => c.id === customerId);
                if (customer && customer.defaultPriceList && cartPriceListSelect) {
                    let defaultList = customer.defaultPriceList;
                    if (defaultList === 'priceDiscount') defaultList = 'priceWholesale';
                    cartPriceListSelect.value = defaultList;
                    if (cartStockSourceSelect) {
                        cartStockSourceSelect.value = defaultList === 'priceWholesale' ? 'wholesale' : 'local';
                    }
                    window.changeCartPriceList();
                }
            }
        });
    }

    // Discount Save
    document.getElementById('discount-save-btn').addEventListener('click', applyCartDiscount);

    // Customer Add Button in POS
    document.getElementById('pos-add-customer-btn').addEventListener('click', () => {
        document.getElementById('customer-modal-title').textContent = "Registrar Cliente Nuevo";
        document.getElementById('customer-id-field').value = "";
        document.getElementById('customer-form').reset();
        const dniInput = document.getElementById('cust-dni');
        if (dniInput) {
            dniInput.readOnly = false;
            dniInput.required = true;
        }
        openModal('modal-customer');
    });

    // Customer Save Form
    document.getElementById('customer-form').addEventListener('submit', saveCustomer);

    const docTipoSelect = document.getElementById('cust-doc-tipo');
    if (docTipoSelect) {
        docTipoSelect.addEventListener('change', () => {
            const dniInput = document.getElementById('cust-dni');
            if (dniInput) {
                if (docTipoSelect.value === '99') {
                    dniInput.value = '0';
                    dniInput.readOnly = true;
                    dniInput.required = false;
                } else {
                    if (dniInput.value === '0') dniInput.value = '';
                    dniInput.readOnly = false;
                    dniInput.required = true;
                }
            }
        });
    }

    // Checkout Processing Listeners
    document.getElementById('checkout-confirm-btn').addEventListener('click', processCheckout);
    document.getElementById('checkout-cash-received').addEventListener('input', calculateChange);

    // Quick Cash container
    document.getElementById('quick-cash-container').addEventListener('click', (e) => {
        if (e.target.classList.contains('quick-cash-btn')) {
            const val = parseFloat(e.target.dataset.amount);
            document.getElementById('checkout-cash-received').value = val;
            calculateChange();
        }
    });

    // Checkout Method Switch
    document.getElementById('checkout-method-selector').addEventListener('click', (e) => {
        const btn = e.target.closest('.method-btn');
        if (btn) {
            document.querySelectorAll('.method-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const cashSection = document.getElementById('checkout-cash-inputs');
            const creditInfo = document.getElementById('checkout-credit-info');

            if (btn.dataset.method === 'cash') {
                cashSection.style.display = 'block';
                if (creditInfo) creditInfo.style.display = 'none';
                calculateChange();
            } else if (btn.dataset.method === 'credit') {
                cashSection.style.display = 'none';
                if (creditInfo) creditInfo.style.display = 'block';
                updateCreditCheckoutValidation();
            } else {
                cashSection.style.display = 'none';
                if (creditInfo) creditInfo.style.display = 'none';
                document.getElementById('checkout-confirm-btn').disabled = false;
            }
        }
    });

    // Inventory View Listeners
    const btnReceptionAi = document.getElementById('btn-reception-ai');
    if (btnReceptionAi) {
        btnReceptionAi.addEventListener('click', () => {
            openReceptionAiModal();
        });
    }
    initReceptionAiListeners();

    document.getElementById('inventory-add-product-btn').addEventListener('click', () => {
        document.getElementById('product-modal-title').textContent = "Registrar Nuevo Repuesto";
        document.getElementById('product-id-field').value = "";
        document.getElementById('product-form').reset();
        document.getElementById('prod-sku').readOnly = false;

        // Reset simple/combo product type UI
        const typeSimple = document.getElementById('prod-type-simple');
        if (typeSimple) typeSimple.checked = true;
        const typeCombo = document.getElementById('prod-type-combo');
        if (typeCombo) typeCombo.checked = false;
        const stockInput = document.getElementById('prod-stock');
        if (stockInput) {
            stockInput.readOnly = false;
        }
        const stockWholesaleInput = document.getElementById('prod-stock-wholesale');
        if (stockWholesaleInput) {
            stockWholesaleInput.readOnly = false;
        }
        const comboSection = document.getElementById('combo-components-section');
        if (comboSection) comboSection.style.display = 'none';
        tempComboComponents = [];
        window.updateComboComponentsTable();

        // Reset image selector UI
        tempProductImageBase64 = "";
        const fileRadio = document.getElementById('prod-image-src-file');
        if (fileRadio) fileRadio.checked = true;
        const dropzone = document.getElementById('prod-image-dropzone');
        if (dropzone) dropzone.style.display = 'flex';
        const urlGroup = document.getElementById('prod-image-url-group');
        if (urlGroup) urlGroup.style.display = 'none';
        const previewContainer = document.getElementById('prod-image-preview-container');
        if (previewContainer) previewContainer.style.display = 'none';
        const fileInput = document.getElementById('prod-image-file-input');
        if (fileInput) fileInput.value = "";

        openModal('modal-product');
    });

    document.getElementById('product-form').addEventListener('submit', saveProduct);

    // Combo Type Switcher Listeners
    const typeSimple = document.getElementById('prod-type-simple');
    const typeCombo = document.getElementById('prod-type-combo');
    const stockInput = document.getElementById('prod-stock');
    const stockWholesaleInput = document.getElementById('prod-stock-wholesale');
    const comboSection = document.getElementById('combo-components-section');

    if (typeSimple && typeCombo) {
        const toggleType = () => {
            if (typeCombo.checked) {
                if (stockInput) {
                    stockInput.value = 0;
                    stockInput.readOnly = true;
                }
                if (stockWholesaleInput) {
                    stockWholesaleInput.value = 0;
                    stockWholesaleInput.readOnly = true;
                }
                if (comboSection) {
                    comboSection.style.display = 'block';
                    // Scroll to bottom of modal-body to reveal search magnifying glass
                    const modalBody = comboSection.closest('.modal-body');
                    if (modalBody) {
                        setTimeout(() => {
                            modalBody.scrollTop = modalBody.scrollHeight;
                        }, 150);
                    }
                }
                window.updateComboComponentsTable();
            } else {
                if (stockInput) {
                    stockInput.readOnly = false;
                }
                if (stockWholesaleInput) {
                    stockWholesaleInput.readOnly = false;
                }
                if (comboSection) comboSection.style.display = 'none';
            }
        };
        typeSimple.addEventListener('change', toggleType);
        typeCombo.addEventListener('change', toggleType);
    }

    // Combo Components Search Listener
    const comboSearchInput = document.getElementById('combo-search-input');
    if (comboSearchInput) {
        comboSearchInput.addEventListener('input', window.handleComboSearch);
    }

    // Combo Apply Suggested Prices
    const applyBtn = document.getElementById('combo-apply-suggested-btn');
    if (applyBtn) {
        applyBtn.addEventListener('click', () => {
            const cost = parseFloat(applyBtn.dataset.cost) || 0;
            const price = parseFloat(applyBtn.dataset.price) || 0;
            const wholesale = parseFloat(applyBtn.dataset.wholesale) || 0;
            document.getElementById('prod-cost').value = cost.toFixed(2);
            document.getElementById('prod-price').value = price.toFixed(2);
            document.getElementById('prod-price-wholesale').value = wholesale.toFixed(2);
        });
    }

    const debouncedRenderInventoryTable = debounce(renderInventoryTable, 150);
    document.getElementById('inventory-search').addEventListener('input', debouncedRenderInventoryTable);
    document.getElementById('inventory-filter-category').addEventListener('change', renderInventoryTable);
    document.getElementById('inventory-filter-stock').addEventListener('change', renderInventoryTable);

    // Customers View Search
    const debouncedRenderCustomersTable = debounce(renderCustomersTable, 150);
    document.getElementById('customers-search').addEventListener('input', debouncedRenderCustomersTable);
    document.getElementById('customers-add-btn').addEventListener('click', () => {
        document.getElementById('customer-modal-title').textContent = "Registrar Cliente Nuevo";
        document.getElementById('customer-id-field').value = "";
        document.getElementById('customer-form').reset();
        const dniInput = document.getElementById('cust-dni');
        if (dniInput) {
            dniInput.readOnly = false;
            dniInput.required = true;
        }
        openModal('modal-customer');
    });

    // Suppliers View Search & Actions
    const debouncedRenderSuppliersTable = debounce(renderSuppliersTable, 150);
    const suppSearchInput = document.getElementById('suppliers-search');
    if (suppSearchInput) {
        suppSearchInput.addEventListener('input', debouncedRenderSuppliersTable);
    }
    const suppAddBtn = document.getElementById('suppliers-add-btn');
    if (suppAddBtn) {
        suppAddBtn.addEventListener('click', () => {
            document.getElementById('supplier-modal-title').textContent = "Registrar Proveedor Nuevo";
            document.getElementById('supplier-id-field').value = "";
            document.getElementById('supplier-form').reset();
            openModal('modal-supplier');
        });
    }
    const suppForm = document.getElementById('supplier-form');
    if (suppForm) {
        suppForm.addEventListener('submit', saveSupplier);
    }
    const suppPayForm = document.getElementById('supplier-payment-form');
    if (suppPayForm) {
        suppPayForm.addEventListener('submit', processSupplierPayment);
    }

    // History View Search & Filters
    const debouncedRenderHistoryTable = debounce(renderHistoryTable, 150);
    document.getElementById('history-search').addEventListener('input', debouncedRenderHistoryTable);
    document.getElementById('history-filter-start').addEventListener('change', renderHistoryTable);
    document.getElementById('history-filter-end').addEventListener('change', renderHistoryTable);
    document.getElementById('history-filter-status').addEventListener('change', renderHistoryTable);

    // Receipt Actions
    document.getElementById('receipt-print-btn').addEventListener('click', () => {
        window.print();
    });
    document.getElementById('receipt-void-btn').addEventListener('click', voidSale);

    // Settings Store Form
    document.getElementById('settings-store-form').addEventListener('submit', saveSettings);

    // Settings Fiscal Form (ARCA)
    const settingsFiscalForm = document.getElementById('settings-fiscal-form');
    if (settingsFiscalForm) {
        settingsFiscalForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const cuit = document.getElementById('set-fiscal-cuit').value;
            const pos = document.getElementById('set-fiscal-pos').value;
            const iva = document.getElementById('set-fiscal-iva').value;
            const env = document.getElementById('set-fiscal-env').value;
            const cert = document.getElementById('set-fiscal-cert').value;
            const key = document.getElementById('set-fiscal-key').value;
            
            try {
                const saveBtn = settingsFiscalForm.querySelector('button[type="submit"]');
                const originalHtml = saveBtn.innerHTML;
                saveBtn.disabled = true;
                saveBtn.innerHTML = '⌛ Guardando...';
                
                await saveFiscalConfig(cuit, pos, iva, env, cert, key);
                
                alert("¡Configuración fiscal guardada con éxito!");
                saveBtn.disabled = false;
                saveBtn.innerHTML = originalHtml;
            } catch (err) {
                alert("Error al guardar la configuración fiscal: " + err.message);
                console.error(err);
            }
        });
    }

    // Cash Movement Listeners
    document.getElementById('caja-add-inflow-btn').addEventListener('click', () => {
        document.getElementById('caja-movement-modal-title').textContent = "Registrar Ingreso de Caja";
        document.getElementById('caja-movement-type-field').value = "inflow";
        document.getElementById('caja-movement-form').reset();
        openModal('modal-caja-movement');
    });

    document.getElementById('caja-add-outflow-btn').addEventListener('click', () => {
        document.getElementById('caja-movement-modal-title').textContent = "Registrar Egreso de Caja";
        document.getElementById('caja-movement-type-field').value = "outflow";
        document.getElementById('caja-movement-form').reset();
        openModal('modal-caja-movement');
    });

    document.getElementById('caja-movement-form').addEventListener('submit', saveCajaMovement);
    const debouncedRenderCaja = debounce(() => {
        cajaPage = 1;
        renderCaja();
    }, 150);
    document.getElementById('caja-search').addEventListener('input', debouncedRenderCaja);
    document.getElementById('caja-filter-type').addEventListener('change', () => {
        cajaPage = 1;
        renderCaja();
    });

    // Cierre de Caja Listeners
    const doCloseBtn = document.getElementById('caja-do-close-btn');
    if (doCloseBtn) {
        doCloseBtn.addEventListener('click', openCierreCajaModal);
    }
    const actualCashInput = document.getElementById('cierre-actual-cash');
    if (actualCashInput) {
        actualCashInput.addEventListener('input', updateCierreDifferenceBadge);
    }
    const cierreForm = document.getElementById('cierre-caja-form');
    if (cierreForm) {
        cierreForm.addEventListener('submit', processCierreCaja);
    }

    // Excel Import/Export Listeners
    document.getElementById('inventory-import-excel').addEventListener('change', handleExcelImport);
    document.getElementById('inventory-export-excel').addEventListener('click', exportInventoryExcel);
    document.getElementById('excel-confirm-import-btn').addEventListener('click', confirmExcelImport);
    document.getElementById('excel-download-template-btn').addEventListener('click', downloadExcelTemplate);

    // Data backups & resets
    document.getElementById('data-load-demo-btn').addEventListener('click', () => {
        if (confirm("¿Estás seguro de que deseas sobrescribir los datos actuales con la base de datos demo de la repuestera?")) {
            loadDemoData();
            syncSettingsInputs(); // sync settings inputs
            renderApp();
            playScanSound('success');
            alert("Base de datos demo cargada con éxito.");
        }
    });

    document.getElementById('data-reset-btn').addEventListener('click', () => {
        if (confirm("ATENCIÓN: Se eliminarán todos los productos, ventas y clientes de forma permanente. ¿Deseas continuar?")) {
            state.products = [];
            state.sales = [];
            state.customers = [];
            state.cart = [];
            saveDatabase();
            renderApp();
            playScanSound('fail');
            alert("El sistema ha sido reiniciado por completo.");
        }
    });

    document.getElementById('data-export-btn').addEventListener('click', exportJSONBackup);
    document.getElementById('data-import-input').addEventListener('change', importJSONBackup);
    document.getElementById('data-export-csv-btn').addEventListener('click', exportSalesCSV);

    // Keyboard Shortcuts (F8 for Cobrar, F9 for Imprimir)
    window.addEventListener('keydown', (e) => {
        if (!e || !e.key) return;
        if (e.key === 'F8') {
            const checkoutBtn = document.getElementById('cart-checkout-btn');
            if (window.location.hash === '#pos' && checkoutBtn && !checkoutBtn.disabled) {
                e.preventDefault();
                openCheckoutModal();
            }
        }
        if (e.key === 'F9') {
            const printModal = document.getElementById('modal-receipt');
            if (printModal && printModal.classList.contains('active')) {
                e.preventDefault();
                window.print();
            }
        }
    });

    // Select dropdown cardBgType change logic
    const cardBgTypeSelect = document.getElementById('set-card-bg-type');
    const colorGroup = document.getElementById('card-bg-color-group');
    const imageGroup = document.getElementById('card-bg-image-group');

    if (cardBgTypeSelect) {
        cardBgTypeSelect.addEventListener('change', (e) => {
            const val = e.target.value;
            if (colorGroup) colorGroup.style.display = (val === 'color') ? 'block' : 'none';
            if (imageGroup) imageGroup.style.display = (val === 'image') ? 'block' : 'none';
        });
    }

    // Logo Upload Logic
    const logoInput = document.getElementById('brand-logo-input');
    const logoDropzone = document.getElementById('brand-logo-dropzone');
    const logoPreviewContainer = document.getElementById('brand-logo-preview-container');
    const logoPreviewImg = document.getElementById('brand-logo-preview-img');
    const logoRemoveBtn = document.getElementById('brand-logo-remove-btn');

    if (logoDropzone && logoInput) {
        logoDropzone.addEventListener('click', () => logoInput.click());

        logoDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            logoDropzone.style.borderColor = 'var(--primary)';
        });
        logoDropzone.addEventListener('dragleave', () => {
            logoDropzone.style.borderColor = '';
        });
        logoDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            logoDropzone.style.borderColor = '';
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleLogoFile(e.dataTransfer.files[0]);
            }
        });

        logoInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleLogoFile(e.target.files[0]);
            }
        });
    }

    function handleLogoFile(file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            tempLogoBase64 = event.target.result;
            if (logoPreviewImg) logoPreviewImg.src = tempLogoBase64;
            if (logoPreviewContainer) logoPreviewContainer.style.display = 'flex';
            if (logoDropzone) logoDropzone.style.display = 'none';
        };
        reader.readAsDataURL(file);
    }

    if (logoRemoveBtn) {
        logoRemoveBtn.addEventListener('click', () => {
            tempLogoBase64 = ""; // Clear
            if (logoInput) logoInput.value = "";
            if (logoPreviewContainer) logoPreviewContainer.style.display = 'none';
            if (logoDropzone) logoDropzone.style.display = 'block';
        });
    }

    // Card BG Image Upload Logic
    const cardBgInput = document.getElementById('card-bg-image-input');
    const cardBgDropzone = document.getElementById('card-bg-dropzone');
    const cardBgPreviewContainer = document.getElementById('card-bg-preview-container');
    const cardBgPreviewImg = document.getElementById('card-bg-preview-img');
    const cardBgRemoveBtn = document.getElementById('card-bg-remove-btn');

    if (cardBgDropzone && cardBgInput) {
        cardBgDropzone.addEventListener('click', () => cardBgInput.click());

        cardBgDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            cardBgDropzone.style.borderColor = 'var(--primary)';
        });
        cardBgDropzone.addEventListener('dragleave', () => {
            cardBgDropzone.style.borderColor = '';
        });
        cardBgDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            cardBgDropzone.style.borderColor = '';
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleCardBgFile(e.dataTransfer.files[0]);
            }
        });

        cardBgInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleCardBgFile(e.target.files[0]);
            }
        });
    }

    function handleCardBgFile(file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            tempCardBgImageBase64 = event.target.result;
            if (cardBgPreviewImg) cardBgPreviewImg.src = tempCardBgImageBase64;
            if (cardBgPreviewContainer) cardBgPreviewContainer.style.display = 'flex';
            if (cardBgDropzone) cardBgDropzone.style.display = 'none';
        };
        reader.readAsDataURL(file);
    }

    if (cardBgRemoveBtn) {
        cardBgRemoveBtn.addEventListener('click', () => {
            tempCardBgImageBase64 = ""; // Clear
            if (cardBgInput) cardBgInput.value = "";
            if (cardBgPreviewContainer) cardBgPreviewContainer.style.display = 'none';
            if (cardBgDropzone) cardBgDropzone.style.display = 'block';
        });
    }

    // Public Catalog Listeners
    const btnViewCatalog = document.getElementById('btn-view-public-catalog');
    if (btnViewCatalog) {
        btnViewCatalog.addEventListener('click', () => {
            window.location.hash = '#catalogo';
        });
    }

    const catalogSearchInput = document.getElementById('catalog-search-input');
    if (catalogSearchInput) {
        catalogSearchInput.addEventListener('input', renderCatalogProductGrid);
    }

    // Product Image source toggles (File vs URL)
    const prodImgSrcFile = document.getElementById('prod-image-src-file');
    const prodImgSrcUrl = document.getElementById('prod-image-src-url');
    const prodImgDropzone = document.getElementById('prod-image-dropzone');
    const prodImgUrlGroup = document.getElementById('prod-image-url-group');
    const prodImgFileInput = document.getElementById('prod-image-file-input');
    const prodImgPreviewContainer = document.getElementById('prod-image-preview-container');
    const prodImgPreviewImg = document.getElementById('prod-image-preview-img');
    const prodImgRemoveBtn = document.getElementById('prod-image-remove-btn');

    if (prodImgSrcFile && prodImgSrcUrl) {
        prodImgSrcFile.addEventListener('change', toggleProductImageSource);
        prodImgSrcUrl.addEventListener('change', toggleProductImageSource);
    }

    function toggleProductImageSource() {
        if (prodImgSrcFile.checked) {
            prodImgUrlGroup.style.display = 'none';
            if (tempProductImageBase64) {
                prodImgDropzone.style.display = 'none';
                prodImgPreviewContainer.style.display = 'flex';
            } else {
                prodImgDropzone.style.display = 'flex';
                prodImgPreviewContainer.style.display = 'none';
            }
        } else {
            prodImgUrlGroup.style.display = 'block';
            prodImgDropzone.style.display = 'none';
            prodImgPreviewContainer.style.display = 'none';
        }
    }

    // Dropzone events for product image
    if (prodImgDropzone && prodImgFileInput) {
        prodImgDropzone.addEventListener('click', () => prodImgFileInput.click());

        prodImgDropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            prodImgDropzone.style.borderColor = 'var(--primary)';
        });
        prodImgDropzone.addEventListener('dragleave', () => {
            prodImgDropzone.style.borderColor = '';
        });
        prodImgDropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            prodImgDropzone.style.borderColor = '';
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleProductImageFile(e.dataTransfer.files[0]);
            }
        });

        prodImgFileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleProductImageFile(e.target.files[0]);
            }
        });
    }

    function handleProductImageFile(file) {
        compressProductImage(file, (compressedBase64) => {
            tempProductImageBase64 = compressedBase64;
            if (prodImgPreviewImg) prodImgPreviewImg.src = tempProductImageBase64;
            if (prodImgPreviewContainer) prodImgPreviewContainer.style.display = 'flex';
            if (prodImgDropzone) prodImgDropzone.style.display = 'none';

            // Show file size information
            const sizeInKb = Math.round((compressedBase64.length * 3 / 4) / 1024);
            const sizeInfo = document.getElementById('prod-image-size-info');
            if (sizeInfo) sizeInfo.textContent = `Optimizado: ~${sizeInKb} KB`;
        });
    }

    if (prodImgRemoveBtn) {
        prodImgRemoveBtn.addEventListener('click', () => {
            tempProductImageBase64 = "";
            if (prodImgFileInput) prodImgFileInput.value = "";
            if (prodImgPreviewContainer) prodImgPreviewContainer.style.display = 'none';
            if (prodImgDropzone) prodImgDropzone.style.display = 'flex';
        });
    }

    // Helper to compress product images using canvas
    function compressProductImage(file, callback) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 400;
                const MAX_HEIGHT = 400;
                let width = img.width;
                let height = img.height;

                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height *= MAX_WIDTH / width;
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width *= MAX_HEIGHT / height;
                        height = MAX_HEIGHT;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);

                // Export to compressed JPEG
                const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                callback(dataUrl);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
}

/* ==========================================================================
   Barcode Listener (Hardware USB/Bluetooth Keyboard Emulators)
   ========================================================================== */
function setupBarcodeListener() {
    window.addEventListener('keydown', (e) => {
        if (!e || !e.key) return;

        // Exclude inputs that are not the POS search bar.
        const activeEl = document.activeElement;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT')) {
            if (activeEl.id !== 'pos-search-input') {
                return; // User is actively typing in a form or another modal, ignore barcode intercept
            }
        }

        const currentTime = Date.now();

        // Fast typing speed validation (< 50ms interval)
        if (currentTime - lastKeyTime > 50) {
            barcodeBuffer = '';
        }

        lastKeyTime = currentTime;

        // Skip modifiers
        if (e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' || e.key === 'Meta') {
            return;
        }

        if (e.key === 'Enter') {
            if (barcodeBuffer.trim().length >= 3) {
                e.preventDefault();
                processBarcodeScan(barcodeBuffer.trim());
                barcodeBuffer = '';
            }
        } else {
            // Standard single char keys
            if (e.key.length === 1) {
                barcodeBuffer += e.key;
            }
        }
    });
}

function processBarcodeScan(code) {
    console.log("Barcode scanned:", code);

    // Look for product by SKU or unique barcode
    const product = state.products.find(p => p.sku.toUpperCase() === code.toUpperCase());

    if (product) {
        const stockSourceSelect = document.getElementById('cart-stock-source-select');
        const stockSource = stockSourceSelect ? stockSourceSelect.value : 'local';
        const currentStock = product.isCombo 
            ? window.getComboStock(product, stockSource) 
            : (stockSource === 'wholesale' ? (product.stockWholesale || 0) : product.stock);

        if (currentStock <= 0) {
            playScanSound('fail');
            alert(`El repuesto "${product.name}" no cuenta con stock disponible.`);
            return;
        }

        // Redirect first if needed so handleRoute renders the target view
        const needsRedirect = window.location.hash !== '#pos';
        if (needsRedirect) {
            window.location.hash = '#pos';
        }

        // Add to cart! If we redirected, handleRoute will render the page/cart, so avoid duplicate render.
        addCartItem(product.id, !needsRedirect);
        // Flash barcode status indicator in UI
        const badge = document.getElementById('pos-barcode-badge');
        if (badge) {
            badge.style.borderColor = 'var(--primary)';
            badge.style.boxShadow = '0 0 10px rgba(var(--primary-rgb), 0.5)';
            badge.style.backgroundColor = 'var(--primary-light)';

            setTimeout(() => {
                badge.style.borderColor = '';
                badge.style.boxShadow = '';
                badge.style.backgroundColor = '';
            }, 300);
        }
        
    } else {
        // Not found
        playScanSound('warning');

        // If in inventory view, autofill barcode to New Product SKU field
        if (window.location.hash === '#inventario') {
            document.getElementById('product-modal-title').textContent = "Registrar Nuevo Repuesto";
            document.getElementById('product-id-field').value = "";
            document.getElementById('product-form').reset();
            document.getElementById('prod-sku').value = code;
            document.getElementById('prod-sku').readOnly = false;
            openModal('modal-product');
            setTimeout(() => document.getElementById('prod-name').focus(), 300);
        } else {
            alert(`Código de barras "${code}" no encontrado en el catálogo.`);
        }
    }
}

/* ==========================================================================
   Global Theme Handling
   ========================================================================== */
function toggleTheme() {
    const isDark = document.body.classList.contains('dark-theme');
    applyThemeMode(isDark ? 'light' : 'dark');
}

function applyThemeMode(mode) {
    const darkBtn = document.getElementById('theme-btn-dark');
    const lightBtn = document.getElementById('theme-btn-light');

    if (mode === 'dark') {
        document.body.classList.remove('light-theme');
        document.body.classList.add('dark-theme');
        darkBtn.classList.add('active');
        lightBtn.classList.remove('active');
    } else {
        document.body.classList.remove('dark-theme');
        document.body.classList.add('light-theme');
        lightBtn.classList.add('active');
        darkBtn.classList.remove('active');
    }
}

function applyAccentTheme(color) {
    // Reset all theme accent classes
    document.body.classList.remove('theme-violet', 'theme-blue', 'theme-emerald', 'theme-crimson', 'theme-amber');
    if (color && color !== 'violet') {
        document.body.classList.add(`theme-${color}`);
    }
    // Update active dot in UI
    const dots = document.querySelectorAll('#accent-pickers-container .color-dot');
    dots.forEach(d => {
        if (d.dataset.color === color) {
            d.classList.add('active');
        } else {
            d.classList.remove('active');
        }
    });
    // Re-render SVG chart to pick up color change
    if (window.location.hash === '#dashboard') {
        renderSalesChartContainer();
    }
}

/* ==========================================================================
   Modals Control
   ========================================================================== */
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        // Handle autofocus fields
        if (modalId === 'modal-checkout') {
            const cashInput = document.getElementById('checkout-cash-received');
            cashInput.value = '';
            document.getElementById('checkout-change-display').textContent = "$0.00";

            // Auto focus cash input if method is cash
            const activeMethod = document.querySelector('#checkout-method-selector .method-btn.active');
            if (activeMethod.dataset.method === 'cash') {
                setTimeout(() => cashInput.focus(), 150);
            }
        }
        if (modalId === 'modal-discount') {
            setTimeout(() => document.getElementById('discount-value').focus(), 150);
        }
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

/* ==========================================================================
   Date Display
   ========================================================================== */
function initDatetime() {
    const updateTime = () => {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        document.getElementById('current-datetime').textContent = now.toLocaleDateString('es-ES', options);
    };
    updateTime();
    setInterval(updateTime, 60000);
}

/* ==========================================================================
   General Render Router dispatcher
   ========================================================================== */
function renderApp() {
    const hash = window.location.hash || '#dashboard';
    const targetView = hash.replace('#', '');
    
    // Only render the currently active view to save performance cycles on old PCs
    if (targetView === 'dashboard') {
        renderDashboard();
    } else if (targetView === 'pos') {
        renderPOS();
    } else if (targetView === 'inventario') {
        renderInventory();
    } else if (targetView === 'clientes') {
        renderCustomers();
    } else if (targetView === 'proveedores') {
        renderSuppliers();
    } else if (targetView === 'historial') {
        renderHistory();
    } else if (targetView === 'caja') {
        renderCaja();
    }
}

/* ==========================================================================
   1. DASHBOARD VIEW CONTROLLER
   ========================================================================== */
function renderDashboard() {
    if (currentUserRole === 'saas_admin') {
        const standardContent = document.getElementById('standard-dashboard-content');
        if (standardContent) standardContent.style.display = 'none';
        const saasPanel = document.getElementById('saas-dashboard-panel');
        if (saasPanel) saasPanel.style.display = 'block';
        renderSaasDashboard();
        return;
    } else {
        const standardContent = document.getElementById('standard-dashboard-content');
        if (standardContent) standardContent.style.display = 'block';
        const saasPanel = document.getElementById('saas-dashboard-panel');
        if (saasPanel) saasPanel.style.display = 'none';
    }

    // Calculate dashboard statistics
    const today = new Date().toDateString();

    // Filter completed sales today
    const salesToday = state.sales.filter(s => s.status === 'completed' && new Date(s.date).toDateString() === today);
    const totalTodaySales = salesToday.reduce((sum, s) => sum + s.total, 0);
    const profitToday = salesToday.reduce((sum, s) => {
        // Calculate cost of items sold
        let costOfSale = 0;
        s.items.forEach(item => {
            const prod = state.products.find(p => p.id === item.id);
            const cost = prod ? prod.cost : 0;
            costOfSale += cost * item.quantity;
        });
        return sum + (s.total - costOfSale - s.tax); // profit equals total minus cost minus tax
    }, 0);

    document.getElementById('metric-today-sales').textContent = `${state.settings.currency}${totalTodaySales.toFixed(2)}`;
    document.getElementById('metric-sales-count').innerHTML = `<i data-lucide="trending-up"></i> ${salesToday.length} transacciones`;
    document.getElementById('metric-today-profit').textContent = `${state.settings.currency}${Math.max(0, profitToday).toFixed(2)}`;

    const profitMargin = totalTodaySales > 0 ? (profitToday / totalTodaySales) * 100 : 0;
    document.getElementById('metric-profit-margin').textContent = `${profitMargin.toFixed(0)}% Margen prom.`;

    // Total products and stocks
    const totalProducts = state.products.length;
    const totalStockQty = state.products.reduce((sum, p) => sum + p.stock, 0);
    const totalStockWholesaleQty = state.products.reduce((sum, p) => sum + (p.stockWholesale || 0), 0);
    document.getElementById('metric-total-products').textContent = totalProducts;
    document.getElementById('metric-total-stock').textContent = `${totalStockQty} Loc. / ${totalStockWholesaleQty} May.`;

    // Low stock warnings
    const lowStockList = [];
    state.products.forEach(p => {
        const isLocLow = p.stock <= p.stockMin;
        const wholesMin = p.stockMinWholesale !== undefined ? p.stockMinWholesale : 5;
        const isWholesLow = (p.stockWholesale || 0) <= wholesMin;

        if (isLocLow || isWholesLow) {
            let detail = '';
            let isCrit = false;
            if (isLocLow && isWholesLow) {
                detail = `L: ${p.stock} | M: ${p.stockWholesale || 0}`;
                isCrit = p.stock === 0 || (p.stockWholesale || 0) === 0;
            } else if (isLocLow) {
                detail = `Local: ${p.stock}`;
                isCrit = p.stock === 0;
            } else {
                detail = `Mayorista: ${p.stockWholesale || 0}`;
                isCrit = (p.stockWholesale || 0) === 0;
            }
            lowStockList.push({
                product: p,
                detail: detail,
                isCritical: isCrit
            });
        }
    });

    const lowStockCount = lowStockList.length;
    document.getElementById('metric-low-stock-count').textContent = lowStockCount;

    const alertIconEl = document.getElementById('metric-stock-alert-icon');
    if (lowStockCount > 0) {
        alertIconEl.className = "metric-icon bg-amber status-dot pulse";
    } else {
        alertIconEl.className = "metric-icon bg-amber";
    }

    // Render Dashboard Stock Alert List
    const lowStockContainer = document.getElementById('dashboard-low-stock-list');
    if (lowStockCount === 0) {
        lowStockContainer.innerHTML = `
            <div class="empty-state-small">
                <i data-lucide="check-circle" class="text-success"></i>
                <p>Nivel de stock óptimo en todos los artículos.</p>
            </div>
        `;
    } else {
        let listHtml = '';
        // Display top 4 low stock items
        lowStockList.slice(0, 4).forEach(item => {
            const p = item.product;
            const stockColor = item.isCritical ? 'text-danger' : 'text-warning';
            listHtml += `
                <div class="feed-item">
                    <div class="feed-item-left">
                        <div class="feed-item-icon bg-amber" style="color: #f59e0b;">
                            <i data-lucide="alert-circle" style="width:14px; height:14px;"></i>
                        </div>
                        <div>
                            <p class="feed-item-title">${p.name}</p>
                            <p class="feed-item-subtext">SKU: ${p.sku}</p>
                        </div>
                    </div>
                    <div class="feed-item-right" style="text-align: right;">
                        <span class="feed-item-value ${stockColor}" style="font-size: 13px; font-weight: 600;">${item.detail}</span>
                    </div>
                </div>
            `;
        });
        lowStockContainer.innerHTML = listHtml;
    }

    // Render Recent Sales on Dashboard
    const recentSalesContainer = document.getElementById('dashboard-recent-sales');
    // completed sales, sorted desc by date
    const completedSales = state.sales.filter(s => s.status === 'completed')
        .sort((a, b) => new Date(b.date) - new Date(a.date));

    if (completedSales.length === 0) {
        recentSalesContainer.innerHTML = `
            <div class="empty-state-small">
                <i data-lucide="info"></i>
                <p>No se registran ventas realizadas.</p>
            </div>
        `;
    } else {
        let listHtml = '';
        completedSales.slice(0, 4).forEach(s => {
            const itemsCount = s.items.reduce((sum, item) => sum + item.quantity, 0);
            listHtml += `
                <div class="feed-item cursor-pointer" onclick="viewSaleDetail('${s.id}')">
                    <div class="feed-item-left">
                        <div class="feed-item-icon bg-emerald" style="color: #10b981;">
                            <i data-lucide="check" style="width:14px; height:14px;"></i>
                        </div>
                        <div>
                            <p class="feed-item-title">${s.id}</p>
                            <p class="feed-item-subtext">${s.customerName || 'Consumidor Final'} | ${itemsCount} art.</p>
                        </div>
                    </div>
                    <div class="feed-item-right">
                        <span class="feed-item-value">${state.settings.currency}${s.total.toFixed(2)}</span>
                        <p class="feed-item-subtext">${new Date(s.date).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                </div>
            `;
        });
        recentSalesContainer.innerHTML = listHtml;
    }

    renderSalesChartContainer();

    if (window.lucide) lucide.createIcons();
}

function renderSalesChartContainer() {
    // Generate data for last 7 days (today back to 6 days ago)
    const today = new Date();
    const daysWeek = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const chartData = [];

    for (let i = 6; i >= 0; i--) {
        const d = new Date(today);
        d.setDate(today.getDate() - i);

        // Sum completed sales for this date
        const dateStr = d.toDateString();
        const dailyTotal = state.sales
            .filter(s => s.status === 'completed' && new Date(s.date).toDateString() === dateStr)
            .reduce((sum, s) => sum + s.total, 0);

        chartData.push({
            date: daysWeek[d.getDay()],
            total: dailyTotal
        });
    }

    renderSalesChart('sales-chart-container', chartData, state.settings.currency);
}

async function renderSaasDashboard() {
    const select = document.getElementById('saas-store-select');
    if (!select) return;

    // Show empty state for dashboard metrics/charts initially
    const metricsGrid = document.getElementById('saas-metrics-grid');
    if (metricsGrid) metricsGrid.style.display = 'none';
    const chartLayout = document.getElementById('saas-chart-layout');
    if (chartLayout) chartLayout.style.display = 'none';
    const emptyState = document.getElementById('saas-dash-empty');
    if (emptyState) emptyState.style.display = 'flex';

    select.innerHTML = '<option value="">— Cargando negocios... —</option>';

    try {
        let stores = [];
        const session = supabaseClient ? (await supabaseClient.auth.getSession()).data.session : null;
        if (supabaseInitialized && session) {
            const { data, error } = await supabaseClient
                .from('stores')
                .select('id, name')
                .order('name', { ascending: true });

            if (error) throw error;
            stores = data;
        } else {
            // Local mode fallback
            stores = [
                { id: "demo-local-1", name: "DHMotopartes (Casa Central)" },
                { id: "demo-local-2", name: "Repuestos El Rayo (Sucursal)" }
            ];
        }

        select.innerHTML = '<option value="">— Seleccionar Negocio —</option>';
        if (stores && stores.length > 0) {
            stores.forEach(s => {
                const opt = document.createElement('option');
                opt.value = s.id;
                opt.textContent = s.name;
                select.appendChild(opt);
            });
        } else {
            select.innerHTML = '<option value="">— No hay negocios registrados —</option>';
        }
    } catch (err) {
        console.error("Error al cargar negocios para el dashboard SaaS:", err);
        select.innerHTML = '<option value="">— Error al cargar negocios —</option>';
    }
}



async function onSaasStoreSelected(storeId) {
    const metricsGrid = document.getElementById('saas-metrics-grid');
    const chartLayout = document.getElementById('saas-chart-layout');
    const emptyState = document.getElementById('saas-dash-empty');

    if (!storeId) {
        if (metricsGrid) metricsGrid.style.display = 'none';
        if (chartLayout) chartLayout.style.display = 'none';
        if (emptyState) emptyState.style.display = 'flex';
        activeSaasStoreSettings = null;
        applyBrandSettings();
        return;
    }

    if (emptyState) emptyState.style.display = 'none';
    
    try {
        let storeState = {};
        const session = supabaseClient ? (await supabaseClient.auth.getSession()).data.session : null;
        if (supabaseInitialized && session && !storeId.startsWith('demo-local')) {
            // Fetch the selected store's state from Supabase
            const { data, error } = await supabaseClient
                .from('store_states')
                .select('state')
                .eq('store_id', storeId)
                .single();

            if (error) throw error;
            storeState = (data && data.state) ? data.state : {};
        } else {
            // Local mode / demo fallback
            storeState = JSON.parse(JSON.stringify(state)); // deep copy of local state
            if (storeId === "demo-local-2") {
                // Tweak it slightly so it looks different for the other store
                storeState.sales = storeState.sales.map(s => {
                    const newS = {...s};
                    newS.total = s.total * 1.5;
                    return newS;
                });
            }
        }

        activeSaasStoreSettings = storeState.settings || {};
        applyBrandSettings();

        const sales = Array.isArray(storeState.sales) ? storeState.sales : [];
        const products = Array.isArray(storeState.products) ? storeState.products : [];
        const settings = storeState.settings || {};
        const currency = settings.currency || '$';

        // Calculate statistics (identical to standard dashboard)
        const today = new Date().toDateString();

        // Filter completed sales today
        const salesToday = sales.filter(s => s.status === 'completed' && new Date(s.date).toDateString() === today);
        const totalTodaySales = salesToday.reduce((sum, s) => sum + s.total, 0);
        const profitToday = salesToday.reduce((sum, s) => {
            let costOfSale = 0;
            s.items.forEach(item => {
                const prod = products.find(p => p.id === item.id);
                const cost = prod ? prod.cost : 0;
                costOfSale += cost * item.quantity;
            });
            return sum + (s.total - costOfSale - s.tax);
        }, 0);

        document.getElementById('saas-metric-today-sales').textContent = `${currency}${totalTodaySales.toFixed(2)}`;
        document.getElementById('saas-metric-sales-count').innerHTML = `<i data-lucide="trending-up"></i> ${salesToday.length} transacciones`;
        document.getElementById('saas-metric-today-profit').textContent = `${currency}${Math.max(0, profitToday).toFixed(2)}`;

        const profitMargin = totalTodaySales > 0 ? (profitToday / totalTodaySales) * 100 : 0;
        document.getElementById('saas-metric-profit-margin').textContent = `${profitMargin.toFixed(0)}% Margen prom.`;

        // Total products and stocks
        const totalProducts = products.length;
        const totalStockQty = products.reduce((sum, p) => sum + p.stock, 0);
        const totalStockWholesaleQty = products.reduce((sum, p) => sum + (p.stockWholesale || 0), 0);
        document.getElementById('saas-metric-total-products').textContent = totalProducts;
        document.getElementById('saas-metric-total-stock').textContent = `${totalStockQty} Loc. / ${totalStockWholesaleQty} May.`;

        // Low stock warnings
        const lowStockList = [];
        products.forEach(p => {
            const isLocLow = p.stock <= p.stockMin;
            const wholesMin = p.stockMinWholesale !== undefined ? p.stockMinWholesale : 5;
            const isWholesLow = (p.stockWholesale || 0) <= wholesMin;

            if (isLocLow || isWholesLow) {
                let detail = '';
                let isCrit = false;
                if (isLocLow && isWholesLow) {
                    detail = `L: ${p.stock} | M: ${p.stockWholesale || 0}`;
                    isCrit = p.stock === 0 || (p.stockWholesale || 0) === 0;
                } else if (isLocLow) {
                    detail = `Local: ${p.stock}`;
                    isCrit = p.stock === 0;
                } else {
                    detail = `Mayorista: ${p.stockWholesale || 0}`;
                    isCrit = (p.stockWholesale || 0) === 0;
                }
                lowStockList.push({
                    product: p,
                    detail: detail,
                    isCritical: isCrit
                });
            }
        });

        const lowStockCount = lowStockList.length;
        document.getElementById('saas-metric-low-stock-count').textContent = lowStockCount;

        const alertIconEl = document.getElementById('saas-metric-stock-alert-icon');
        if (alertIconEl) {
            if (lowStockCount > 0) {
                alertIconEl.className = "metric-icon bg-amber status-dot pulse";
            } else {
                alertIconEl.className = "metric-icon bg-amber";
            }
        }

        // Render Low Stock Alert List
        const lowStockContainer = document.getElementById('saas-dashboard-low-stock-list');
        if (lowStockContainer) {
            if (lowStockCount === 0) {
                lowStockContainer.innerHTML = `
                    <div class="empty-state-small">
                        <i data-lucide="check-circle" class="text-success"></i>
                        <p>Stock óptimo en todos los repuestos.</p>
                    </div>
                `;
            } else {
                let listHtml = '';
                lowStockList.slice(0, 4).forEach(item => {
                    const p = item.product;
                    const stockColor = item.isCritical ? 'text-danger' : 'text-warning';
                    listHtml += `
                        <div class="feed-item">
                            <div class="feed-item-left">
                                <div class="feed-item-icon bg-amber" style="color: #f59e0b;">
                                    <i data-lucide="alert-circle" style="width:14px; height:14px;"></i>
                                </div>
                                <div>
                                    <p class="feed-item-title">${p.name}</p>
                                    <p class="feed-item-subtext">SKU: ${p.sku}</p>
                                </div>
                            </div>
                            <div class="feed-item-right" style="text-align: right;">
                                <span class="feed-item-value ${stockColor}" style="font-size: 13px; font-weight: 600;">${item.detail}</span>
                            </div>
                        </div>
                    `;
                });
                lowStockContainer.innerHTML = listHtml;
            }
        }

        // Render Chart Data (last 7 days)
        const chartData = [];
        const daysWeek = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
        const dateToday = new Date();
        for (let i = 6; i >= 0; i--) {
            const d = new Date(dateToday);
            d.setDate(dateToday.getDate() - i);
            const dateStr = d.toDateString();
            const dailyTotal = sales
                .filter(s => s.status === 'completed' && new Date(s.date).toDateString() === dateStr)
                .reduce((sum, s) => sum + s.total, 0);

            chartData.push({
                date: daysWeek[d.getDay()],
                total: dailyTotal
            });
        }

        // Render sales chart
        const chartContainer = document.getElementById('saas-sales-chart-container');
        if (chartContainer) {
            chartContainer.innerHTML = '';
            renderSalesChart('saas-sales-chart-container', chartData, currency);
        }

        // Render Recent Sales (top 4 completed)
        const recentSalesContainer = document.getElementById('saas-recent-sales-list');
        if (recentSalesContainer) {
            const completedSales = sales.filter(s => s.status === 'completed')
                .sort((a, b) => new Date(b.date) - new Date(a.date));

            if (completedSales.length === 0) {
                recentSalesContainer.innerHTML = `
                    <div class="empty-state-small">
                        <i data-lucide="info"></i>
                        <p>No se registran ventas realizadas.</p>
                    </div>
                `;
            } else {
                let listHtml = '';
                completedSales.slice(0, 4).forEach(s => {
                    const itemsCount = s.items.reduce((sum, item) => sum + item.quantity, 0);
                    listHtml += `
                        <div class="feed-item">
                            <div class="feed-item-left">
                                <div class="feed-item-icon bg-success" style="color: var(--text-success);">
                                    <i data-lucide="shopping-bag" style="width:14px; height:14px;"></i>
                                </div>
                                <div>
                                    <p class="feed-item-title">Venta #${s.id.toString().slice(-6)}</p>
                                    <p class="feed-item-subtext">${s.customerName || 'Consumidor Final'} | ${itemsCount} art.</p>
                                </div>
                            </div>
                            <div class="feed-item-right">
                                <span class="feed-item-value text-success">+${currency}${s.total.toFixed(2)}</span>
                                <p class="feed-item-subtext">${new Date(s.date).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}</p>
                            </div>
                        </div>
                    `;
                });
                recentSalesContainer.innerHTML = listHtml;
            }
        }

        if (window.lucide) lucide.createIcons();

        // Show layouts
        if (metricsGrid) metricsGrid.style.display = 'grid';
        if (chartLayout) chartLayout.style.display = 'grid';

    } catch (err) {
        console.error("Error al cargar detalles de negocio:", err);
        alert("Error al cargar la información del negocio seleccionado: " + err.message);
    }
}

// Expose globally for inline events
window.onSaasStoreSelected = onSaasStoreSelected;
window.renderSaasDashboard = renderSaasDashboard;

/* ==========================================================================
   2. POINT OF SALE (POS) VIEW CONTROLLER
   ========================================================================== */
let activePOSCategory = '';

function renderPOS() {
    // Populate Customer Dropdown
    const select = document.getElementById('cart-customer-select');
    select.innerHTML = '<option value="0">Consumidor Final</option>';
    state.customers.forEach(c => {
        select.innerHTML += `<option value="${c.id}">${c.name}</option>`;
    });

    // Populate Category Tabs
    const tabsContainer = document.getElementById('pos-category-tabs');
    // Extract unique categories
    const categories = ['Todas', ...(state.settings.categories || [])];

    let tabsHtml = '';
    categories.forEach(cat => {
        const displayCat = cat === 'Todas' ? '' : cat;
        const activeClass = activePOSCategory === displayCat ? 'active' : '';
        tabsHtml += `
            <button class="category-tab ${activeClass}" onclick="setPOSCategory('${displayCat}')">
                ${cat}
            </button>
        `;
    });
    tabsContainer.innerHTML = tabsHtml;

    renderPOSProductGrid();
    renderCart();
}

window.setPOSCategory = function (cat) {
    activePOSCategory = cat;
    posPage = 1; // Reset to page 1 on category change
    renderPOS();
};

function renderPOSProductGrid() {
    const searchVal = document.getElementById('pos-search-input').value.toLowerCase();
    const grid = document.getElementById('pos-products-grid');

    // Filter catalog products
    const filtered = state.products.filter(p => {
        const matchesCategory = !activePOSCategory || p.category === activePOSCategory;
        const matchesSearch = p.name.toLowerCase().includes(searchVal) ||
            p.sku.toLowerCase().includes(searchVal);
        return matchesCategory && matchesSearch;
    });

    // Pagination slice to keep DOM footprint extremely low for old devices
    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / posItemsPerPage) || 1;
    if (posPage > totalPages) posPage = totalPages;
    
    const startIdx = (posPage - 1) * posItemsPerPage;
    const endIdx = startIdx + posItemsPerPage;
    const pageItems = filtered.slice(startIdx, endIdx);

    const posPagination = document.getElementById('pos-pagination');

    if (pageItems.length === 0) {
        grid.innerHTML = `
            <div class="empty-state-small" style="grid-column: 1 / -1;">
                <i data-lucide="package-x" style="width: 48px; height: 48px; opacity: 0.3;"></i>
                <p>No se encontraron repuestos o herramientas.</p>
            </div>
        `;
        if (posPagination) posPagination.style.display = 'none';
    } else {
        const priceListSelect = document.getElementById('cart-price-list-select');
        const priceKey = priceListSelect ? priceListSelect.value : 'price';
        const stockSourceSelect = document.getElementById('cart-stock-source-select');
        const stockSource = stockSourceSelect ? stockSourceSelect.value : (priceKey === 'priceWholesale' ? 'wholesale' : 'local');

        let cardsHtml = '';
        pageItems.forEach(p => {
            cardsHtml += createPOSProductCard(p, state.settings.currency, priceKey, stockSource);
        });
        grid.innerHTML = cardsHtml;
        
        // Render pagination controls
        if (posPagination) {
            if (totalItems <= posItemsPerPage) {
                posPagination.style.display = 'none';
            } else {
                posPagination.style.display = 'flex';
                posPagination.innerHTML = `
                    <span>Mostrando registros ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
                    <div class="flex-align-center" style="gap: 8px;">
                        <button class="btn btn-secondary btn-icon-only" onclick="changePOSPage(-1)" ${posPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
                        <span>Pág. ${posPage} de ${totalPages}</span>
                        <button class="btn btn-secondary btn-icon-only" onclick="changePOSPage(1)" ${posPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
                    </div>
                `;
            }
        }
    }

    if (window.lucide) lucide.createIcons();
}

window.changePOSPage = function(delta) {
    posPage += delta;
    renderPOSProductGrid();
};

// Shopping Cart Actions
window.addCartItem = function(prodId, shouldRender = true) {
    const product = state.products.find(p => p.id === prodId);
    if (!product) return;

    // Check stock availability
    const existingInCart = state.cart.find(item => item.id === prodId);
    const cartQty = existingInCart ? existingInCart.quantity : 0;

    const stockSourceSelect = document.getElementById('cart-stock-source-select');
    const stockSource = stockSourceSelect ? stockSourceSelect.value : 'local';
    const maxStockAvailable = product.isCombo 
        ? window.getComboStock(product, stockSource) 
        : (stockSource === 'wholesale' ? (product.stockWholesale || 0) : product.stock);

    if (cartQty >= maxStockAvailable) {
        playScanSound('fail');
        alert(`No hay más stock disponible de "${product.name}".`);
        return;
    }

    const priceListSelect = document.getElementById('cart-price-list-select');
    const priceKey = priceListSelect ? priceListSelect.value : 'price';
    let itemPrice = product.price;
    if (priceKey === 'priceWholesale') {
        itemPrice = parseFloat(product.priceWholesale) || product.price;
    }

    let addedQty = 1;
    if (product.isFractional) {
        const qtyInput = prompt(`Ingrese la cantidad a vender de "${product.name}" (Fraccionable):`, "1");
        if (qtyInput === null) return; // cancelado
        const parsedQty = parseFloat(qtyInput);
        if (isNaN(parsedQty) || parsedQty <= 0) {
            alert("Por favor, ingrese una cantidad válida mayor a 0.");
            return;
        }
        if (cartQty + parsedQty > maxStockAvailable) {
            playScanSound('fail');
            alert(`No hay suficiente stock disponible. Stock máximo restante: ${maxStockAvailable - cartQty}`);
            return;
        }
        addedQty = parsedQty;
    }

    if (existingInCart) {
        existingInCart.quantity = Math.round((existingInCart.quantity + addedQty) * 1000) / 1000;
        existingInCart.price = itemPrice;
    } else {
        state.cart.push({
            id: product.id,
            name: product.name,
            sku: product.sku,
            price: itemPrice,
            quantity: addedQty
        });
    }

    playScanSound('success');
    if (shouldRender) {
        renderCart();
    }
};

window.changeCartPriceList = function() {
    const priceListSelect = document.getElementById('cart-price-list-select');
    if (!priceListSelect) return;
    const priceKey = priceListSelect.value;

    state.cart.forEach(item => {
        const product = state.products.find(p => p.id === item.id);
        if (product) {
            if (priceKey === 'priceWholesale') {
                item.price = parseFloat(product.priceWholesale) || product.price;
            } else {
                item.price = product.price;
            }
        }
    });

    renderCart();
    renderPOSProductGrid();
};

window.modifyCartItemQty = function (prodId, delta) {
    const cartItem = state.cart.find(item => item.id === prodId);
    if (!cartItem) return;

    const product = state.products.find(p => p.id === prodId);
    if (!product) return;

    const stockSourceSelect = document.getElementById('cart-stock-source-select');
    const stockSource = stockSourceSelect ? stockSourceSelect.value : 'local';
    const maxStockAvailable = product.isCombo 
        ? window.getComboStock(product, stockSource) 
        : (stockSource === 'wholesale' ? (product.stockWholesale || 0) : product.stock);

    if (delta > 0 && cartItem.quantity + delta > maxStockAvailable) {
        playScanSound('fail');
        alert("Stock máximo alcanzado.");
        return;
    }

    cartItem.quantity = Math.round((cartItem.quantity + delta) * 1000) / 1000;
    if (cartItem.quantity <= 0) {
        state.cart = state.cart.filter(item => item.id !== prodId);
    }

    renderCart();
};

window.promptCartItemQty = function(prodId) {
    const cartItem = state.cart.find(item => item.id === prodId);
    if (!cartItem) return;

    const product = state.products.find(p => p.id === prodId);
    if (!product) return;

    const defaultValue = cartItem.quantity;
    const qtyInput = prompt(`Ingrese la cantidad para "${product.name}":`, defaultValue);
    if (qtyInput === null) return; // cancelado

    const parsedQty = parseFloat(qtyInput);
    if (isNaN(parsedQty) || parsedQty <= 0) {
        alert("Por favor ingrese una cantidad válida mayor a 0.");
        return;
    }

    const stockSourceSelect = document.getElementById('cart-stock-source-select');
    const stockSource = stockSourceSelect ? stockSourceSelect.value : 'local';
    const maxStockAvailable = product.isCombo 
        ? window.getComboStock(product, stockSource) 
        : (stockSource === 'wholesale' ? (product.stockWholesale || 0) : product.stock);

    if (parsedQty > maxStockAvailable) {
        playScanSound('fail');
        alert(`No hay suficiente stock disponible. Stock máximo: ${maxStockAvailable}`);
        return;
    }

    cartItem.quantity = product.isFractional ? parsedQty : Math.round(parsedQty);
    renderCart();
};

function clearCart() {
    if (state.cart.length > 0) {
        state.cart = [];
        // Clear active discount
        cartDiscount = { type: 'amount', value: 0 };
        renderCart();
    }
}

// Calculate totals & update UI
let cartDiscount = { type: 'amount', value: 0 };

function renderCart() {
    const list = document.getElementById('cart-items-list');

    if (state.cart.length === 0) {
        list.innerHTML = `
            <div class="cart-empty-state">
                <i data-lucide="shopping-bag" class="cart-empty-icon"></i>
                <p>El carrito está vacío</p>
                <span class="text-muted small">Haz clic en los repuestos del catálogo para agregarlos</span>
            </div>
        `;
        document.getElementById('cart-summary-subtotal').textContent = "$0.00";
        document.getElementById('cart-summary-discount').textContent = "-$0.00";
        document.getElementById('cart-summary-tax').textContent = "$0.00";
        document.getElementById('cart-summary-total').textContent = "$0.00";
        document.getElementById('cart-checkout-btn').disabled = true;

        if (window.lucide) lucide.createIcons();
        return;
    }

    let itemsHtml = '';
    state.cart.forEach(item => {
        itemsHtml += `
            <div class="cart-item">
                <div>
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-sku">SKU: ${item.sku} | ${state.settings.currency}${item.price.toFixed(2)}</div>
                </div>
                <div class="cart-item-qty">
                    <button class="qty-btn" onclick="modifyCartItemQty('${item.id}', -1)">-</button>
                    <span class="qty-val" style="min-width: 24px; width: auto; padding: 0 4px; cursor: pointer;" title="Haga clic para editar cantidad" onclick="promptCartItemQty('${item.id}')">${item.quantity}</span>
                    <button class="qty-btn" onclick="modifyCartItemQty('${item.id}', 1)">+</button>
                </div>
                <div class="cart-item-price">
                    ${state.settings.currency}${(item.price * item.quantity).toFixed(2)}
                </div>
            </div>
        `;
    });
    list.innerHTML = itemsHtml;

    // Totals Math
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // Apply Discount
    let discountAmt = 0;
    if (cartDiscount.type === 'amount') {
        discountAmt = cartDiscount.value;
    } else {
        discountAmt = subtotal * (cartDiscount.value / 100);
    }
    // Cap discount at subtotal
    discountAmt = Math.min(discountAmt, subtotal);

    const taxableAmount = Math.max(0, subtotal - discountAmt);
    const taxRate = state.settings.storeTax / 100;
    const tax = taxableAmount * taxRate;
    const total = taxableAmount + tax;

    // Set summary elements
    document.getElementById('cart-summary-subtotal').textContent = `${state.settings.currency}${subtotal.toFixed(2)}`;
    document.getElementById('cart-summary-discount').textContent = `-${state.settings.currency}${discountAmt.toFixed(2)}`;
    document.getElementById('cart-summary-tax-label').textContent = `Impuesto (${state.settings.storeTax}%):`;
    document.getElementById('cart-summary-tax').textContent = `${state.settings.currency}${tax.toFixed(2)}`;
    document.getElementById('cart-summary-total').textContent = `${state.settings.currency}${total.toFixed(2)}`;
    document.getElementById('cart-checkout-btn').disabled = false;
}

function applyCartDiscount() {
    const type = document.getElementById('discount-type').value;
    const value = parseFloat(document.getElementById('discount-value').value) || 0;

    if (value < 0) {
        alert("El valor del descuento no puede ser menor a 0.");
        return;
    }

    cartDiscount = { type, value };
    closeModal('modal-discount');
    renderCart();
}

// Checkout Modal trigger
let checkoutTotalVal = 0;

function openCheckoutModal() {
    // Calculate total from cart
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    let discountAmt = 0;
    if (cartDiscount.type === 'amount') {
        discountAmt = cartDiscount.value;
    } else {
        discountAmt = subtotal * (cartDiscount.value / 100);
    }
    discountAmt = Math.min(discountAmt, subtotal);
    const taxableAmount = Math.max(0, subtotal - discountAmt);
    const tax = taxableAmount * (state.settings.storeTax / 100);
    checkoutTotalVal = taxableAmount + tax;

    document.getElementById('checkout-total-display').textContent = `${state.settings.currency}${checkoutTotalVal.toFixed(2)}`;

    // Render Quick Cash buttons (rounding bills in cash)
    const quickContainer = document.getElementById('quick-cash-container');
    const exactOption = Math.ceil(checkoutTotalVal);
    const options = [
        exactOption,
        Math.ceil(exactOption / 100) * 100, // round next 100
        Math.ceil(exactOption / 500) * 500, // round next 500
        Math.ceil(exactOption / 1000) * 1000 // round next 1000
    ];
    // Remove duplicates
    const uniqueOptions = [...new Set(options)].sort((a, b) => a - b);

    let cashBtns = '';
    uniqueOptions.forEach(opt => {
        cashBtns += `
            <button class="quick-cash-btn" data-amount="${opt}">
                ${state.settings.currency}${opt}
            </button>
        `;
    });
    quickContainer.innerHTML = cashBtns;

    // Reset default payment method to cash
    document.querySelectorAll('.method-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector('[data-method="cash"]').classList.add('active');
    document.getElementById('checkout-cash-inputs').style.display = 'block';
    const creditInfo = document.getElementById('checkout-credit-info');
    if (creditInfo) creditInfo.style.display = 'none';

    openModal('modal-checkout');
}

function calculateChange() {
    const receivedInput = document.getElementById('checkout-cash-received');
    const received = parseFloat(receivedInput.value) || 0;
    const confirmBtn = document.getElementById('checkout-confirm-btn');

    const change = received - checkoutTotalVal;

    const changeDisplay = document.getElementById('checkout-change-display');
    changeDisplay.textContent = `${state.settings.currency}${Math.max(0, change).toFixed(2)}`;

    if (change >= -0.01) { // allow fractional rounding
        confirmBtn.disabled = false;
        changeDisplay.className = "change-value text-success";
    } else {
        confirmBtn.disabled = true;
        changeDisplay.className = "change-value text-danger";
    }
}

function updateCreditCheckoutValidation() {
    const selectedCustomerId = document.getElementById('cart-customer-select').value;
    const confirmBtn = document.getElementById('checkout-confirm-btn');
    const container = document.getElementById('checkout-credit-info');
    const titleEl = document.getElementById('checkout-credit-status-title');
    const descEl = document.getElementById('checkout-credit-status-desc');

    if (selectedCustomerId === "0") {
        confirmBtn.disabled = true;
        if (container) {
            container.style.background = 'rgba(245, 158, 11, 0.1)';
            container.style.borderColor = 'rgba(245, 158, 11, 0.3)';
        }
        if (titleEl) {
            titleEl.textContent = "Selección de Cliente Requerida";
            titleEl.parentElement.style.color = 'var(--amber)';
        }
        if (descEl) descEl.textContent = "Para vender a Cuenta Corriente debe seleccionar un cliente registrado en el carrito de compras (no se permite Consumidor Final).";
    } else {
        const customer = state.customers.find(c => c.id === selectedCustomerId);
        if (customer && customer.hasCreditAccount === false) {
            confirmBtn.disabled = true;
            if (container) {
                container.style.background = 'rgba(239, 68, 68, 0.1)';
                container.style.borderColor = 'rgba(239, 68, 68, 0.3)';
            }
            if (titleEl) {
                titleEl.textContent = "Cuenta Corriente Deshabilitada";
                titleEl.parentElement.style.color = 'var(--danger)';
            }
            if (descEl) descEl.textContent = `El cliente ${customer.name} no tiene habilitada la opción de compras a Cuenta Corriente. Puede activarla en el CRM.`;
        } else if (customer && customer.creditLimit > 0 && (((customer.deuda || 0) + checkoutTotalVal) > customer.creditLimit)) {
            confirmBtn.disabled = true;
            if (container) {
                container.style.background = 'rgba(239, 68, 68, 0.1)';
                container.style.borderColor = 'rgba(239, 68, 68, 0.3)';
            }
            if (titleEl) {
                titleEl.textContent = "Límite de Crédito Excedido";
                titleEl.parentElement.style.color = 'var(--danger)';
            }
            if (descEl) descEl.textContent = `Esta compra (${state.settings.currency}${checkoutTotalVal.toFixed(2)}) superará el límite de crédito para ${customer.name} (Límite: ${state.settings.currency}${customer.creditLimit.toFixed(2)}, Deuda actual: ${state.settings.currency}${(customer.deuda || 0).toFixed(2)}).`;
        } else {
            confirmBtn.disabled = false;
            if (container) {
                container.style.background = 'rgba(16, 185, 129, 0.1)';
                container.style.borderColor = 'rgba(16, 185, 129, 0.3)';
            }
            if (titleEl) {
                titleEl.textContent = "Venta a Cuenta Corriente (Apto)";
                titleEl.parentElement.style.color = 'var(--success)';
            }
            const currentDebt = customer ? (customer.deuda || 0) : 0;
            if (descEl) {
                if (currentDebt < 0) {
                    descEl.textContent = `✨ El cliente ${customer ? customer.name : ''} posee ${state.settings.currency}${Math.abs(currentDebt).toFixed(2)} a favor. Se consumirá este saldo en la compra.`;
                } else if (currentDebt > 0) {
                    descEl.textContent = `El importe total (${state.settings.currency}${checkoutTotalVal.toFixed(2)}) se sumará a la deuda actual (${state.settings.currency}${currentDebt.toFixed(2)}) de ${customer ? customer.name : 'cliente'}.`;
                } else {
                    descEl.textContent = `El importe total (${state.settings.currency}${checkoutTotalVal.toFixed(2)}) se cargará como deuda a la ficha de ${customer ? customer.name : 'cliente'}.`;
                }
            }
        }
    }
}

// Process Checkout & deduct inventory stocks
async function processCheckout() {
    const selectedCustomerId = document.getElementById('cart-customer-select').value;
    let customerName = "Consumidor Final";
    let customer = null;

    if (selectedCustomerId !== "0") {
        customer = state.customers.find(c => c.id === selectedCustomerId);
        if (customer) {
            customerName = customer.name;
        }
    }

    // Capture payment details
    const activeMethod = document.querySelector('#checkout-method-selector .method-btn.active').dataset.method;

    if (activeMethod === 'credit') {
        if (!customer || selectedCustomerId === "0") {
            alert("Debe seleccionar un cliente registrado para realizar una venta a Cuenta Corriente.");
            return;
        }
        if (customer.hasCreditAccount === false) {
            alert(`El cliente ${customer.name} no tiene habilitada la Cuenta Corriente.`);
            return;
        }
        // Cart total calculation preview
        const subtotalPreview = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        let discPreview = cartDiscount.type === 'amount' ? cartDiscount.value : subtotalPreview * (cartDiscount.value / 100);
        discPreview = Math.min(discPreview, subtotalPreview);
        const taxablePreview = Math.max(0, subtotalPreview - discPreview);
        const totalPreview = taxablePreview + (taxablePreview * (state.settings.storeTax / 100));

        if (customer.creditLimit > 0 && ((customer.deuda || 0) + totalPreview) > customer.creditLimit) {
            alert(`La venta excede el límite de crédito asignado a ${customer.name}.`);
            return;
        }
    }

    const received = activeMethod === 'cash' ? parseFloat(document.getElementById('checkout-cash-received').value) || 0 : checkoutTotalVal;
    const change = received - checkoutTotalVal;

    // Cart calculations
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    let discountAmt = 0;
    if (cartDiscount.type === 'amount') {
        discountAmt = cartDiscount.value;
    } else {
        discountAmt = subtotal * (cartDiscount.value / 100);
    }
    discountAmt = Math.min(discountAmt, subtotal);
    const taxableAmount = Math.max(0, subtotal - discountAmt);
    const tax = taxableAmount * (state.settings.storeTax / 100);
    const total = taxableAmount + tax;

    // Deduct stock in catalog database
    const stockSourceSelect = document.getElementById('cart-stock-source-select');
    const stockSource = stockSourceSelect ? stockSourceSelect.value : 'local';

    state.cart.forEach(cartItem => {
        const prod = state.products.find(p => p.id === cartItem.id);
        if (prod) {
            if (prod.isCombo && prod.components) {
                // Deduct stock of components
                prod.components.forEach(comp => {
                    const compProd = state.products.find(p => p.id === comp.id);
                    if (compProd) {
                        if (stockSource === 'wholesale') {
                            compProd.stockWholesale = Math.max(0, Math.round(((compProd.stockWholesale || 0) - (comp.quantity * cartItem.quantity)) * 1000) / 1000);
                        } else {
                            compProd.stock = Math.max(0, Math.round((compProd.stock - (comp.quantity * cartItem.quantity)) * 1000) / 1000);
                        }
                    }
                });
            } else {
                // Deduct stock of simple product
                if (stockSource === 'wholesale') {
                    prod.stockWholesale = Math.max(0, Math.round(((prod.stockWholesale || 0) - cartItem.quantity) * 1000) / 1000);
                } else {
                    prod.stock = Math.max(0, Math.round((prod.stock - cartItem.quantity) * 1000) / 1000);
                }
            }
        }
    });

    // Folio Generator
    const transactionId = `V-${Date.now().toString().slice(-6)}`;

    // Update customer credit debt & movements if sold on credit
    if (activeMethod === 'credit' && customer) {
        customer.deuda = Math.round(((customer.deuda || 0) + total) * 100) / 100;
        if (!customer.ctaCteMovements) customer.ctaCteMovements = [];
        customer.ctaCteMovements.push({
            id: `cc_${Date.now()}`,
            date: new Date().toISOString(),
            type: 'charge',
            amount: total,
            saleId: transactionId,
            description: `Compra a Crédito (Venta #${transactionId})`
        });
    }

    // Award loyalty points (1 point per 100 units of currency spent)
    if (customer) {
        const pointsEarned = Math.floor(total / 100);
        customer.points += pointsEarned;
    }

    // Create Sale record
    const saleRecord = {
        id: transactionId,
        date: new Date().toISOString(),
        customerId: selectedCustomerId !== "0" ? selectedCustomerId : null,
        customerName: customerName,
        items: [...state.cart],
        subtotal,
        discount: discountAmt,
        tax,
        total,
        paymentMethod: activeMethod,
        amountReceived: received,
        changeReturned: Math.max(0, change),
        status: "completed",
        stockSource: stockSource
    };

    // Check if electronic invoice is requested
    const emitInvoiceCheckbox = document.getElementById('checkout-emit-invoice');
    const shouldEmitInvoice = emitInvoiceCheckbox ? emitInvoiceCheckbox.checked : false;

    saleRecord.estado_fiscal = "no_requerido";

    if (shouldEmitInvoice) {
        const confirmBtn = document.getElementById('checkout-confirm-btn');
        const originalBtnHtml = confirmBtn.innerHTML;
        confirmBtn.disabled = true;
        confirmBtn.innerHTML = '⌛ Autorizando ARCA...';

        try {
            const fiscalConfig = await loadFiscalConfig();
            if (!fiscalConfig || !fiscalConfig.cuit) {
                throw new Error("No hay configuración fiscal cargada para esta tienda. Configúrala en Ajustes.");
            }

            const result = await facturador.emitirComprobante(saleRecord, fiscalConfig);
            if (result.success) {
                saleRecord.estado_fiscal = "emitido";
                saleRecord.nro_comprobante = result.nroComprobante;
                saleRecord.cae = result.cae;
                saleRecord.cae_vto = result.caeFchVto;
            } else {
                throw new Error(result.error || "Error desconocido al autorizar CAE.");
            }
        } catch (err) {
            console.error("Facturación electrónica fallida:", err);
            saleRecord.estado_fiscal = "pendiente";
            saleRecord.error_fiscal = err.message;
            alert("⚠️ La venta se registró con éxito, pero la facturación electrónica falló:\n" + err.message + "\n\nPuede reintentar la facturación desde el Historial de Ventas.");
        } finally {
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = originalBtnHtml;
        }
    }

    state.sales.push(saleRecord);

    // Persist to local DB
    saveDatabase();

    // Close checkout and clear cart
    closeModal('modal-checkout');
    state.cart = [];
    cartDiscount = { type: 'amount', value: 0 };
    renderCart();

    // Render and print receipt
    renderPOS(); // update POS view
    playScanSound('success');
    viewSaleDetail(transactionId);
}

/* ==========================================================================
   3. INVENTORY VIEW CONTROLLER
   ========================================================================== */
function renderInventory() {
    // Populate category filters
    const filterCat = document.getElementById('inventory-filter-category');
    const prodCatSelect = document.getElementById('prod-category');

    const categories = state.settings.categories || [];

    if (filterCat) {
        filterCat.innerHTML = '<option value="">Todas las categorías</option>';
        categories.forEach(cat => {
            filterCat.innerHTML += `<option value="${cat}">${cat}</option>`;
        });
    }

    if (prodCatSelect) {
        prodCatSelect.innerHTML = '<option value="">Seleccione una categoría</option>';
        categories.forEach(cat => {
            prodCatSelect.innerHTML += `<option value="${cat}">${cat}</option>`;
        });
    }

    // Render table
    renderInventoryTable();
}

function renderInventoryTable() {
    const searchVal = document.getElementById('inventory-search').value.toLowerCase();
    const catVal = document.getElementById('inventory-filter-category').value;
    const stockVal = document.getElementById('inventory-filter-stock').value;
    const tbody = document.getElementById('inventory-table-body');

    // Apply filters
    const filtered = state.products.filter(p => {
        const matchesSearch = p.name.toLowerCase().includes(searchVal) ||
            p.sku.toLowerCase().includes(searchVal);

        const matchesCategory = !catVal || p.category === catVal;

        let matchesStock = true;
        const stockLocal = p.isCombo ? window.getComboStock(p, 'local') : p.stock;
        const stockWholesale = p.isCombo ? window.getComboStock(p, 'wholesale') : (p.stockWholesale || 0);
        const minWholesale = p.stockMinWholesale !== undefined ? p.stockMinWholesale : 5;

        if (stockVal === 'low') {
            matchesStock = (stockLocal > 0 && stockLocal <= p.stockMin) || (stockWholesale > 0 && stockWholesale <= minWholesale);
        } else if (stockVal === 'out') {
            matchesStock = stockLocal <= 0 || stockWholesale <= 0;
        } else if (stockVal === 'ok') {
            matchesStock = stockLocal > p.stockMin && stockWholesale > minWholesale;
        }

        return matchesSearch && matchesCategory && matchesStock;
    });

    // Pagination slice
    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (inventoryPage > totalPages) inventoryPage = totalPages;

    const startIdx = (inventoryPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageItems = filtered.slice(startIdx, endIdx);

    // Build markup
    if (pageItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="13" class="text-center text-muted" style="padding: 40px;">
                    No se registran productos con los filtros seleccionados.
                </td>
            </tr>
        `;
        document.getElementById('inventory-pagination').innerHTML = '';
        return;
    }

    let rowsHtml = '';
    pageItems.forEach(p => {
        const marginL1 = p.price > 0 ? ((p.price - p.cost) / p.price) * 100 : 0;
        const wholesalePrice = parseFloat(p.priceWholesale) || 0;
        const marginL2 = wholesalePrice > 0 ? ((wholesalePrice - p.cost) / wholesalePrice) * 100 : 0;

        const stockLocal = p.isCombo ? window.getComboStock(p, 'local') : p.stock;
        let stockLocalBadge = 'ok';
        let stockLocalText = p.isFractional ? `${stockLocal}` : `${stockLocal} U.`;
        if (stockLocal <= 0) {
            stockLocalBadge = 'out';
            stockLocalText = 'Sin Stock';
        } else if (stockLocal <= p.stockMin) {
            stockLocalBadge = 'low';
            stockLocalText = `${stockLocal} (Bajo)`;
        }

        const stockWholesale = p.isCombo ? window.getComboStock(p, 'wholesale') : (p.stockWholesale || 0);
        let stockWholesaleBadge = 'ok';
        let stockWholesaleText = p.isFractional ? `${stockWholesale}` : `${stockWholesale} U.`;
        const minWholesale = p.stockMinWholesale !== undefined ? p.stockMinWholesale : 5;
        if (stockWholesale <= 0) {
            stockWholesaleBadge = 'out';
            stockWholesaleText = 'Sin Stock';
        } else if (stockWholesale <= minWholesale) {
            stockWholesaleBadge = 'low';
            stockWholesaleText = `${stockWholesale} (Bajo)`;
        }

        const nameCell = p.isCombo 
            ? `<div class="flex-align-center" style="gap: 6px; display: inline-flex;">${p.name} <span class="badge badge-primary" style="font-size: 10px; padding: 2px 6px; background-color: var(--primary); color: #fff; border-radius: var(--radius-sm); font-weight: bold; margin-left: 6px;">Combo</span></div>`
            : p.name;

        rowsHtml += `
            <tr>
                <td style="font-weight: 700;">${p.sku}</td>
                <td style="font-weight: 500;">${nameCell}</td>
                <td>${p.category}</td>
                <td class="text-right">${state.settings.currency}${p.cost.toFixed(2)}</td>
                <td class="text-right" style="font-weight: 700;">${state.settings.currency}${p.price.toFixed(2)}</td>
                <td class="text-right">${state.settings.currency}${wholesalePrice.toFixed(2)}</td>
                <td class="text-center text-emerald" style="font-weight: 600;">${marginL1.toFixed(0)}%</td>
                <td class="text-center text-amber" style="font-weight: 600;">${marginL2.toFixed(0)}%</td>
                <td class="text-center">
                    <span class="stock-pill ${stockLocalBadge}">${stockLocalText}</span>
                </td>
                <td class="text-center text-muted">${p.stockMin}</td>
                <td class="text-center">
                    <span class="stock-pill ${stockWholesaleBadge}">${stockWholesaleText}</span>
                </td>
                <td class="text-center text-muted">${minWholesale}</td>
                <td class="text-center">
                    <div class="table-action-btn-group">
                        <button class="btn btn-secondary btn-icon-only" onclick="editProduct('${p.id}')" title="Editar"><i data-lucide="edit-3" style="width:14px; height:14px;"></i></button>
                        <button class="btn btn-danger btn-outline btn-icon-only" onclick="deleteProduct('${p.id}')" title="Eliminar"><i data-lucide="trash-2" style="width:14px; height:14px;"></i></button>
                    </div>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    // Render pagination footer
    document.getElementById('inventory-pagination').innerHTML = `
        <span>Mostrando registros ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
        <div class="flex-align-center" style="gap: 8px;">
            <button class="btn btn-secondary btn-icon-only" onclick="changeInventoryPage(-1)" ${inventoryPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
            <span>Pág. ${inventoryPage} de ${totalPages}</span>
            <button class="btn btn-secondary btn-icon-only" onclick="changeInventoryPage(1)" ${inventoryPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

window.changeInventoryPage = function (delta) {
    inventoryPage += delta;
    renderInventoryTable();
};

// Create or edit product in DB
function saveProduct(e) {
    e.preventDefault();

    const id = document.getElementById('product-id-field').value;
    const sku = document.getElementById('prod-sku').value.trim().toUpperCase();
    const name = document.getElementById('prod-name').value.trim();
    const category = document.getElementById('prod-category').value;
    const cost = parseFloat(document.getElementById('prod-cost').value) || 0;
    const price = parseFloat(document.getElementById('prod-price').value) || 0;
    const priceWholesale = parseFloat(document.getElementById('prod-price-wholesale').value) || 0;
    
    const isFractional = document.getElementById('prod-is-fractional').checked;
    const stock = isFractional ? (parseFloat(document.getElementById('prod-stock').value) || 0) : (parseInt(document.getElementById('prod-stock').value) || 0);
    const stockMin = isFractional ? (parseFloat(document.getElementById('prod-stock-min').value) || 0) : (parseInt(document.getElementById('prod-stock-min').value) || 5);

    const stockWholesale = isFractional ? (parseFloat(document.getElementById('prod-stock-wholesale').value) || 0) : (parseInt(document.getElementById('prod-stock-wholesale').value) || 0);
    const stockMinWholesale = isFractional ? (parseFloat(document.getElementById('prod-stock-wholesale-min').value) || 0) : (parseInt(document.getElementById('prod-stock-wholesale-min').value) || 5);

    const isFileMode = document.getElementById('prod-image-src-file').checked;
    const image = isFileMode ? tempProductImageBase64 : document.getElementById('prod-image').value.trim();

    const isCombo = document.getElementById('prod-type-combo').checked;
    const finalStock = isCombo ? 0 : stock;
    const finalStockWholesale = isCombo ? 0 : stockWholesale;

    // Check SKU duplicate on creation
    if (!id) {
        const skuExists = state.products.find(p => p.sku === sku);
        if (skuExists) {
            alert(`Ya existe un repuesto con el SKU: ${sku}`);
            return;
        }

        state.products.push({
            id: `p_${Date.now()}`,
            sku, name, category, cost, price, priceWholesale, 
            priceDiscount: priceWholesale, // mantener por compatibilidad
            stock: finalStock, 
            stockMin,
            stockWholesale: finalStockWholesale,
            stockMinWholesale,
            image,
            isCombo,
            isFractional,
            components: isCombo ? [...tempComboComponents] : []
        });
    } else {
        const product = state.products.find(p => p.id === id);
        if (product) {
            product.sku = sku;
            product.name = name;
            product.category = category;
            product.cost = cost;
            product.price = price;
            product.priceWholesale = priceWholesale;
            product.priceDiscount = priceWholesale; // mantener por compatibilidad
            product.isCombo = isCombo;
            product.isFractional = isFractional;
            product.components = isCombo ? [...tempComboComponents] : [];
            if (!isCombo) {
                product.stock = stock;
                product.stockWholesale = stockWholesale;
            } else {
                product.stock = 0;
                product.stockWholesale = 0;
            }
            product.stockMin = stockMin;
            product.stockMinWholesale = stockMinWholesale;
            product.image = image;
        }
    }

    saveDatabase();
    closeModal('modal-product');
    renderInventory();
    playScanSound('success');
}

window.editProduct = function (id) {
    const p = state.products.find(prod => prod.id === id);
    if (!p) return;

    document.getElementById('product-modal-title').textContent = "Editar Repuesto";
    document.getElementById('product-id-field').value = p.id;
    document.getElementById('prod-sku').value = p.sku;
    document.getElementById('prod-sku').readOnly = true;
    document.getElementById('prod-name').value = p.name;
    document.getElementById('prod-category').value = p.category;
    document.getElementById('prod-cost').value = p.cost;
    document.getElementById('prod-price').value = p.price;
    document.getElementById('prod-price-wholesale').value = p.priceWholesale || p.priceDiscount || 0;
    document.getElementById('prod-stock-min').value = p.stockMin;
    document.getElementById('prod-stock-wholesale-min').value = p.stockMinWholesale !== undefined ? p.stockMinWholesale : 5;
    document.getElementById('prod-is-fractional').checked = p.isFractional || false;

    const isCombo = p.isCombo || false;
    document.getElementById('prod-type-simple').checked = !isCombo;
    document.getElementById('prod-type-combo').checked = isCombo;

    const stockInput = document.getElementById('prod-stock');
    const stockWholesaleInput = document.getElementById('prod-stock-wholesale');
    const comboSection = document.getElementById('combo-components-section');

    if (isCombo) {
        if (stockInput) {
            stockInput.value = window.getComboStock(p, 'local');
            stockInput.readOnly = true;
        }
        if (stockWholesaleInput) {
            stockWholesaleInput.value = window.getComboStock(p, 'wholesale');
            stockWholesaleInput.readOnly = true;
        }
        if (comboSection) comboSection.style.display = 'block';
        tempComboComponents = [...(p.components || [])];
    } else {
        if (stockInput) {
            stockInput.value = p.stock;
            stockInput.readOnly = false;
        }
        if (stockWholesaleInput) {
            stockWholesaleInput.value = p.stockWholesale !== undefined ? p.stockWholesale : 0;
            stockWholesaleInput.readOnly = false;
        }
        if (comboSection) comboSection.style.display = 'none';
        tempComboComponents = [];
    }
    window.updateComboComponentsTable();

    // Reset image uploader UI first
    tempProductImageBase64 = "";
    const fileInput = document.getElementById('prod-image-file-input');
    if (fileInput) fileInput.value = "";

    const hasBase64Image = p.image && p.image.startsWith('data:image/');

    if (hasBase64Image) {
        const fileRadio = document.getElementById('prod-image-src-file');
        if (fileRadio) fileRadio.checked = true;

        tempProductImageBase64 = p.image;
        const previewImg = document.getElementById('prod-image-preview-img');
        if (previewImg) previewImg.src = p.image;

        const previewContainer = document.getElementById('prod-image-preview-container');
        if (previewContainer) previewContainer.style.display = 'flex';

        const dropzone = document.getElementById('prod-image-dropzone');
        if (dropzone) dropzone.style.display = 'none';

        const urlGroup = document.getElementById('prod-image-url-group');
        if (urlGroup) urlGroup.style.display = 'none';

        const urlInput = document.getElementById('prod-image');
        if (urlInput) urlInput.value = '';

        // Show file size information
        const sizeInKb = Math.round((p.image.length * 3 / 4) / 1024);
        const sizeInfo = document.getElementById('prod-image-size-info');
        if (sizeInfo) sizeInfo.textContent = `Optimizado: ~${sizeInKb} KB`;
    } else {
        const urlRadio = document.getElementById('prod-image-src-url');
        if (urlRadio) urlRadio.checked = true;

        const urlInput = document.getElementById('prod-image');
        if (urlInput) urlInput.value = p.image || '';

        const previewContainer = document.getElementById('prod-image-preview-container');
        if (previewContainer) previewContainer.style.display = 'none';

        const dropzone = document.getElementById('prod-image-dropzone');
        if (dropzone) dropzone.style.display = 'none';

        const urlGroup = document.getElementById('prod-image-url-group');
        if (urlGroup) urlGroup.style.display = 'block';
    }

    openModal('modal-product');
};

window.deleteProduct = function (id) {
    if (confirm("¿Estás seguro de que deseas eliminar este producto del catálogo?")) {
        state.products = state.products.filter(p => p.id !== id);
        saveDatabase();
        renderInventory();
        playScanSound('fail');
    }
};

/* ==========================================================================
   4. CUSTOMERS VIEW CONTROLLER
   ========================================================================== */
/* ==========================================================================
   4. CUSTOMERS VIEW CONTROLLER
   ========================================================================== */
function renderCustomers() {
    updateCustomersMetrics();
    renderCustomersTable();
}

function updateCustomersMetrics() {
    const customersList = state.customers || [];
    const totalCustomers = customersList.length;
    const totalDebt = customersList.reduce((sum, c) => sum + ((c.deuda || 0) > 0 ? c.deuda : 0), 0);
    const totalCredit = customersList.reduce((sum, c) => sum + ((c.deuda || 0) < 0 ? Math.abs(c.deuda) : 0), 0);
    const indebtedCount = customersList.filter(c => (c.deuda || 0) > 0).length;
    const creditCount = customersList.filter(c => (c.deuda || 0) < 0).length;

    const totalEl = document.getElementById('customers-metric-total');
    const debtEl = document.getElementById('customers-metric-total-debt');
    const countEl = document.getElementById('customers-metric-indebted-count');

    if (totalEl) totalEl.textContent = totalCustomers;
    if (debtEl) debtEl.textContent = `${state.settings.currency}${totalDebt.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    if (countEl) {
        let subtext = `${indebtedCount} ${indebtedCount === 1 ? 'cliente con deuda' : 'clientes con deuda'}`;
        if (creditCount > 0) {
            subtext += ` | ${creditCount} a favor (${state.settings.currency}${totalCredit.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`;
        }
        countEl.textContent = subtext;
    }
}

function renderCustomersTable() {
    const searchVal = document.getElementById('customers-search').value.toLowerCase();
    const tbody = document.getElementById('customers-table-body');

    const filtered = state.customers.filter(c => {
        return c.name.toLowerCase().includes(searchVal) ||
            (c.phone && c.phone.includes(searchVal)) ||
            (c.email && c.email.toLowerCase().includes(searchVal)) ||
            (c.dni && c.dni.includes(searchVal));
    });

    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (customersPage > totalPages) customersPage = totalPages;

    const startIdx = (customersPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageItems = filtered.slice(startIdx, endIdx);

    if (pageItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-muted" style="padding: 40px;">
                    No hay clientes registrados en el sistema.
                </td>
            </tr>
        `;
        document.getElementById('customers-pagination').innerHTML = '';
        return;
    }

    let rowsHtml = '';
    pageItems.forEach(c => {
        let docLabel = "DNI";
        if (c.doc_tipo === 80) docLabel = "CUIT";
        else if (c.doc_tipo === 99) docLabel = "CF";

        let ivaLabel = "Consumidor Final";
        if (c.cond_iva_receptor === 1) ivaLabel = "Resp. Inscripto";
        else if (c.cond_iva_receptor === 6) ivaLabel = "Monotributista";
        else if (c.cond_iva_receptor === 4) ivaLabel = "Sujeto Exento";

        const debt = c.deuda || 0;
        let debtBadge = '';
        if (debt > 0) {
            debtBadge = `<span class="badge badge-danger" style="font-weight: 700;">Debe ${state.settings.currency}${debt.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>`;
        } else if (debt < 0) {
            debtBadge = `<span class="badge badge-success" style="font-weight: 700;">A favor: ${state.settings.currency}${Math.abs(debt).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>`;
        } else {
            debtBadge = `<span class="badge badge-secondary" style="opacity: 0.85;">Al día (${state.settings.currency}0.00)</span>`;
        }

        rowsHtml += `
            <tr>
                <td>${c.id}</td>
                <td style="font-weight: 600;">
                    ${c.name}
                    <div style="font-size: 11px; color: var(--text-muted); font-weight: normal; margin-top: 2px;">
                        ${docLabel}: ${c.dni || 'No registrado'} | ${ivaLabel}
                    </div>
                </td>
                <td>${c.phone || '<span class="text-muted">No registrado</span>'}</td>
                <td>${c.email || '<span class="text-muted">No registrado</span>'}</td>
                <td class="text-center" style="font-weight: 700; color: var(--primary);">${c.points} pts</td>
                <td class="text-right">${debtBadge}</td>
                <td>${c.dateRegistered || '-'}</td>
                <td class="text-center">
                    <div class="table-action-btn-group">
                        <button class="btn ${debt > 0 ? 'btn-emerald' : 'btn-secondary'} btn-icon-only" onclick="openCustomerPaymentModal('${c.id}')" title="${debt < 0 ? 'Registrar Abono A Favor' : 'Cobrar / Abonar Cta. Cte.'}"><i data-lucide="hand-coins" style="width:14px; height:14px;"></i></button>
                        <button class="btn btn-secondary btn-icon-only" onclick="openCustomerMovementsModal('${c.id}')" title="Ver Historial Cta. Cte."><i data-lucide="history" style="width:14px; height:14px;"></i></button>
                        <button class="btn btn-secondary btn-icon-only" onclick="editCustomer('${c.id}')" title="Editar"><i data-lucide="edit-3" style="width:14px; height:14px;"></i></button>
                        <button class="btn btn-danger btn-outline btn-icon-only" onclick="deleteCustomer('${c.id}')" title="Eliminar"><i data-lucide="trash-2" style="width:14px; height:14px;"></i></button>
                    </div>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    document.getElementById('customers-pagination').innerHTML = `
        <span>Mostrando registros ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
        <div class="flex-align-center" style="gap: 8px;">
            <button class="btn btn-secondary btn-icon-only" onclick="changeCustomersPage(-1)" ${customersPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
            <span>Pág. ${customersPage} de ${totalPages}</span>
            <button class="btn btn-secondary btn-icon-only" onclick="changeCustomersPage(1)" ${customersPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

window.changeCustomersPage = function (delta) {
    customersPage += delta;
    renderCustomersTable();
};

function saveCustomer(e) {
    e.preventDefault();

    const id = document.getElementById('customer-id-field').value;
    const firstName = document.getElementById('cust-first-name').value.trim();
    const lastName = document.getElementById('cust-last-name').value.trim();
    const dni = document.getElementById('cust-dni').value.trim();
    const phone = document.getElementById('cust-phone').value.trim();
    const email = document.getElementById('cust-email').value.trim();
    const points = parseInt(document.getElementById('cust-points').value) || 0;
    const docTipo = parseInt(document.getElementById('cust-doc-tipo').value) || 96;
    const condIva = parseInt(document.getElementById('cust-iva-condition').value) || 5;
    const defaultPriceList = document.getElementById('cust-price-list').value;
    const hasCreditAccount = document.getElementById('cust-has-credit') ? document.getElementById('cust-has-credit').checked : true;
    const creditLimit = parseFloat(document.getElementById('cust-credit-limit') ? document.getElementById('cust-credit-limit').value : 0) || 0;

    const compiledName = `${firstName} ${lastName}`;

    if (!id) {
        // Create new
        state.customers.push({
            id: `c_${Date.now()}`,
            firstName,
            lastName,
            name: compiledName,
            dni,
            phone,
            email,
            points,
            doc_tipo: docTipo,
            cond_iva_receptor: condIva,
            defaultPriceList,
            hasCreditAccount,
            creditLimit,
            deuda: 0,
            ctaCteMovements: [],
            dateRegistered: new Date().toISOString().split('T')[0]
        });
    } else {
        // Edit existing
        const customer = state.customers.find(c => c.id === id);
        if (customer) {
            customer.firstName = firstName;
            customer.lastName = lastName;
            customer.name = compiledName;
            customer.dni = dni;
            customer.phone = phone;
            customer.email = email;
            customer.points = points;
            customer.doc_tipo = docTipo;
            customer.cond_iva_receptor = condIva;
            customer.defaultPriceList = defaultPriceList;
            customer.hasCreditAccount = hasCreditAccount;
            customer.creditLimit = creditLimit;
        }
    }

    saveDatabase();
    closeModal('modal-customer');

    // Refresh current view (POS or CRM)
    if (window.location.hash === '#pos') {
        renderPOS();
    } else {
        renderCustomers();
    }

    playScanSound('success');
}

window.editCustomer = function (id) {
    const c = state.customers.find(cust => cust.id === id);
    if (!c) return;

    document.getElementById('customer-modal-title').textContent = "Editar Cliente";
    document.getElementById('customer-id-field').value = c.id;
    document.getElementById('cust-first-name').value = c.firstName || c.name.split(' ')[0] || '';
    document.getElementById('cust-last-name').value = c.lastName || c.name.split(' ').slice(1).join(' ') || '';
    document.getElementById('cust-dni').value = c.dni || '';
    document.getElementById('cust-phone').value = c.phone || '';
    document.getElementById('cust-email').value = c.email || '';
    document.getElementById('cust-points').value = c.points;
    const hasCreditCheckbox = document.getElementById('cust-has-credit');
    if (hasCreditCheckbox) hasCreditCheckbox.checked = c.hasCreditAccount !== false;
    const creditLimitInput = document.getElementById('cust-credit-limit');
    if (creditLimitInput) creditLimitInput.value = c.creditLimit || '';

    const docTipoSelect = document.getElementById('cust-doc-tipo');
    const dniInput = document.getElementById('cust-dni');
    const ivaSelect = document.getElementById('cust-iva-condition');

    if (docTipoSelect) docTipoSelect.value = c.doc_tipo || '96';
    if (ivaSelect) ivaSelect.value = c.cond_iva_receptor || '5';
    const priceListSelect = document.getElementById('cust-price-list');
    if (priceListSelect) {
        let defaultList = c.defaultPriceList || 'price';
        if (defaultList === 'priceDiscount') defaultList = 'priceWholesale';
        priceListSelect.value = defaultList;
    }

    if (docTipoSelect && dniInput) {
        if (docTipoSelect.value === '99') {
            dniInput.readOnly = true;
            dniInput.required = false;
        } else {
            dniInput.readOnly = false;
            dniInput.required = true;
        }
    }

    openModal('modal-customer');
};

/* ==========================================================================
   CUSTOMER ACCOUNT MOVEMENTS & PAYMENTS LOGIC
   ========================================================================== */
window.openCustomerPaymentModal = function (customerId) {
    const c = state.customers.find(cust => cust.id === customerId);
    if (!c) return;

    document.getElementById('cust-pay-id').value = c.id;
    document.getElementById('cust-pay-name').textContent = c.name;
    const debt = c.deuda || 0;
    const debtEl = document.getElementById('cust-pay-current-debt');
    if (debt > 0) {
        debtEl.textContent = `${state.settings.currency}${debt.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (Deuda)`;
        debtEl.style.color = 'var(--danger)';
    } else if (debt < 0) {
        debtEl.textContent = `${state.settings.currency}${Math.abs(debt).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (A Favor)`;
        debtEl.style.color = 'var(--success)';
    } else {
        debtEl.textContent = `${state.settings.currency}0.00 (Sin Deuda)`;
        debtEl.style.color = 'var(--text-muted)';
    }
    document.getElementById('cust-pay-amount').value = debt > 0 ? debt.toFixed(2) : '';
    document.getElementById('cust-pay-amount').removeAttribute('max');
    document.getElementById('cust-pay-notes').value = '';

    openModal('modal-customer-payment');
};

window.setFullDebtPayment = function () {
    const custId = document.getElementById('cust-pay-id').value;
    const c = state.customers.find(cust => cust.id === custId);
    if (c && c.deuda > 0) {
        document.getElementById('cust-pay-amount').value = c.deuda.toFixed(2);
    }
};

window.saveCustomerPayment = function (e) {
    e.preventDefault();

    const custId = document.getElementById('cust-pay-id').value;
    const c = state.customers.find(cust => cust.id === custId);
    if (!c) {
        alert("Cliente no encontrado.");
        return;
    }

    const amount = parseFloat(document.getElementById('cust-pay-amount').value) || 0;
    const method = document.getElementById('cust-pay-method').value;
    const notes = document.getElementById('cust-pay-notes').value.trim();

    if (amount <= 0) {
        alert("Ingrese un monto válido a abonar.");
        return;
    }

    // Deduct debt (allows negative numbers representing Saldo a Favor)
    c.deuda = Math.round(((c.deuda || 0) - amount) * 100) / 100;

    // Register movement in customer's credit history
    if (!c.ctaCteMovements) c.ctaCteMovements = [];
    c.ctaCteMovements.push({
        id: `cc_${Date.now()}`,
        date: new Date().toISOString(),
        type: 'payment',
        amount: amount,
        paymentMethod: method,
        description: notes || `Abono a Cuenta Corriente (${getPaymentMethodLabel(method)})`
    });

    // Register cash inflow movement in main Cash module
    if (!state.cashMovements) state.cashMovements = [];
    state.cashMovements.push({
        id: `cm_${Date.now()}`,
        date: new Date().toISOString(),
        type: 'inflow',
        amount: amount,
        concept: `Cobro Cta. Cte. - ${c.name}`,
        notes: notes || `Cobro de deuda de cliente vía ${getPaymentMethodLabel(method)}`
    });

    saveDatabase();
    closeModal('modal-customer-payment');
    renderCustomers();
    if (window.location.hash === '#caja' && typeof renderCaja === 'function') {
        renderCaja();
    }

    playScanSound('success');
    let debtStatusMsg = '';
    if (c.deuda > 0) {
        debtStatusMsg = `Saldo deudor restante: ${state.settings.currency}${c.deuda.toFixed(2)}`;
    } else if (c.deuda < 0) {
        debtStatusMsg = `Saldo a favor generado: ${state.settings.currency}${Math.abs(c.deuda).toFixed(2)}`;
    } else {
        debtStatusMsg = `Cuenta al día (${state.settings.currency}0.00)`;
    }
    alert(`✅ ¡Abono de ${state.settings.currency}${amount.toFixed(2)} registrado con éxito para ${c.name}!\n${debtStatusMsg}.`);
};

let currentMovementsCustomerId = null;

window.openCustomerMovementsModal = function (customerId) {
    const c = state.customers.find(cust => cust.id === customerId);
    if (!c) return;

    currentMovementsCustomerId = customerId;

    document.getElementById('cust-mov-name').textContent = c.name;
    document.getElementById('cust-mov-info').textContent = `DNI/CUIT: ${c.dni || 'Sin registro'} | Teléfono: ${c.phone || 'Sin registro'}`;
    const debt = c.deuda || 0;
    const debtEl = document.getElementById('cust-mov-debt-display');
    if (debt > 0) {
        debtEl.textContent = `${state.settings.currency}${debt.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (Deuda)`;
        debtEl.style.color = 'var(--danger)';
    } else if (debt < 0) {
        debtEl.textContent = `${state.settings.currency}${Math.abs(debt).toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} (A Favor)`;
        debtEl.style.color = 'var(--success)';
    } else {
        debtEl.textContent = `${state.settings.currency}0.00 (Al día)`;
        debtEl.style.color = 'var(--text-muted)';
    }

    const tbody = document.getElementById('cust-movements-tbody');
    const movements = [...(c.ctaCteMovements || [])].sort((a, b) => new Date(b.date) - new Date(a.date));

    if (movements.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-muted" style="padding: 30px;">
                    No hay registros de movimientos en la Cuenta Corriente de este cliente.
                </td>
            </tr>
        `;
    } else {
        let rowsHtml = '';
        movements.forEach(m => {
            const dateFormatted = new Date(m.date).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' });
            const isCharge = m.type === 'charge';
            const badge = isCharge 
                ? `<span class="badge badge-danger">Cargo (Compra)</span>` 
                : `<span class="badge badge-success">Abono (Pago)</span>`;
            const amountFormatted = isCharge 
                ? `+${state.settings.currency}${m.amount.toFixed(2)}` 
                : `-${state.settings.currency}${m.amount.toFixed(2)}`;
            const amountColor = isCharge ? 'color: var(--danger); font-weight: 700;' : 'color: var(--success); font-weight: 700;';

            rowsHtml += `
                <tr>
                    <td>${dateFormatted}</td>
                    <td>${badge}</td>
                    <td>${m.description || m.concept || '-'}</td>
                    <td class="text-right" style="${amountColor}">${amountFormatted}</td>
                </tr>
            `;
        });
        tbody.innerHTML = rowsHtml;
    }

    openModal('modal-customer-movements');
};

window.printCustomerStatement = function () {
    if (!currentMovementsCustomerId) return;
    const c = state.customers.find(cust => cust.id === currentMovementsCustomerId);
    if (!c) return;

    const movements = [...(c.ctaCteMovements || [])].sort((a, b) => new Date(a.date) - new Date(b.date));
    let printContent = `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 700px; margin: auto;">
            <div style="text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px;">
                <h2 style="margin: 0; text-transform: uppercase;">${state.settings.storeName || 'DH Motopartes'}</h2>
                <h4 style="margin: 5px 0 0 0; color: #555;">ESTADO DE CUENTA CORRIENTE DE CLIENTE</h4>
            </div>
            <div style="margin-bottom: 20px;">
                <p style="margin: 4px 0;"><strong>Cliente:</strong> ${c.name}</p>
                <p style="margin: 4px 0;"><strong>DNI / CUIT:</strong> ${c.dni || 'Sin documento'}</p>
                <p style="margin: 4px 0;"><strong>Teléfono:</strong> ${c.phone || '-'}</p>
                <p style="margin: 4px 0; font-size: 16px;"><strong>Saldo Actual:</strong> ${(c.deuda || 0) > 0 ? `<span style="color: red;">$${(c.deuda || 0).toFixed(2)} (Saldo Deudor)</span>` : ((c.deuda || 0) < 0 ? `<span style="color: green;">$${Math.abs(c.deuda || 0).toFixed(2)} (Saldo a Favor)</span>` : `<span style="color: #666;">$0.00 (Al día)</span>`)}</p>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px;">
                <thead>
                    <tr style="background: #f2f2f2; border-bottom: 2px solid #ccc;">
                        <th style="padding: 8px; text-align: left;">Fecha</th>
                        <th style="padding: 8px; text-align: left;">Tipo</th>
                        <th style="padding: 8px; text-align: left;">Descripción</th>
                        <th style="padding: 8px; text-align: right;">Monto</th>
                    </tr>
                </thead>
                <tbody>
    `;

    movements.forEach(m => {
        const dateFormatted = new Date(m.date).toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' });
        const isCharge = m.type === 'charge';
        const typeStr = isCharge ? 'Cargo' : 'Abono';
        const sign = isCharge ? '+' : '-';
        printContent += `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 8px;">${dateFormatted}</td>
                <td style="padding: 8px;">${typeStr}</td>
                <td style="padding: 8px;">${m.description || '-'}</td>
                <td style="padding: 8px; text-align: right; font-weight: bold; color: ${isCharge ? '#d32f2f' : '#388e3c'};">${sign}$${m.amount.toFixed(2)}</td>
            </tr>
        `;
    });

    printContent += `
                </tbody>
            </table>
            <div style="margin-top: 40px; text-align: center; font-size: 11px; color: #777;">
                Documento emitido el ${new Date().toLocaleString('es-AR')} - ${state.settings.storeName}
            </div>
        </div>
    `;

    const printWin = window.open('', '_blank');
    printWin.document.write(`<html><head><title>Estado de Cuenta - ${c.name}</title></head><body>${printContent}</body></html>`);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => {
        printWin.print();
        printWin.close();
    }, 250);
};

window.deleteCustomer = function (id) {
    if (confirm("¿Deseas eliminar a este cliente de la base de datos? Sus puntos acumulados y registro de cuenta corriente se perderán.")) {
        state.customers = state.customers.filter(c => c.id !== id);
        saveDatabase();
        renderCustomers();
        playScanSound('fail');
    }
};

/* ==========================================================================
   4.5. SUPPLIERS VIEW CONTROLLER
   ========================================================================== */
function renderSuppliers() {
    renderSuppliersTable();
    updateSuppliersMetrics();
}

function updateSuppliersMetrics() {
    const suppliersList = state.suppliers || [];
    const totalCount = suppliersList.length;
    
    let totalDebt = 0;
    let indebtedCount = 0;
    
    suppliersList.forEach(s => {
        const debtVal = parseFloat(s.debt) || 0;
        if (debtVal > 0) {
            totalDebt += debtVal;
            indebtedCount++;
        }
    });

    const countEl = document.getElementById('suppliers-metric-count');
    const debtEl = document.getElementById('suppliers-metric-total-debt');
    const indebtedEl = document.getElementById('suppliers-metric-indebted-count');

    if (countEl) countEl.textContent = totalCount;
    if (debtEl) {
        const currency = (state.settings && state.settings.currency) || "$";
        debtEl.textContent = `${currency}${totalDebt.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    if (indebtedEl) indebtedEl.textContent = `${indebtedCount} proveedores con deuda`;
}

function renderSuppliersTable() {
    const searchInput = document.getElementById('suppliers-search');
    const searchVal = searchInput ? searchInput.value.toLowerCase() : '';
    const tbody = document.getElementById('suppliers-table-body');
    if (!tbody) return;

    const filtered = (state.suppliers || []).filter(s => {
        return (s.name || '').toLowerCase().includes(searchVal) ||
            (s.contactName || '').toLowerCase().includes(searchVal) ||
            (s.phone && s.phone.includes(searchVal)) ||
            (s.email && s.email.toLowerCase().includes(searchVal));
    });

    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (suppliersPage > totalPages) suppliersPage = totalPages;

    const startIdx = (suppliersPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageItems = filtered.slice(startIdx, endIdx);

    if (pageItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center text-muted" style="padding: 40px;">
                    No se registran proveedores en el sistema.
                </td>
            </tr>
        `;
        const pagEl = document.getElementById('suppliers-pagination');
        if (pagEl) pagEl.innerHTML = '';
        return;
    }

    const currency = (state.settings && state.settings.currency) || "$";
    let rowsHtml = '';
    pageItems.forEach(s => {
        const debtVal = parseFloat(s.debt) || 0;
        const formattedDebt = `${currency}${debtVal.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        const debtClass = debtVal > 0 ? 'text-danger font-bold' : 'text-muted';

        rowsHtml += `
            <tr>
                <td>${s.id}</td>
                <td style="font-weight: 600;">
                    ${s.name}
                    ${s.notes ? `<div style="font-size: 11px; color: var(--text-muted); font-weight: normal; margin-top: 2px;">Nota: ${s.notes}</div>` : ''}
                </td>
                <td>${s.contactName || '<span class="text-muted">—</span>'}</td>
                <td>${s.phone || '<span class="text-muted">—</span>'}</td>
                <td>${s.email || '<span class="text-muted">—</span>'}</td>
                <td class="text-right ${debtClass}" style="font-weight: 700;">${formattedDebt}</td>
                <td class="text-center">
                    <div class="table-action-btn-group">
                        <button class="btn btn-emerald btn-outline btn-icon-only" onclick="openSupplierPayment('${s.id}')" title="Registrar Pago"><i data-lucide="hand-coins" style="width:14px; height:14px;"></i></button>
                        <button class="btn btn-secondary btn-icon-only" onclick="editSupplier('${s.id}')" title="Editar"><i data-lucide="edit-3" style="width:14px; height:14px;"></i></button>
                        <button class="btn btn-danger btn-outline btn-icon-only" onclick="deleteSupplier('${s.id}')" title="Eliminar"><i data-lucide="trash-2" style="width:14px; height:14px;"></i></button>
                    </div>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    const pagEl = document.getElementById('suppliers-pagination');
    if (pagEl) {
        pagEl.innerHTML = `
            <span>Mostrando registros ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
            <div class="flex-align-center" style="gap: 8px;">
                <button class="btn btn-secondary btn-icon-only" onclick="changeSuppliersPage(-1)" ${suppliersPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
                <span>Pág. ${suppliersPage} de ${totalPages}</span>
                <button class="btn btn-secondary btn-icon-only" onclick="changeSuppliersPage(1)" ${suppliersPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
            </div>
        `;
    }

    if (window.lucide) lucide.createIcons();
}

window.changeSuppliersPage = function (delta) {
    suppliersPage += delta;
    renderSuppliersTable();
};

function saveSupplier(e) {
    e.preventDefault();

    const id = document.getElementById('supplier-id-field').value;
    const name = document.getElementById('supp-name').value.trim();
    const contactName = document.getElementById('supp-contact').value.trim();
    const phone = document.getElementById('supp-phone').value.trim();
    const email = document.getElementById('supp-email').value.trim();
    const address = document.getElementById('supp-address').value.trim();
    const debt = parseFloat(document.getElementById('supp-debt').value) || 0;
    const notes = document.getElementById('supp-notes').value.trim();

    if (!state.suppliers) state.suppliers = [];

    if (!id) {
        // Create new
        state.suppliers.push({
            id: `s_${Date.now()}`,
            name,
            contactName,
            phone,
            email,
            address,
            debt,
            notes,
            dateRegistered: new Date().toISOString().split('T')[0]
        });
    } else {
        // Edit existing
        const supplier = state.suppliers.find(s => s.id === id);
        if (supplier) {
            supplier.name = name;
            supplier.contactName = contactName;
            supplier.phone = phone;
            supplier.email = email;
            supplier.address = address;
            supplier.debt = debt;
            supplier.notes = notes;
        }
    }

    saveDatabase();
    closeModal('modal-supplier');
    renderSuppliers();
    playScanSound('success');
}

window.editSupplier = function (id) {
    const s = state.suppliers.find(supp => supp.id === id);
    if (!s) return;

    document.getElementById('supplier-modal-title').textContent = "Editar Proveedor";
    document.getElementById('supplier-id-field').value = s.id;
    document.getElementById('supp-name').value = s.name;
    document.getElementById('supp-contact').value = s.contactName || '';
    document.getElementById('supp-phone').value = s.phone || '';
    document.getElementById('supp-email').value = s.email || '';
    document.getElementById('supp-address').value = s.address || '';
    document.getElementById('supp-debt').value = s.debt || 0;
    document.getElementById('supp-notes').value = s.notes || '';

    openModal('modal-supplier');
};

window.deleteSupplier = function (id) {
    if (confirm("¿Deseas eliminar a este proveedor de la base de datos?")) {
        state.suppliers = state.suppliers.filter(s => s.id !== id);
        saveDatabase();
        renderSuppliers();
        playScanSound('fail');
    }
};

window.openSupplierPayment = function (id) {
    const s = state.suppliers.find(supp => supp.id === id);
    if (!s) return;

    document.getElementById('supp-pay-id-field').value = s.id;
    document.getElementById('supp-pay-name').textContent = s.name;

    const currency = (state.settings && state.settings.currency) || "$";
    const debtVal = parseFloat(s.debt) || 0;
    document.getElementById('supp-pay-current-debt').textContent = `${currency}${debtVal.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    document.getElementById('supp-pay-amount').value = "";
    document.getElementById('supp-pay-amount').max = debtVal;
    document.getElementById('supp-pay-outflow-check').checked = true;

    openModal('modal-supplier-payment');
};

window.processSupplierPayment = function (e) {
    e.preventDefault();

    const id = document.getElementById('supp-pay-id-field').value;
    const amount = parseFloat(document.getElementById('supp-pay-amount').value) || 0;
    const logOutflow = document.getElementById('supp-pay-outflow-check').checked;

    if (amount <= 0) return;

    const supplier = state.suppliers.find(s => s.id === id);
    if (!supplier) return;

    const previousDebt = parseFloat(supplier.debt) || 0;
    supplier.debt = Math.max(0, previousDebt - amount);

    // Register as cash outflow if selected
    if (logOutflow) {
        if (!state.cashMovements) state.cashMovements = [];
        state.cashMovements.push({
            id: `cm_${Date.now()}`,
            date: new Date().toISOString(),
            type: "outflow",
            amount: amount,
            concept: `Pago a Proveedor: ${supplier.name}`,
            notes: `Abono de deuda. Saldo anterior: $${previousDebt.toFixed(2)}. Saldo restante: $${supplier.debt.toFixed(2)}.`
        });
    }

    saveDatabase();
    closeModal('modal-supplier-payment');
    renderSuppliers();
    playScanSound('success');
};

/* ==========================================================================
   5. SALES HISTORY VIEW CONTROLLER
   ========================================================================== */
let activeReceiptId = '';

async function renderHistory() {
    const tbody = document.getElementById('history-table-body');
    
    // Show Negocio column header if saas_admin or superadmin
    const negocioHeader = document.getElementById('history-header-negocio');
    if (negocioHeader) {
        if (currentUserRole === 'saas_admin' || currentUserRole === 'superadmin') {
            negocioHeader.style.display = '';
        } else {
            negocioHeader.style.display = 'none';
        }
    }

    if (currentUserRole === 'saas_admin') {
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9" class="text-center text-muted" style="padding: 40px;">
                        <i data-lucide="loader" class="animate-spin" style="animation: spin 1s linear infinite; margin-right: 8px;"></i>
                        Cargando ventas de todos los negocios...
                    </td>
                </tr>
            `;
            if (window.lucide) lucide.createIcons();
        }

        try {
            // Fetch stores to map store_id to name
            const { data: stores, error: storesError } = await supabaseClient
                .from('stores')
                .select('id, name');

            if (storesError) throw storesError;

            // Fetch all store states
            const { data: statesList, error: statesError } = await supabaseClient
                .from('store_states')
                .select('store_id, state');

            if (statesError) throw statesError;

            const storeMap = {};
            if (stores) {
                stores.forEach(st => {
                    storeMap[st.id] = st.name;
                });
            }

            let allSales = [];
            if (statesList) {
                statesList.forEach(item => {
                    const storeId = item.store_id;
                    const storeName = storeMap[storeId] || (item.state && item.state.settings && item.state.settings.storeName) || 'Bigtech';
                    if (item.state && Array.isArray(item.state.sales)) {
                        item.state.sales.forEach(sale => {
                            allSales.push({
                                ...sale,
                                storeName: storeName,
                                storeId: storeId,
                                storeSettings: item.state.settings
                            });
                        });
                    }
                });
            }

            // Assign to global state.sales so that filtering/pagination/exporting works seamlessly
            state.sales = allSales;
        } catch (err) {
            console.error("Error al cargar el historial global de ventas:", err);
            if (tbody) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="9" class="text-center text-danger" style="padding: 40px;">
                            Error al cargar el historial de ventas: ${err.message}
                        </td>
                    </tr>
                `;
            }
            return;
        }
    }

    renderHistoryTable();
}

function renderHistoryTable() {
    const searchVal = document.getElementById('history-search').value.toLowerCase();
    const startVal = document.getElementById('history-filter-start').value;
    const endVal = document.getElementById('history-filter-end').value;
    const statusVal = document.getElementById('history-filter-status').value;
    const tbody = document.getElementById('history-table-body');
    
    // Determine colspan based on role (9 for saas_admin and superadmin, 8 for others)
    const showNegocio = (currentUserRole === 'saas_admin' || currentUserRole === 'superadmin');
    const totalCols = showNegocio ? 9 : 8;

    const filtered = state.sales.filter(s => {
        const matchesSearch = s.id.toLowerCase().includes(searchVal) ||
            s.customerName.toLowerCase().includes(searchVal);

        const matchesStatus = !statusVal || s.status === statusVal;

        let matchesDates = true;
        if (startVal) {
            const startDate = new Date(startVal);
            startDate.setHours(0, 0, 0, 0);
            matchesDates = matchesDates && (new Date(s.date) >= startDate);
        }
        if (endVal) {
            const endDate = new Date(endVal);
            endDate.setHours(23, 59, 59, 999);
            matchesDates = matchesDates && (new Date(s.date) <= endDate);
        }

        return matchesSearch && matchesStatus && matchesDates;
    }).sort((a, b) => new Date(b.date) - new Date(a.date)); // Sort desc (recent first)

    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (historyPage > totalPages) historyPage = totalPages;

    const startIdx = (historyPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageItems = filtered.slice(startIdx, endIdx);

    if (pageItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="${totalCols}" class="text-center text-muted" style="padding: 40px;">
                    No se encontraron transacciones registradas.
                </td>
            </tr>
        `;
        document.getElementById('history-pagination').innerHTML = '';
        return;
    }

    let rowsHtml = '';
    pageItems.forEach(s => {
        const itemsCount = s.items.reduce((sum, item) => sum + item.quantity, 0);

        let statusBadge = 'success';
        let statusText = 'Completada';
        if (s.status === 'voided') {
            statusBadge = 'danger';
            statusText = 'Anulada';
        }

        let fiscalBadgeHtml = '';
        if (s.estado_fiscal === 'emitido') {
            fiscalBadgeHtml = `
                <div style="font-size: 11px; margin-top: 5px; color: var(--success); font-weight: 600;">
                    📄 Factura: ${s.nro_comprobante}
                </div>
            `;
        } else if (s.estado_fiscal === 'pendiente') {
            fiscalBadgeHtml = `
                <div style="font-size: 11px; margin-top: 5px; color: var(--warning); display: flex; align-items: center; justify-content: center; gap: 4px; font-weight: 600;">
                    <span>⚠️ Pendiente</span>
                    <button class="btn btn-secondary btn-icon-only" style="padding: 1px 3px; font-size: 9px; height: auto; width: auto; min-width: 0;" onclick="event.stopPropagation(); retryInvoicing('${s.id}')" title="Reintentar Facturar">
                        <i data-lucide="refresh-cw" style="width: 10px; height: 10px;"></i>
                    </button>
                </div>
            `;
        }

        rowsHtml += `
            <tr>
                <td style="font-weight: 700; color: var(--primary);">${s.id}</td>
                <td>${new Date(s.date).toLocaleString('es-ES')}</td>
                ${showNegocio ? `<td>${s.storeName || (state.settings && state.settings.storeName) || 'Bigtech'}</td>` : ''}
                <td style="font-weight: 500;">${s.customerName}</td>
                <td>${itemsCount} artículos</td>
                <td class="text-right" style="font-weight: 700;">${state.settings.currency}${s.total.toFixed(2)}</td>
                <td>${getPaymentMethodLabel(s.paymentMethod, true)}</td>
                <td class="text-center">
                    <span class="badge badge-${statusBadge}">${statusText}</span>
                    ${fiscalBadgeHtml}
                </td>
                <td class="text-center">
                    <button class="btn btn-secondary" onclick="viewSaleDetail('${s.id}')">
                        <i data-lucide="eye" style="width:13px; height:13px;"></i> Detalle
                    </button>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    document.getElementById('history-pagination').innerHTML = `
        <span>Mostrando registros ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
        <div class="flex-align-center" style="gap: 8px;">
            <button class="btn btn-secondary btn-icon-only" onclick="changeHistoryPage(-1)" ${historyPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
            <span>Pág. ${historyPage} de ${totalPages}</span>
            <button class="btn btn-secondary btn-icon-only" onclick="changeHistoryPage(1)" ${historyPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

window.changeHistoryPage = function (delta) {
    historyPage += delta;
    renderHistoryTable();
};

window.retryInvoicing = async function (saleId) {
    const sale = state.sales.find(s => s.id === saleId);
    if (!sale) return;
    
    if (sale.estado_fiscal !== 'pendiente') {
        alert("Esta venta no tiene una facturación pendiente.");
        return;
    }

    const confirmRetry = confirm(`¿Deseas reintentar la facturación electrónica de la venta ${saleId}?`);
    if (!confirmRetry) return;

    try {
        const fiscalConfig = await loadFiscalConfig();
        if (!fiscalConfig || !fiscalConfig.cuit) {
            throw new Error("No hay configuración fiscal cargada para esta tienda. Por favor confígurala en Ajustes.");
        }

        const result = await facturador.emitirComprobante(sale, fiscalConfig);
        if (result.success) {
            sale.estado_fiscal = "emitido";
            sale.nro_comprobante = result.nroComprobante;
            sale.cae = result.cae;
            sale.cae_vto = result.caeFchVto;
            delete sale.error_fiscal;
            
            await saveDatabase();
            alert("¡Facturación electrónica emitida con éxito!\nCAE: " + result.cae);
            
            renderHistory();
            if (activeReceiptId === saleId) {
                viewSaleDetail(saleId);
            }
        } else {
            throw new Error(result.error || "Error desconocido.");
        }
    } catch (err) {
        alert("Error al reintentar facturación: " + err.message);
        sale.error_fiscal = err.message;
        await saveDatabase();
        renderHistory();
    }
};

window.viewSaleDetail = function (saleId) {
    const sale = state.sales.find(s => s.id === saleId);
    if (!sale) return;

    activeReceiptId = saleId;

    // Hide/show refund button depending on status and role
    const voidBtn = document.getElementById('receipt-void-btn');
    if (sale.status === 'voided' || currentUserRole === 'saas_admin' || currentUserRole === 'superadmin') {
        voidBtn.style.display = 'none';
    } else {
        voidBtn.style.display = 'inline-flex';
    }

    const container = document.getElementById('receipt-modal-content');
    container.innerHTML = renderReceipt(sale, sale.storeSettings || state.settings);

    openModal('modal-receipt');
};

// Void a sale (returns products back to stock)
function voidSale() {
    if (!activeReceiptId) return;

    const sale = state.sales.find(s => s.id === activeReceiptId);
    if (!sale || sale.status === 'voided') return;

    if (confirm(`¿Estás seguro de que deseas ANULAR la venta ${activeReceiptId}? Se devolverán los artículos al stock del inventario.`)) {
        // Return products to inventory
        sale.items.forEach(item => {
            const prod = state.products.find(p => p.id === item.id);
            if (prod) {
                if (prod.isCombo && prod.components) {
                    prod.components.forEach(comp => {
                        const compProd = state.products.find(p => p.id === comp.id);
                        if (compProd) {
                            compProd.stock = Math.round((compProd.stock + (comp.quantity * item.quantity)) * 1000) / 1000;
                        }
                    });
                } else {
                    prod.stock = Math.round((prod.stock + item.quantity) * 1000) / 1000;
                }
            }
        });

        // Deduct points from loyalty customer
        if (sale.customerId) {
            const customer = state.customers.find(c => c.id === sale.customerId);
            if (customer) {
                const pointsToDeduct = Math.floor(sale.total / 100);
                customer.points = Math.max(0, customer.points - pointsToDeduct);
            }
        }

        sale.status = 'voided';

        saveDatabase();
        closeModal('modal-receipt');
        renderHistory();
        playScanSound('fail');
        alert(`Venta ${activeReceiptId} anulada con éxito. Stock devuelto.`);
    }
}

/* ==========================================================================
   6. SETTINGS VIEW CONTROLLER
   ========================================================================== */
function saveSettings(e) {
    e.preventDefault();

    const storeName = document.getElementById('set-store-name').value.trim();
    const storeAddress = document.getElementById('set-store-address').value.trim();
    const storePhone = document.getElementById('set-store-phone').value.trim();
    const whatsapp = document.getElementById('set-store-whatsapp').value.trim();
    const instagram = document.getElementById('set-store-instagram').value.trim();
    const brandDescription = document.getElementById('set-store-description').value.trim();
    const storeAlias = document.getElementById('set-store-alias') ? document.getElementById('set-store-alias').value.trim() : 'DHMOTOPARTES';
    const storeHolder = document.getElementById('set-store-holder') ? document.getElementById('set-store-holder').value.trim() : 'DANIEL OSCAR HIDALGO';
    const currency = document.getElementById('set-store-currency').value.trim();
    const storeTax = parseFloat(document.getElementById('set-store-tax').value) || 0;
    const geminiApiKey = document.getElementById('set-gemini-api-key') ? document.getElementById('set-gemini-api-key').value.trim() : (state.settings.geminiApiKey || '');

    const cardBgType = document.getElementById('set-card-bg-type').value;
    const cardBgColor = document.getElementById('set-card-bg-color').value;
    const cardBgColorHover = document.getElementById('set-card-bg-hover').value;

    const theme = document.body.classList.contains('light-theme') ? 'light' : 'dark';
    const activeDot = document.querySelector('#accent-pickers-container .color-dot.active');
    const accentColor = activeDot ? activeDot.dataset.color : 'violet';

    if (tempLogoBase64 !== null) {
        state.settings.logo = tempLogoBase64;
    }
    if (tempCardBgImageBase64 !== null) {
        state.settings.cardBgImage = tempCardBgImageBase64;
    }

    state.settings = {
        ...state.settings,
        storeName,
        storeAddress,
        storePhone,
        storeAlias,
        storeHolder,
        currency,
        storeTax,
        cardBgType,
        cardBgColor,
        cardBgColorHover,
        theme,
        accentColor,
        whatsapp,
        instagram,
        brandDescription,
        geminiApiKey
    };

    // Apply brand settings dynamically
    applyBrandSettings();

    saveDatabase();
    playScanSound('success');
    alert("Configuración de la empresa y diseño visual guardados con éxito.");
}

function applyBrandSettings() {
    if (!state.settings) return;

    // Apply theme & accent
    applyThemeMode(state.settings.theme || 'dark');
    applyAccentTheme(state.settings.accentColor || 'violet');

    let storeName = state.settings.storeName || "Bigtech";
    if (currentUserRole === 'saas_admin') {
        if (activeSaasStoreSettings) {
            storeName = activeSaasStoreSettings.storeName || "Bigtech";
        } else {
            storeName = "Bigtech";
        }
    }

    // Update page title
    document.title = `${storeName} - Control de Ventas e Inventario`;

    // Sync header/sidebar text displays
    const storeNameSidebar = document.getElementById('store-name-sidebar');
    if (storeNameSidebar) {
        storeNameSidebar.textContent = storeName;
    }
    const headerStoreName = document.getElementById('header-store-name');
    if (headerStoreName) {
        headerStoreName.textContent = storeName;
    }

    const logoTitleSidebar = document.getElementById('logo-title-sidebar');
    if (logoTitleSidebar) {
        logoTitleSidebar.innerHTML = storeName;
    }
    const logoTitleLogin = document.getElementById('logo-title-login');
    if (logoTitleLogin) {
        logoTitleLogin.innerHTML = storeName;
    }
    const catalogStoreName = document.getElementById('catalog-store-name');
    if (catalogStoreName) {
        catalogStoreName.textContent = storeName;
    }

    // Sync store settings form inputs
    const aliasInput = document.getElementById('set-store-alias');
    if (aliasInput) {
        aliasInput.value = state.settings.storeAlias || 'DHMOTOPARTES';
    }
    const holderInput = document.getElementById('set-store-holder');
    if (holderInput) {
        holderInput.value = state.settings.storeHolder || 'DANIEL OSCAR HIDALGO';
    }
    const catDisplayAlias = document.getElementById('cat-display-alias');
    if (catDisplayAlias) {
        catDisplayAlias.textContent = state.settings.storeAlias || 'DHMOTOPARTES';
    }
    const catDisplayHolder = document.getElementById('cat-display-holder');
    if (catDisplayHolder) {
        catDisplayHolder.textContent = state.settings.storeHolder || 'DANIEL OSCAR HIDALGO';
    }

    // Render description, whatsapp and instagram in public catalog
    const catalogDescText = document.getElementById('catalog-description-text');
    const catalogWhatsappLink = document.getElementById('catalog-whatsapp-link');
    const catalogInstagramLink = document.getElementById('catalog-instagram-link');
    const catalogInfoCard = document.getElementById('catalog-info-card');

    let hasInfo = false;

    if (catalogDescText) {
        const desc = state.settings.brandDescription || "";
        if (desc) {
            catalogDescText.textContent = desc;
            catalogDescText.style.display = 'block';
            hasInfo = true;
        } else {
            catalogDescText.style.display = 'none';
        }
    }

    if (catalogWhatsappLink) {
        let wa = state.settings.whatsapp || "";
        if (wa) {
            wa = wa.trim();
            let waUrl = wa;
            if (!wa.startsWith('http://') && !wa.startsWith('https://')) {
                const digits = wa.replace(/[^\d+]/g, '');
                waUrl = `https://wa.me/${digits.replace('+', '')}`;
            }
            catalogWhatsappLink.href = waUrl;
            catalogWhatsappLink.style.display = 'inline-flex';
            hasInfo = true;
        } else {
            catalogWhatsappLink.style.display = 'none';
        }
    }

    if (catalogInstagramLink) {
        let ig = state.settings.instagram || "";
        if (ig) {
            ig = ig.trim();
            let igUrl = ig;
            if (!ig.startsWith('http://') && !ig.startsWith('https://')) {
                const username = ig.replace('@', '');
                igUrl = `https://instagram.com/${username}`;
            }
            catalogInstagramLink.href = igUrl;
            catalogInstagramLink.style.display = 'inline-flex';
            hasInfo = true;
        } else {
            catalogInstagramLink.style.display = 'none';
        }
    }

    if (catalogInfoCard) {
        catalogInfoCard.style.display = hasInfo ? 'flex' : 'none';
    }

    if (window.lucide && hasInfo) {
        lucide.createIcons();
    }

    // Logo handling
    const logoUrl = (currentUserRole === 'saas_admin' && activeSaasStoreSettings) ? (activeSaasStoreSettings.logo || "") : state.settings.logo;
    const sidebarLogoIcon = document.getElementById('logo-icon-container');
    const sidebarLogoDefault = document.getElementById('logo-icon-default');
    const sidebarLogoImg = document.getElementById('logo-icon-img');

    const loginLogoIcon = document.getElementById('login-logo-container');
    const loginLogoDefault = document.getElementById('login-logo-default');
    const loginLogoImg = document.getElementById('login-logo-img');

    const catalogLogoIcon = document.getElementById('catalog-logo-container');
    const catalogLogoDefault = document.getElementById('catalog-logo-default');
    const catalogLogoImg = document.getElementById('catalog-logo-img');

    const headerLogoDefault = document.getElementById('header-store-icon-default');
    const headerLogoImg = document.getElementById('header-store-logo-img');

    if (logoUrl) {
        // Display custom logo image
        if (sidebarLogoIcon) sidebarLogoIcon.classList.add('has-custom-logo');
        if (sidebarLogoDefault) sidebarLogoDefault.style.display = 'none';
        if (sidebarLogoImg) {
            sidebarLogoImg.src = logoUrl;
            sidebarLogoImg.style.display = 'block';
        }

        if (loginLogoIcon) loginLogoIcon.classList.add('has-custom-logo');
        if (loginLogoDefault) loginLogoDefault.style.display = 'none';
        if (loginLogoImg) {
            loginLogoImg.src = logoUrl;
            loginLogoImg.style.display = 'block';
        }

        if (catalogLogoIcon) catalogLogoIcon.classList.add('has-custom-logo');
        if (catalogLogoDefault) catalogLogoDefault.style.display = 'none';
        if (catalogLogoImg) {
            catalogLogoImg.src = logoUrl;
            catalogLogoImg.style.display = 'block';
        }

        if (headerLogoDefault) headerLogoDefault.style.display = 'none';
        if (headerLogoImg) {
            headerLogoImg.src = logoUrl;
            headerLogoImg.style.display = 'block';
        }
    } else {
        // Default wrench icon
        if (sidebarLogoIcon) sidebarLogoIcon.classList.remove('has-custom-logo');
        if (sidebarLogoDefault) sidebarLogoDefault.style.display = 'block';
        if (sidebarLogoImg) sidebarLogoImg.style.display = 'none';

        if (loginLogoIcon) loginLogoIcon.classList.remove('has-custom-logo');
        if (loginLogoDefault) loginLogoDefault.style.display = 'block';
        if (loginLogoImg) loginLogoImg.style.display = 'none';

        if (catalogLogoIcon) catalogLogoIcon.classList.remove('has-custom-logo');
        if (catalogLogoDefault) catalogLogoDefault.style.display = 'block';
        if (catalogLogoImg) catalogLogoImg.style.display = 'none';

        if (headerLogoDefault) headerLogoDefault.style.display = 'block';
        if (headerLogoImg) headerLogoImg.style.display = 'none';
    }

    // Card custom styles logic
    const bgType = state.settings.cardBgType || 'default';
    const bgColor = state.settings.cardBgColor || '#1f2937';
    const bgHover = state.settings.cardBgColorHover || '#26354a';
    const bgImage = state.settings.cardBgImage || '';

    let dynamicCss = '';

    if (bgType === 'glass') {
        dynamicCss = `
            :root {
                --bg-card: rgba(30, 41, 59, 0.75) !important;
                --bg-card-hover: rgba(30, 41, 59, 0.85) !important;
                --border-color: rgba(255, 255, 255, 0.08) !important;
            }
            body.light-theme {
                --bg-card: rgba(255, 255, 255, 0.8) !important;
                --bg-card-hover: rgba(255, 255, 255, 0.9) !important;
                --border-color: rgba(15, 23, 42, 0.08) !important;
            }
            .metric-card, .dashboard-panel, .prod-card, .data-table-card, .data-op-card, .login-card {
                backdrop-filter: blur(14px) !important;
                -webkit-backdrop-filter: blur(14px) !important;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05) !important;
            }
        `;
    } else if (bgType === 'aurora') {
        dynamicCss = `
            :root {
                --bg-card: linear-gradient(135deg, rgba(30, 41, 59, 0.95) 0%, rgba(249, 115, 22, 0.06) 100%) !important;
                --bg-card-hover: linear-gradient(135deg, rgba(38, 53, 74, 0.95) 0%, rgba(249, 115, 22, 0.1) 100%) !important;
                --border-color: rgba(249, 115, 22, 0.25) !important;
                --border-hover: rgba(249, 115, 22, 0.45) !important;
            }
            body.light-theme {
                --bg-card: linear-gradient(135deg, #ffffff 0%, rgba(249, 115, 22, 0.04) 100%) !important;
                --bg-card-hover: linear-gradient(135deg, #f8fafc 0%, rgba(249, 115, 22, 0.08) 100%) !important;
                --border-color: rgba(249, 115, 22, 0.18) !important;
                --border-hover: rgba(249, 115, 22, 0.35) !important;
            }
            .metric-card, .dashboard-panel, .prod-card, .data-table-card, .data-op-card, .login-card {
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05) !important;
            }
        `;
    } else if (bgType === 'carbon') {
        dynamicCss = `
            :root {
                --bg-card: linear-gradient(135deg, #1e293b 0%, #0f172a 100%) !important;
                --bg-card-hover: linear-gradient(135deg, #273549 0%, #162030 100%) !important;
                --border-color: rgba(255, 255, 255, 0.05) !important;
                --border-hover: rgba(255, 255, 255, 0.1) !important;
            }
            body.light-theme {
                --bg-card: linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%) !important;
                --bg-card-hover: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%) !important;
                --border-color: #cbd5e1 !important;
                --border-hover: #94a3b8 !important;
            }
            .metric-card, .dashboard-panel, .prod-card, .data-table-card, .data-op-card, .login-card {
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05) !important;
            }
        `;
    } else if (bgType === 'color') {
        dynamicCss = `
            :root {
                --bg-card: ${bgColor} !important;
                --bg-card-hover: ${bgHover} !important;
            }
        `;
    } else if (bgType === 'image') {
        if (bgImage) {
            dynamicCss = `
                .metric-card, .dashboard-panel, .prod-card, .data-table-card, .data-op-card, .login-card {
                    background-image: url('${bgImage}') !important;
                    background-size: cover !important;
                    background-position: center !important;
                    background-repeat: no-repeat !important;
                    border-color: rgba(255, 255, 255, 0.08) !important;
                }
            `;
        }
    }

    const styleTag = document.getElementById('custom-brand-styles');
    if (styleTag) {
        styleTag.innerHTML = dynamicCss;
    }
}

// Category Management Functions
function renderCategorySettings() {
    const list = document.getElementById('settings-category-list');
    if (!list) return;

    if (!state.settings.categories) {
        state.settings.categories = ['Sistema Eléctrico', 'Repuestos de Motor', 'Frenos', 'Transmisión', 'Herramientas', 'Accesorios', 'Aceites'];
    }

    let html = '';
    state.settings.categories.forEach((cat, index) => {
        html += `
            <div class="category-item">
                <span>${cat}</span>
                <button class="btn-icon" onclick="deleteCategory(${index})" title="Eliminar categoría" style="color: var(--rose-red);">
                    <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                </button>
            </div>
        `;
    });
    list.innerHTML = html;
    if (window.lucide) lucide.createIcons();
}

window.addCategory = function () {
    const input = document.getElementById('new-category-name');
    const name = input.value.trim();
    if (!name) return;

    if (!state.settings.categories) state.settings.categories = [];
    if (state.settings.categories.includes(name)) {
        alert("La categoría ya existe.");
        return;
    }

    state.settings.categories.push(name);
    input.value = '';
    saveDatabase();
    renderCategorySettings();
    renderInventory();

    // Also re-render POS tabs if we are in POS view
    if (document.getElementById('view-pos').classList.contains('active')) {
        renderPOS();
    }
}

window.deleteCategory = function (index) {
    if (!state.settings.categories) return;

    const catName = state.settings.categories[index];
    const inUse = state.products.some(p => p.category === catName);

    if (inUse) {
        const confirmDelete = confirm(`Hay productos utilizando la categoría "${catName}". ¿Estás seguro de eliminarla? Los productos conservarán el nombre de la categoría pero ya no aparecerá en el menú principal.`);
        if (!confirmDelete) return;
    }

    state.settings.categories.splice(index, 1);
    saveDatabase();
    renderCategorySettings();
    renderInventory();

    if (document.getElementById('view-pos').classList.contains('active')) {
        renderPOS();
    }
}

/* ==========================================================================
   Public Customer Catalog Controller
   ========================================================================== */
function renderCatalog() {
    const storeName = state.settings.storeName || "Bigtech";
    const logoUrl = state.settings.logo;

    // Sync store name and logo preview elements
    const catalogStoreName = document.getElementById('catalog-store-name');
    if (catalogStoreName) catalogStoreName.textContent = storeName;

    const catalogLogoDefault = document.getElementById('catalog-logo-default');
    const catalogLogoImg = document.getElementById('catalog-logo-img');
    const catalogLogoIcon = document.getElementById('catalog-logo-container');
    if (logoUrl) {
        if (catalogLogoIcon) catalogLogoIcon.classList.add('has-custom-logo');
        if (catalogLogoDefault) catalogLogoDefault.style.display = 'none';
        if (catalogLogoImg) {
            catalogLogoImg.src = logoUrl;
            catalogLogoImg.style.display = 'block';
        }
    } else {
        if (catalogLogoIcon) catalogLogoIcon.classList.remove('has-custom-logo');
        if (catalogLogoDefault) catalogLogoDefault.style.display = 'block';
        if (catalogLogoImg) catalogLogoImg.style.display = 'none';
    }

    // Populate Category Tabs
    const tabsContainer = document.getElementById('catalog-categories-container');
    if (tabsContainer) {
        const categories = ['Todas', ...(state.settings.categories || [])];
        let tabsHtml = '';
        categories.forEach(cat => {
            const displayCat = cat === 'Todas' ? '' : cat;
            const activeClass = activeCatalogCategory === displayCat ? 'active' : '';
            tabsHtml += `
                <button class="category-tab ${activeClass}" onclick="setCatalogCategory('${displayCat}')">
                    ${cat}
                </button>
            `;
        });
        tabsContainer.innerHTML = tabsHtml;
    }

    renderCatalogProductGrid();
}

window.setCatalogCategory = function (cat) {
    activeCatalogCategory = cat;
    renderCatalog();
};

function renderCatalogProductGrid() {
    const searchVal = document.getElementById('catalog-search-input').value.toLowerCase();
    const grid = document.getElementById('catalog-products-grid');
    if (!grid) return;

    const filtered = state.products.filter(p => {
        if (p.isFractional) return false;
        const matchesCategory = !activeCatalogCategory || p.category === activeCatalogCategory;
        const matchesSearch = p.name.toLowerCase().includes(searchVal) ||
            p.sku.toLowerCase().includes(searchVal);
        return matchesCategory && matchesSearch;
    });

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div class="empty-state-small" style="grid-column: 1 / -1;">
                <i data-lucide="package-x" style="width: 48px; height: 48px; opacity: 0.3;"></i>
                <p>No se encontraron repuestos o herramientas en este catálogo.</p>
            </div>
        `;
    } else {
        let cardsHtml = '';
        filtered.forEach(p => {
            cardsHtml += createCatalogProductCard(p, state.settings.currency);
        });
        grid.innerHTML = cardsHtml;
    }

    if (window.lucide) lucide.createIcons();
}

// Export database as JSON file download
function exportJSONBackup() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `aurapos_backup_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    playScanSound('success');
}

// Restore database from JSON backup upload
function importJSONBackup(e) {
    const fileReader = new FileReader();
    fileReader.onload = function (event) {
        try {
            const parsedData = JSON.parse(event.target.result);

            // Validate schema
            if (parsedData.products && parsedData.sales && parsedData.customers && parsedData.settings) {
                state = parsedData;
                saveDatabase();
                syncSettingsInputs(); // sync settings inputs
                renderApp();
                playScanSound('success');
                alert("Base de datos restaurada con éxito.");
            } else {
                throw new Error("El archivo no contiene el formato correcto de AuraPOS.");
            }
        } catch (error) {
            playScanSound('fail');
            alert(`Error al importar el archivo: ${error.message}`);
        }
    };
    if (e.target.files[0]) {
        fileReader.readAsText(e.target.files[0]);
    }
}

// Export sales logs as a CSV file
function exportSalesCSV() {
    if (state.sales.length === 0) {
        alert("No se registran ventas para exportar.");
        return;
    }

    // CSV Headers
    let csvContent = "data:text/csv;charset=utf-8,";
    const showNegocio = (currentUserRole === 'saas_admin' || currentUserRole === 'superadmin');
    if (showNegocio) {
        csvContent += "Folio,Fecha,Negocio,Cliente,Subtotal,Descuento,Impuestos,Total,Metodo Pago,Estado\r\n";
    } else {
        csvContent += "Folio,Fecha,Cliente,Subtotal,Descuento,Impuestos,Total,Metodo Pago,Estado\r\n";
    }

    state.sales.forEach(s => {
        const row = [
            s.id,
            new Date(s.date).toISOString().replace('T', ' ').slice(0, 19)
        ];
        if (showNegocio) {
            row.push(`"${s.storeName || (state.settings && state.settings.storeName) || 'Bigtech'}"`);
        }
        row.push(
            `"${s.customerName}"`,
            s.subtotal.toFixed(2),
            s.discount.toFixed(2),
            s.tax.toFixed(2),
            s.total.toFixed(2),
            s.paymentMethod,
            s.status
        );
        csvContent += row.join(",") + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", encodedUri);
    downloadAnchor.setAttribute("download", `reporte_ventas_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    playScanSound('success');
}

/* ==========================================================================
   7. CAJA (CASH CONTROL) & SHIFT CLOSURE VIEW CONTROLLER
   ========================================================================== */
let activeCajaTab = 'movements'; // 'movements' | 'closures'
let closuresPage = 1;

function getLastClosure() {
    if (!state.cashClosures || state.cashClosures.length === 0) return null;
    const sorted = [...state.cashClosures].sort((a, b) => new Date(b.date) - new Date(a.date));
    return sorted[0];
}

function getShiftMetrics() {
    const currency = state.settings.currency || '$';
    const lastClosure = getLastClosure();
    const shiftStartIso = lastClosure ? lastClosure.date : null;
    const shiftStartFormatted = lastClosure 
        ? new Date(lastClosure.date).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' })
        : 'Inicio del Sistema';

    // Base initial cash balance for active shift
    const initialBalance = lastClosure ? (lastClosure.actualCash || 0) : 0;

    // Filter sales in current shift
    const shiftSales = state.sales ? state.sales.filter(s => {
        if (!shiftStartIso) return true;
        return new Date(s.date) > new Date(shiftStartIso);
    }) : [];

    const cashSalesList = shiftSales.filter(s => s.paymentMethod === 'cash');
    const cashSales = cashSalesList.filter(s => s.status === 'completed').reduce((sum, s) => sum + s.total, 0);
    const cashSalesCount = cashSalesList.filter(s => s.status === 'completed').length;
    const voidsTotal = cashSalesList.filter(s => s.status === 'voided').reduce((sum, s) => sum + s.total, 0);

    const otherSales = shiftSales
        .filter(s => s.paymentMethod !== 'cash' && s.status === 'completed')
        .reduce((sum, s) => sum + s.total, 0);

    // Filter cash movements in current shift
    const shiftMovements = state.cashMovements ? state.cashMovements.filter(m => {
        if (!shiftStartIso) return true;
        return new Date(m.date) > new Date(shiftStartIso);
    }) : [];

    const inflowsTotal = shiftMovements.filter(m => m.type === 'inflow').reduce((sum, m) => sum + m.amount, 0);
    const inflowsCount = shiftMovements.filter(m => m.type === 'inflow').length;

    const outflowsTotal = shiftMovements.filter(m => m.type === 'outflow').reduce((sum, m) => sum + m.amount, 0);
    const outflowsCount = shiftMovements.filter(m => m.type === 'outflow').length;

    const expectedCash = initialBalance + cashSales + inflowsTotal - outflowsTotal - voidsTotal;

    return {
        currency,
        lastClosure,
        shiftStartIso,
        shiftStartFormatted,
        initialBalance,
        cashSales,
        cashSalesCount,
        otherSales,
        inflowsTotal,
        inflowsCount,
        outflowsTotal,
        outflowsCount,
        voidsTotal,
        expectedCash,
        shiftMovements,
        shiftSales
    };
}

function renderCaja() {
    const metrics = getShiftMetrics();
    const currency = metrics.currency;

    // Update metric displays for active shift
    document.getElementById('caja-metric-balance').textContent = `${currency}${metrics.expectedCash.toFixed(2)}`;
    document.getElementById('caja-metric-sales').textContent = `${currency}${metrics.cashSales.toFixed(2)}`;
    document.getElementById('caja-metric-sales-count').textContent = `${metrics.cashSalesCount} transacciones`;
    document.getElementById('caja-metric-inflows').textContent = `${currency}${metrics.inflowsTotal.toFixed(2)}`;
    document.getElementById('caja-metric-inflows-count').textContent = `${metrics.inflowsCount} movimientos`;
    document.getElementById('caja-metric-outflows').textContent = `${currency}${metrics.outflowsTotal.toFixed(2)}`;
    document.getElementById('caja-metric-outflows-count').textContent = `${metrics.outflowsCount} movimientos`;

    const balanceCard = document.getElementById('caja-metric-balance').closest('.metric-card');
    if (metrics.expectedCash < 0) {
        balanceCard.style.borderColor = 'var(--danger)';
    } else {
        balanceCard.style.borderColor = '';
    }

    if (activeCajaTab === 'closures') {
        renderCierresHistorial();
        return;
    }

    // Render Turno Actual movements
    const searchVal = document.getElementById('caja-search').value.toLowerCase();
    const typeVal = document.getElementById('caja-filter-type').value;
    const tbody = document.getElementById('caja-table-body');

    const allMovements = compileAllCashMovements(metrics.shiftStartIso);

    const filtered = allMovements.filter(m => {
        const matchesSearch = m.concept.toLowerCase().includes(searchVal) || m.notes.toLowerCase().includes(searchVal);
        const matchesType = !typeVal || m.type === typeVal;
        return matchesSearch && matchesType;
    });

    const totalItems = filtered.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (cajaPage > totalPages) cajaPage = totalPages;

    const startIdx = (cajaPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageItems = filtered.slice(startIdx, endIdx);

    if (pageItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-muted" style="padding: 40px;">
                    No se registran movimientos en el turno actual con los filtros seleccionados.
                </td>
            </tr>
        `;
        document.getElementById('caja-pagination').innerHTML = '';
        return;
    }

    let rowsHtml = '';
    pageItems.forEach(m => {
        let typeBadgeClass = 'badge-primary';
        let typeText = 'Venta';
        let amountPrefix = '+';
        let amountClass = 'text-success';

        if (m.type === 'inflow') {
            typeBadgeClass = 'badge-success';
            typeText = 'Ingreso Manual';
            amountPrefix = '+';
            amountClass = 'text-success';
        } else if (m.type === 'outflow') {
            typeBadgeClass = 'badge-danger';
            typeText = 'Egreso Manual';
            amountPrefix = '-';
            amountClass = 'text-danger';
        } else if (m.type === 'voided') {
            typeBadgeClass = 'badge-warning';
            typeText = 'Anulación';
            amountPrefix = '-';
            amountClass = 'text-danger';
        } else if (m.type === 'sale') {
            typeBadgeClass = 'badge-primary';
            typeText = 'Venta Efectivo';
            amountPrefix = '+';
            amountClass = 'text-success';
        }

        rowsHtml += `
            <tr>
                <td>${new Date(m.date).toLocaleString('es-ES')}</td>
                <td><span class="badge ${typeBadgeClass}">${typeText}</span></td>
                <td style="font-weight: 500;">${m.concept}</td>
                <td class="text-right ${amountClass}" style="font-weight: 700;">
                    ${amountPrefix}${currency}${m.amount.toFixed(2)}
                </td>
                <td class="text-muted" style="font-size: 13px;">${m.notes || '-'}</td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    document.getElementById('caja-pagination').innerHTML = `
        <span>Mostrando registros ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
        <div class="flex-align-center" style="gap: 8px;">
            <button class="btn btn-secondary btn-icon-only" onclick="changeCajaPage(-1)" ${cajaPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
            <span>Pág. ${cajaPage} de ${totalPages}</span>
            <button class="btn btn-secondary btn-icon-only" onclick="changeCajaPage(1)" ${cajaPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

window.changeCajaPage = function (delta) {
    cajaPage += delta;
    renderCaja();
};

window.switchCajaViewTab = function(tabName) {
    activeCajaTab = tabName;
    const btnMovements = document.getElementById('caja-tab-movements-btn');
    const btnClosures = document.getElementById('caja-tab-closures-btn');
    const cardMovements = document.getElementById('caja-movements-card');
    const cardClosures = document.getElementById('caja-closures-card');

    if (tabName === 'closures') {
        if (btnMovements) btnMovements.classList.remove('active-tab');
        if (btnClosures) btnClosures.classList.add('active-tab');
        if (cardMovements) cardMovements.style.display = 'none';
        if (cardClosures) cardClosures.style.display = 'block';
        renderCierresHistorial();
    } else {
        if (btnClosures) btnClosures.classList.remove('active-tab');
        if (btnMovements) btnMovements.classList.add('active-tab');
        if (cardClosures) cardClosures.style.display = 'none';
        if (cardMovements) cardMovements.style.display = 'block';
        cajaPage = 1;
        renderCaja();
    }
};

function renderCierresHistorial() {
    const currency = state.settings.currency || '$';
    const tbody = document.getElementById('closures-table-body');
    if (!tbody) return;

    const closures = state.cashClosures ? [...state.cashClosures].sort((a, b) => new Date(b.date) - new Date(a.date)) : [];

    const totalItems = closures.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (closuresPage > totalPages) closuresPage = totalPages;

    const startIdx = (closuresPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const pageItems = closures.slice(startIdx, endIdx);

    if (pageItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-muted" style="padding: 40px;">
                    Aún no se han realizado cierres de caja en el sistema.
                </td>
            </tr>
        `;
        document.getElementById('closures-pagination').innerHTML = '';
        return;
    }

    let rowsHtml = '';
    pageItems.forEach(c => {
        const diff = c.difference || 0;
        let diffBadgeClass = 'badge-success';
        let diffText = `${currency}0.00`;

        if (diff > 0) {
            diffBadgeClass = 'badge-primary';
            diffText = `+${currency}${diff.toFixed(2)} (Sobrante)`;
        } else if (diff < 0) {
            diffBadgeClass = 'badge-danger';
            diffText = `-${currency}${Math.abs(diff).toFixed(2)} (Faltante)`;
        } else {
            diffBadgeClass = 'badge-success';
            diffText = `${currency}0.00 (Cuadrada)`;
        }

        rowsHtml += `
            <tr>
                <td style="font-weight: 700; color: var(--primary);">#${c.closureNumber || 1}</td>
                <td>${new Date(c.date).toLocaleString('es-ES')}</td>
                <td>${c.cashierName || c.closedBy}</td>
                <td class="text-right">${currency}${(c.expectedCash || 0).toFixed(2)}</td>
                <td class="text-right" style="font-weight: 700;">${currency}${(c.actualCash || 0).toFixed(2)}</td>
                <td class="text-right"><span class="badge ${diffBadgeClass}">${diffText}</span></td>
                <td class="text-center">
                    <span class="badge ${c.emailSentTo ? 'badge-success' : 'badge-warning'}">
                        ${c.emailSentTo ? 'Enviado' : 'Pendiente'}
                    </span>
                </td>
                <td class="text-center">
                    <button class="btn btn-secondary btn-sm" onclick="viewClosureDetail('${c.id}')" title="Ver comprobante y reenviar">
                        <i data-lucide="eye" style="width:14px; height:14px;"></i> Detalle
                    </button>
                </td>
            </tr>
        `;
    });
    tbody.innerHTML = rowsHtml;

    document.getElementById('closures-pagination').innerHTML = `
        <span>Mostrando cierres ${startIdx + 1}-${Math.min(endIdx, totalItems)} de ${totalItems}</span>
        <div class="flex-align-center" style="gap: 8px;">
            <button class="btn btn-secondary btn-icon-only" onclick="changeClosuresPage(-1)" ${closuresPage === 1 ? 'disabled' : ''}><i data-lucide="chevron-left" style="width:14px; height:14px;"></i></button>
            <span>Pág. ${closuresPage} de ${totalPages}</span>
            <button class="btn btn-secondary btn-icon-only" onclick="changeClosuresPage(1)" ${closuresPage === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right" style="width:14px; height:14px;"></i></button>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

window.changeClosuresPage = function(delta) {
    closuresPage += delta;
    renderCierresHistorial();
};

function openCierreCajaModal() {
    const metrics = getShiftMetrics();
    const currency = metrics.currency;

    document.getElementById('cierre-initial-balance-display').textContent = `${currency}${metrics.initialBalance.toFixed(2)}`;
    document.getElementById('cierre-cash-sales-display').textContent = `+${currency}${metrics.cashSales.toFixed(2)} (${metrics.cashSalesCount} ventas)`;
    document.getElementById('cierre-inflows-display').textContent = `+${currency}${metrics.inflowsTotal.toFixed(2)} (${metrics.inflowsCount} mov.)`;
    document.getElementById('cierre-outflows-display').textContent = `-${currency}${metrics.outflowsTotal.toFixed(2)} (${metrics.outflowsCount} mov.)`;
    document.getElementById('cierre-voids-display').textContent = `-${currency}${metrics.voidsTotal.toFixed(2)}`;
    document.getElementById('cierre-expected-display').textContent = `${currency}${metrics.expectedCash.toFixed(2)}`;
    document.getElementById('cierre-other-sales-display').textContent = `${currency}${metrics.otherSales.toFixed(2)}`;
    document.getElementById('cierre-shift-period-text').textContent = `Turno desde: ${metrics.shiftStartFormatted}`;

    const actualInput = document.getElementById('cierre-actual-cash');
    if (actualInput) {
        actualInput.value = metrics.expectedCash.toFixed(2);
    }
    const notesInput = document.getElementById('cierre-notes');
    if (notesInput) {
        notesInput.value = '';
    }

    updateCierreDifferenceBadge();
    openModal('modal-cierre-caja');
}

function updateCierreDifferenceBadge() {
    const metrics = getShiftMetrics();
    const currency = metrics.currency;
    const actualVal = parseFloat(document.getElementById('cierre-actual-cash').value) || 0;
    const diff = actualVal - metrics.expectedCash;
    const badgeEl = document.getElementById('cierre-diff-badge');
    if (!badgeEl) return;

    if (Math.abs(diff) < 0.009) {
        badgeEl.style.background = 'rgba(16,185,129,0.15)';
        badgeEl.style.color = '#10b981';
        badgeEl.textContent = `Caja Cuadrada (${currency}0.00)`;
    } else if (diff > 0) {
        badgeEl.style.background = 'rgba(59,130,246,0.15)';
        badgeEl.style.color = '#3b82f6';
        badgeEl.textContent = `Sobrante de Caja (+${currency}${diff.toFixed(2)})`;
    } else {
        badgeEl.style.background = 'rgba(239,68,68,0.15)';
        badgeEl.style.color = '#ef4444';
        badgeEl.textContent = `FALTANTE DE CAJA (-${currency}${Math.abs(diff).toFixed(2)})`;
    }
}

async function processCierreCaja(e) {
    e.preventDefault();
    const metrics = getShiftMetrics();
    const actualCash = parseFloat(document.getElementById('cierre-actual-cash').value) || 0;
    const difference = actualCash - metrics.expectedCash;
    const targetEmail = document.getElementById('cierre-target-email').value.trim() || 'dhmotopartes@gmail.com';
    const notes = document.getElementById('cierre-notes').value.trim();

    const cashierEmail = 'dhmotopartes@gmail.com';
    let cashierName = 'Cajero DH Motopartes';
    if (currentUserProfile && (currentUserProfile.first_name || currentUserProfile.last_name)) {
        cashierName = `${currentUserProfile.first_name || ''} ${currentUserProfile.last_name || ''}`.trim();
    }

    const closureNumber = state.cashClosures ? state.cashClosures.length + 1 : 1;
    const closureObj = {
        id: `CLO-${Date.now()}`,
        closureNumber: closureNumber,
        date: new Date().toISOString(),
        openedAt: metrics.shiftStartIso || new Date().toISOString(),
        closedBy: cashierEmail,
        cashierName: cashierName,
        initialBalance: metrics.initialBalance,
        cashSales: metrics.cashSales,
        cashSalesCount: metrics.cashSalesCount,
        otherSales: metrics.otherSales,
        inflows: metrics.inflowsTotal,
        inflowsCount: metrics.inflowsCount,
        outflows: metrics.outflowsTotal,
        outflowsCount: metrics.outflowsCount,
        voidsTotal: metrics.voidsTotal,
        expectedCash: metrics.expectedCash,
        actualCash: actualCash,
        difference: difference,
        notes: notes,
        emailSentTo: targetEmail,
        emailStatus: 'sent'
    };

    if (!state.cashClosures) state.cashClosures = [];
    state.cashClosures.push(closureObj);
    saveDatabase();

    closeModal('modal-cierre-caja');
    playScanSound('success');

    // Dispatch closure email
    await sendCierreEmail(closureObj);

    // Refresh Caja view
    cajaPage = 1;
    renderCaja();

    alert(`¡Cierre de Caja #${closureNumber} realizado con éxito!\nEl reporte fue procesado y enviado a ${targetEmail}.`);
}

async function sendCierreEmail(closureObj) {
    const targetEmail = closureObj.targetEmail || 'dhmotopartes@gmail.com';
    const storeName = (state.settings && state.settings.storeName) || 'DH Motopartes';
    const currency = (state.settings && state.settings.currency) || '$';

    try {
        if (supabaseClient) {
            const { data, error } = await supabaseClient.functions.invoke('send-cierre-email', {
                body: {
                    closureId: closureObj.id,
                    closureNumber: closureObj.closureNumber,
                    date: closureObj.date,
                    openedAt: closureObj.openedAt,
                    closedBy: closureObj.closedBy,
                    cashierName: closureObj.cashierName,
                    storeName: storeName,
                    initialBalance: closureObj.initialBalance,
                    cashSales: closureObj.cashSales,
                    cashSalesCount: closureObj.cashSalesCount,
                    otherSales: closureObj.otherSales,
                    inflows: closureObj.inflows,
                    inflowsCount: closureObj.inflowsCount,
                    outflows: closureObj.outflows,
                    outflowsCount: closureObj.outflowsCount,
                    voidsTotal: closureObj.voidsTotal,
                    expectedCash: closureObj.expectedCash,
                    actualCash: closureObj.actualCash,
                    difference: closureObj.difference,
                    notes: closureObj.notes,
                    targetEmail: targetEmail,
                    currency: currency
                }
            });
            if (error) {
                console.warn("Respuesta de Edge Function send-cierre-email:", error);
            }
        }
    } catch (err) {
        console.warn("No se pudo invocar directamente la Edge Function de correo:", err);
    }
}

window.viewClosureDetail = function(closureId) {
    const closure = state.cashClosures ? state.cashClosures.find(c => c.id === closureId) : null;
    if (!closure) return;

    const currency = state.settings.currency || '$';
    const storeName = state.settings.storeName || 'DH Motopartes';
    const formattedDate = new Date(closure.date).toLocaleString('es-ES', { dateStyle: 'full', timeStyle: 'medium' });

    const diff = closure.difference || 0;
    let diffColor = '#10b981';
    let diffText = 'CAJA CUADRADA ($0.00)';
    if (diff > 0) {
        diffColor = '#3b82f6';
        diffText = `SOBRANTE (+${currency}${diff.toFixed(2)})`;
    } else if (diff < 0) {
        diffColor = '#ef4444';
        diffText = `FALTANTE (-${currency}${Math.abs(diff).toFixed(2)})`;
    }

    const detailHtml = `
        <div class="closure-ticket-view" style="font-family: monospace; font-size: 13px; color: var(--text-main); line-height: 1.5; padding: 10px;">
            <div style="text-align: center; border-bottom: 1px dashed var(--border-color); padding-bottom: 10px; margin-bottom: 10px;">
                <h3 style="margin: 0; font-size: 18px; font-weight: 800;">${storeName}</h3>
                <p style="margin: 2px 0 0 0; font-size: 12px; color: var(--text-muted);">COMPROBANTE DE CIERRE DE CAJA #${closure.closureNumber || 1}</p>
                <div style="margin-top: 6px; font-weight: 700; color: ${diffColor}; font-size: 13px;">${diffText}</div>
            </div>

            <div style="margin-bottom: 10px; font-size: 12px;">
                <div><strong>Folio:</strong> ${closure.id}</div>
                <div><strong>Fecha Cierre:</strong> ${formattedDate}</div>
                <div><strong>Cajero:</strong> ${closure.cashierName || closure.closedBy}</div>
                <div><strong>Enviado a:</strong> ${closure.targetEmail || 'dhmotopartes@gmail.com'}</div>
            </div>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 12px;">
                <tbody>
                    <tr><td>Fondo de Apertura:</td><td style="text-align: right;">${currency}${(closure.initialBalance || 0).toFixed(2)}</td></tr>
                    <tr style="color: var(--emerald);"><td>(+) Ventas Efectivo:</td><td style="text-align: right;">+${currency}${(closure.cashSales || 0).toFixed(2)}</td></tr>
                    <tr style="color: var(--emerald);"><td>(+) Otros Ingresos:</td><td style="text-align: right;">+${currency}${(closure.inflows || 0).toFixed(2)}</td></tr>
                    <tr style="color: var(--danger);"><td>(-) Egresos / Retiros:</td><td style="text-align: right;">-${currency}${(closure.outflows || 0).toFixed(2)}</td></tr>
                    <tr style="color: var(--danger);"><td>(-) Anulaciones:</td><td style="text-align: right;">-${currency}${(closure.voidsTotal || 0).toFixed(2)}</td></tr>
                    <tr style="border-top: 1px dashed var(--border-color); font-weight: 700; font-size: 13px;">
                        <td>EFECTIVO ESPERADO:</td>
                        <td style="text-align: right;">${currency}${(closure.expectedCash || 0).toFixed(2)}</td>
                    </tr>
                    <tr style="font-weight: 700; font-size: 13px;">
                        <td>EFECTIVO REAL:</td>
                        <td style="text-align: right;">${currency}${(closure.actualCash || 0).toFixed(2)}</td>
                    </tr>
                    <tr style="font-weight: 700; color: ${diffColor};">
                        <td>DIFERENCIA:</td>
                        <td style="text-align: right;">${diff >= 0 ? '+' : ''}${currency}${diff.toFixed(2)}</td>
                    </tr>
                </tbody>
            </table>

            ${closure.otherSales > 0 ? `
            <div style="border-top: 1px dashed var(--border-color); padding-top: 6px; font-size: 11px; color: var(--text-muted);">
                Ventas en otros medios de pago (Transferencias / Tarjetas): <strong>${currency}${(closure.otherSales).toFixed(2)}</strong>
            </div>
            ` : ''}

            ${closure.notes ? `
            <div style="border-top: 1px dashed var(--border-color); padding-top: 6px; margin-top: 6px; font-size: 12px; font-style: italic;">
                <strong>Observaciones:</strong> ${closure.notes}
            </div>
            ` : ''}
        </div>
    `;

    document.getElementById('cierre-detail-content').innerHTML = detailHtml;
    document.getElementById('cierre-print-btn').onclick = () => window.print();
    document.getElementById('cierre-resend-email-btn').onclick = async () => {
        await sendCierreEmail(closure);
        alert(`Reporte de Cierre #${closure.closureNumber} reenviado a ${closure.targetEmail || 'dhmotopartes@gmail.com'}`);
    };

    openModal('modal-cierre-detail');
};

function saveCajaMovement(e) {
    e.preventDefault();

    const type = document.getElementById('caja-movement-type-field').value;
    const amount = parseFloat(document.getElementById('caja-movement-amount').value) || 0;
    const concept = document.getElementById('caja-movement-concept').value.trim();
    const notes = document.getElementById('caja-movement-notes').value.trim();

    if (amount <= 0) {
        alert("El monto debe ser mayor a 0.");
        return;
    }

    const movement = {
        id: `cm_${Date.now()}`,
        date: new Date().toISOString(),
        type,
        amount,
        concept,
        notes
    };

    state.cashMovements.push(movement);
    saveDatabase();

    closeModal('modal-caja-movement');
    document.getElementById('caja-movement-form').reset();

    renderCaja();
    playScanSound('success');
}

function compileAllCashMovements(shiftStartIso) {
    let movements = [];
    // Add manual cash movements
    if (state.cashMovements) {
        state.cashMovements.forEach(m => {
            if (shiftStartIso && new Date(m.date) <= new Date(shiftStartIso)) return;
            movements.push({
                id: m.id,
                date: m.date,
                type: m.type, // 'inflow' | 'outflow'
                amount: m.amount,
                concept: m.concept,
                notes: m.notes || ''
            });
        });
    }
    // Add cash sales
    if (state.sales) {
        state.sales.forEach(s => {
            if (shiftStartIso && new Date(s.date) <= new Date(shiftStartIso)) return;
            if (s.paymentMethod === 'cash') {
                if (s.status === 'completed') {
                    movements.push({
                        id: s.id,
                        date: s.date,
                        type: 'sale',
                        amount: s.total,
                        concept: `Venta en Efectivo (Folio: ${s.id})`,
                        notes: `Cliente: ${s.customerName}`
                    });
                } else if (s.status === 'voided') {
                    movements.push({
                        id: s.id,
                        date: s.date,
                        type: 'voided',
                        amount: s.total,
                        concept: `Anulación Venta Efectivo (Folio: ${s.id})`,
                        notes: `Reembolso de venta por anulación`
                    });
                }
            }
        });
    }
    return movements.sort((a, b) => new Date(b.date) - new Date(a.date)); // descending date (newest first)
}

/* ==========================================================================
   8. EXCEL MASS IMPORT CONTROLLER
   ========================================================================== */
let tempExcelProducts = [];

function findExcelColumnIndex(headers, targets) {
    for (let i = 0; i < headers.length; i++) {
        if (headers[i] === undefined || headers[i] === null) continue;
        const h = headers[i].toString().toLowerCase().trim()
            .normalize("NFD").replace(/[\u0300-\u036f]/g, ""); // remove accents
        if (targets.includes(h)) {
            return i;
        }
    }
    return -1;
}

async function handleExcelImport(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    try {
        await ensureXLSX();
    } catch (err) {
        alert(err.message);
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function (evt) {
        try {
            const data = new Uint8Array(evt.target.result);
            const workbook = XLSX.read(data, { type: 'array' });

            // Read first sheet
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];

            // Convert to 2D array (header: 1 forces array of arrays)
            const jsonRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

            if (jsonRows.length < 2) {
                alert("El archivo Excel no tiene suficientes filas. Debe contener los encabezados y al menos un producto.");
                return;
            }

            const headers = jsonRows[0];

            // Mappings (variations in spanish/english)
            const skuIdx = findExcelColumnIndex(headers, ['sku', 'codigo', 'code', 'referencia', 'id']);
            const nameIdx = findExcelColumnIndex(headers, ['nombre', 'name', 'descripcion', 'producto', 'articulo', 'detalle']);
            const catIdx = findExcelColumnIndex(headers, ['categoria', 'category']);
            const costIdx = findExcelColumnIndex(headers, ['costo', 'cost', 'compra', 'precio compra']);
            const priceIdx = findExcelColumnIndex(headers, ['precio', 'price', 'venta', 'precio venta']);
            const priceWholesaleIdx = findExcelColumnIndex(headers, ['mayorista', 'wholesale', 'precio mayorista', 'lista 2', 'descuento', 'discount', 'precio descuento']);
            const stockIdx = findExcelColumnIndex(headers, ['stock', 'cantidad', 'cant', 'stock local', 'local']);
            const minIdx = findExcelColumnIndex(headers, ['stockmin', 'stock minimo', 'minimo', 'alerta', 'stock minimo local']);
            const stockWholesaleIdx = findExcelColumnIndex(headers, ['stock mayorista', 'mayorista stock', 'stock wholesale', 'wholesale stock']);
            const minWholesaleIdx = findExcelColumnIndex(headers, ['stockminwholesale', 'stockmin mayorista', 'stock minimo mayorista', 'minimo mayorista', 'alerta mayorista']);
            const isFractionalIdx = findExcelColumnIndex(headers, ['fraccionable', 'isfractional', 'fraccion', 'fraccionario', 'decimal']);

            if (skuIdx === -1) {
                alert("No se pudo detectar la columna 'SKU' o 'Código'. Por favor, asegúrate de que el archivo Excel tenga una columna con uno de estos nombres.");
                return;
            }

            tempExcelProducts = [];
            let duplicates = new Set();

            for (let i = 1; i < jsonRows.length; i++) {
                const row = jsonRows[i];
                if (!row || row.length === 0) continue;

                const rawSku = row[skuIdx];
                if (rawSku === undefined || rawSku === null || rawSku.toString().trim() === '') continue;

                const sku = rawSku.toString().trim().toUpperCase();
                if (duplicates.has(sku)) continue; // skip duplicates in the spreadsheet
                duplicates.add(sku);

                // Lookup in current database
                const exists = state.products.find(p => p.sku === sku);

                // Read values with fallbacks
                const name = nameIdx !== -1 && row[nameIdx] !== undefined && row[nameIdx] !== null
                    ? row[nameIdx].toString().trim()
                    : (exists ? exists.name : `Repuesto SKU ${sku}`);

                const category = catIdx !== -1 && row[catIdx] !== undefined && row[catIdx] !== null
                    ? row[catIdx].toString().trim()
                    : (exists ? exists.category : 'Repuestos de Motor');

                const cost = costIdx !== -1 && row[costIdx] !== undefined && row[costIdx] !== null
                    ? parseFloat(row[costIdx]) || 0
                    : (exists ? exists.cost : 0);

                const price = priceIdx !== -1 && row[priceIdx] !== undefined && row[priceIdx] !== null
                    ? parseFloat(row[priceIdx]) || 0
                    : (exists ? exists.price : 0);

                const priceWholesale = priceWholesaleIdx !== -1 && row[priceWholesaleIdx] !== undefined && row[priceWholesaleIdx] !== null
                    ? parseFloat(row[priceWholesaleIdx]) || 0
                    : (exists ? (exists.priceWholesale || exists.priceDiscount || 0) : 0);

                const isFractional = isFractionalIdx !== -1 && row[isFractionalIdx] !== undefined && row[isFractionalIdx] !== null
                    ? (row[isFractionalIdx].toString().toLowerCase().trim() === 'true' || row[isFractionalIdx].toString().toLowerCase().trim() === 'si' || row[isFractionalIdx] === 1 || row[isFractionalIdx] === '1')
                    : (exists ? (exists.isFractional || false) : false);

                const stock = stockIdx !== -1 && row[stockIdx] !== undefined && row[stockIdx] !== null
                    ? (isFractional ? (parseFloat(row[stockIdx]) || 0) : (parseInt(row[stockIdx]) || 0))
                    : (exists ? exists.stock : 0);

                const stockMin = minIdx !== -1 && row[minIdx] !== undefined && row[minIdx] !== null
                    ? (isFractional ? (parseFloat(row[minIdx]) || 0) : (parseInt(row[minIdx]) || 5))
                    : (exists ? exists.stockMin : 5);

                const stockWholesale = stockWholesaleIdx !== -1 && row[stockWholesaleIdx] !== undefined && row[stockWholesaleIdx] !== null
                    ? (isFractional ? (parseFloat(row[stockWholesaleIdx]) || 0) : (parseInt(row[stockWholesaleIdx]) || 0))
                    : (exists ? (exists.stockWholesale || 0) : 0);

                const stockMinWholesale = minWholesaleIdx !== -1 && row[minWholesaleIdx] !== undefined && row[minWholesaleIdx] !== null
                    ? (isFractional ? (parseFloat(row[minWholesaleIdx]) || 0) : (parseInt(row[minWholesaleIdx]) || 5))
                    : (exists ? (exists.stockMinWholesale || 5) : 5);

                tempExcelProducts.push({
                    sku, name, category, cost, price, priceWholesale, stock, stockMin, stockWholesale, stockMinWholesale, isFractional,
                    isNew: !exists,
                    existingProduct: exists || null
                });
            }

            if (tempExcelProducts.length === 0) {
                alert("No se encontraron registros de productos procesables en el archivo Excel.");
                return;
            }

            showExcelImportPreview();

        } catch (error) {
            console.error("Excel processing failed:", error);
            alert("Ocurrió un error al procesar el archivo Excel: " + error.message);
        } finally {
            e.target.value = '';
        }
    };
    reader.readAsArrayBuffer(file);
}

function showExcelImportPreview() {
    const totalCount = tempExcelProducts.length;
    const newCount = tempExcelProducts.filter(p => p.isNew).length;
    const updateCount = totalCount - newCount;

    document.getElementById('excel-total-count').textContent = totalCount;
    document.getElementById('excel-new-count').textContent = newCount;
    document.getElementById('excel-update-count').textContent = updateCount;

    const tbody = document.getElementById('excel-preview-table-body');
    let rowsHtml = '';
    const currency = state.settings.currency || '$';

    // Show first 5 items to keep modal lightweight
    const previewItems = tempExcelProducts.slice(0, 5);
    previewItems.forEach(p => {
        const badgeClass = p.isNew ? 'badge-success' : 'badge-warning';
        const badgeText = p.isNew ? 'Nuevo' : 'Actualizar';

        rowsHtml += `
            <tr>
                <td style="font-weight: 700;">${p.sku}</td>
                <td>${p.name}</td>
                <td>${p.category}</td>
                <td class="text-right">${currency}${p.cost.toFixed(2)}</td>
                <td class="text-right" style="font-weight: 700;">${currency}${p.price.toFixed(2)}</td>
                <td class="text-right">${currency}${p.priceWholesale.toFixed(2)}</td>
                <td class="text-center" style="font-weight: 700;">${p.stock} L / ${p.stockWholesale || 0} M</td>
                <td><span class="badge ${badgeClass}">${badgeText}</span></td>
            </tr>
        `;
    });

    if (totalCount > 5) {
        rowsHtml += `
            <tr>
                <td colspan="8" class="text-center text-muted" style="padding: 12px; font-weight: 500;">
                    ... y ${totalCount - 5} productos más en el archivo ...
                  </td>
            </tr>
        `;
    }

    tbody.innerHTML = rowsHtml;

    if (window.lucide) lucide.createIcons();
    openModal('modal-excel-preview');
}

function confirmExcelImport() {
    if (tempExcelProducts.length === 0) return;

    let created = 0;
    let updated = 0;

    tempExcelProducts.forEach(p => {
        if (p.isNew) {
            state.products.push({
                id: `p_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
                sku: p.sku,
                name: p.name,
                category: p.category,
                cost: p.cost,
                price: p.price,
                priceWholesale: p.priceWholesale,
                priceDiscount: p.priceWholesale, // mantener sincronizado
                stock: p.stock,
                stockMin: p.stockMin,
                stockWholesale: p.stockWholesale || 0,
                stockMinWholesale: p.stockMinWholesale || 5,
                isCombo: false,
                components: [],
                image: '',
                isFractional: p.isFractional || false
            });
            created++;
        } else {
            const prod = state.products.find(item => item.id === p.existingProduct.id);
            if (prod) {
                prod.name = p.name;
                prod.category = p.category;
                prod.cost = p.cost;
                prod.price = p.price;
                prod.priceWholesale = p.priceWholesale;
                prod.priceDiscount = p.priceWholesale; // mantener sincronizado
                if (!prod.isCombo) {
                    prod.stock = p.stock;
                    prod.stockWholesale = p.stockWholesale !== undefined ? p.stockWholesale : (prod.stockWholesale || 0);
                }
                prod.stockMin = p.stockMin;
                prod.stockMinWholesale = p.stockMinWholesale !== undefined ? p.stockMinWholesale : (prod.stockMinWholesale || 5);
                prod.isFractional = p.isFractional || false;
                updated++;
            }
        }
    });

    saveDatabase();
    closeModal('modal-excel-preview');

    // Refresh view
    inventoryPage = 1;
    renderInventory();
    playScanSound('success');

    alert(`Importación Masiva Completada:\n- ${created} productos nuevos creados.\n- ${updated} productos existentes actualizados.`);
    tempExcelProducts = [];
}

async function downloadExcelTemplate() {
    try {
        await ensureXLSX();
    } catch (err) {
        alert(err.message);
        return;
    }

    // Columns
    const headers = ['SKU', 'Nombre', 'Categoria', 'Costo', 'Precio Minorista', 'Precio Mayorista', 'Stock Local', 'Stock Minimo Local', 'Stock Mayorista', 'Stock Minimo Mayorista', 'Fraccionable'];

    // Sample items for motorcycle spare parts store
    const rows = [
        ['REP-FIL-NAF', 'Filtro de Nafta Universal Motocicleta', 'Repuestos de Motor', 150.00, 320.00, 280.00, 50, 10, 30, 5, 'NO'],
        ['REP-BUJ-NGK-D8EA', 'Bujía NGK D8EA (Motos 110cc-150cc)', 'Sistema Eléctrico', 420.00, 800.00, 700.00, 100, 15, 60, 8, 'NO'],
        ['REP-TRA-CAD-DID', 'Cadena DID 428H-118L Reforzada', 'Transmisión', 3500.00, 5900.00, 5200.00, 15, 5, 10, 2, 'NO'],
        ['LIQ-ACE-SUELTO', 'Aceite 2T Suelto (Lts)', 'Aceites', 900.00, 1500.00, 1300.00, 20.5, 5.0, 10.0, 2.0, 'SI']
    ];

    const data = [headers, ...rows];

    try {
        const worksheet = XLSX.utils.aoa_to_sheet(data);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Plantilla de Inventario');

        // Write file binary
        XLSX.writeFile(workbook, 'plantilla_inventario_dhmotopartes.xlsx');
        playScanSound('success');
    } catch (err) {
        console.error("Template generation failed:", err);
        alert("No se pudo generar la plantilla Excel: " + err.message);
    }
}

async function exportInventoryExcel() {
    if (state.products.length === 0) {
        alert("No hay productos en el inventario para exportar.");
        return;
    }
    
    try {
        await ensureXLSX();
    } catch (err) {
        alert(err.message);
        return;
    }
    
    // Headers
    const headers = ['SKU', 'Nombre', 'Categoria', 'Costo', 'Precio Minorista', 'Precio Mayorista', 'Stock Local', 'Stock Minimo Local', 'Stock Mayorista', 'Stock Minimo Mayorista', 'Fraccionable'];

    // Data Rows
    const rows = state.products.map(p => [
        p.sku,
        p.name,
        p.category,
        p.cost,
        p.price,
        p.priceWholesale || 0,
        p.stock,
        p.stockMin,
        p.stockWholesale || 0,
        p.stockMinWholesale || 5,
        p.isFractional ? 'SI' : 'NO'
    ]);

    const data = [headers, ...rows];

    try {
        const worksheet = XLSX.utils.aoa_to_sheet(data);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Inventario DHMotopartes');

        XLSX.writeFile(workbook, 'inventario_completo.xlsx');
        playScanSound('success');
    } catch (err) {
        console.error("Inventory export failed:", err);
        alert("Ocurrió un error al exportar el inventario a Excel: " + err.message);
    }
}

/* ==========================================================================
   AI Receipt Scanner & Staging Menu
   ========================================================================== */
let tempReceptionFile = null;
let tempReceptionFileBase64 = null;
let tempReceptionMimeType = null;
let tempStagingItems = [];

window.togglePasswordVisibility = function(inputId) {
    const el = document.getElementById(inputId);
    if (!el) return;
    el.type = el.type === 'password' ? 'text' : 'password';
};

function openReceptionAiModal() {
    tempReceptionFile = null;
    tempReceptionFileBase64 = null;
    tempReceptionMimeType = null;
    tempStagingItems = [];

    // Reset Steps visibility
    const stepUpload = document.getElementById('reception-step-upload');
    const stepStaging = document.getElementById('reception-step-staging');
    const btnBack = document.getElementById('btn-reception-back');
    const btnProcess = document.getElementById('btn-reception-process-ai');
    const btnAuthorize = document.getElementById('btn-reception-authorize');
    const loadingContainer = document.getElementById('reception-loading-container');
    const dropzone = document.getElementById('reception-dropzone');
    const previewCard = document.getElementById('reception-file-preview-card');

    if (stepUpload) stepUpload.style.display = 'block';
    if (stepStaging) stepStaging.style.display = 'none';
    if (btnBack) btnBack.style.display = 'none';
    if (btnProcess) btnProcess.style.display = 'inline-flex';
    if (btnAuthorize) btnAuthorize.style.display = 'none';
    if (loadingContainer) loadingContainer.style.display = 'none';
    if (dropzone) dropzone.style.display = 'block';
    if (previewCard) previewCard.style.display = 'none';

    // Populate quick API key if available
    const keyInput = document.getElementById('reception-quick-api-key');
    const keyStatusText = document.getElementById('reception-ai-key-status-text');
    const currentKey = (state.settings && state.settings.geminiApiKey) || '';
    if (keyInput) keyInput.value = currentKey;
    if (keyStatusText) {
        if (currentKey) {
            keyStatusText.innerHTML = '<span style="color: var(--success); font-weight: 600;">✓ Clave Gemini configurada y activa</span>';
        } else {
            keyStatusText.innerHTML = '<span style="color: var(--warning); font-weight: 600;">⚠ Sin clave API configurada (o usa el botón "Probar con Remito Demo")</span>';
        }
    }

    openModal('modal-reception-ai');
    if (window.lucide) lucide.createIcons();
}

// Realistic sample receipt from a motorcycle parts distributor for quick demo & testing
const DEMO_RECEIPT_DATA = {
    proveedor: "Distribuidora Motos del Plata S.A.",
    numero_comprobante: "REM-00049281",
    items: [
        { codigo: "REP-BUJ-C7HSA", descripcion: "Bujía NGK C7HSA (Motos 110cc)", cantidad: 20, costo_unitario: 650.00 },
        { codigo: "REP-CAD-428H", descripcion: "Cadena de Transmisión 428H-118L Reforzada WStandard", cantidad: 8, costo_unitario: 4800.00 },
        { codigo: "REP-PAS-YBR", descripcion: "Juego de Pastillas de Freno Delantero Yamaha YBR 125", cantidad: 12, costo_unitario: 2400.00 },
        { codigo: "REP-CAB-TITAN", descripcion: "Cable de Embrague Honda CG Titan 150", cantidad: 15, costo_unitario: 1100.00 },
        { codigo: "LUB-MOT-20W50", descripcion: "Aceite Motul 3000 4T 20W50 Mineral 1L", cantidad: 24, costo_unitario: 3900.00 },
        { codigo: "REP-JUN-WAVE", descripcion: "Juego de Juntas Completo Honda Wave 110 S", cantidad: 6, costo_unitario: 2150.00 },
        { codigo: "REP-FIL-XR150", descripcion: "Filtro de Aire Honda XR 150 L", cantidad: 10, costo_unitario: 1750.00 },
        { codigo: "REP-REL-12V", descripcion: "Relay de Arranque Universal 12V 4 Pines", cantidad: 10, costo_unitario: 1350.00 }
    ]
};

function initReceptionAiListeners() {
    const dropzone = document.getElementById('reception-dropzone');
    const fileInput = document.getElementById('reception-file-input');
    const cameraInput = document.getElementById('reception-camera-input');
    const btnClear = document.getElementById('btn-reception-clear-file');
    const btnDemo = document.getElementById('btn-load-demo-receipt');
    const btnProcess = document.getElementById('btn-reception-process-ai');
    const btnSaveKey = document.getElementById('btn-save-quick-api-key');
    const btnBack = document.getElementById('btn-reception-back');
    const btnAddRow = document.getElementById('btn-staging-add-row');
    const btnApplyMargin = document.getElementById('btn-apply-global-margin');
    const btnAuthorize = document.getElementById('btn-reception-authorize');

    if (dropzone) {
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.add('dragover');
        });
        dropzone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove('dragover');
        });
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropzone.classList.remove('dragover');
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                handleReceptionFileSelected(e.dataTransfer.files[0]);
            }
        });
    }

    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleReceptionFileSelected(e.target.files[0]);
            }
        });
    }

    if (cameraInput) {
        cameraInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                handleReceptionFileSelected(e.target.files[0]);
            }
        });
    }

    if (btnClear) {
        btnClear.addEventListener('click', () => {
            tempReceptionFile = null;
            tempReceptionFileBase64 = null;
            tempReceptionMimeType = null;
            const drop = document.getElementById('reception-dropzone');
            const card = document.getElementById('reception-file-preview-card');
            const fi = document.getElementById('reception-file-input');
            const ci = document.getElementById('reception-camera-input');
            if (drop) drop.style.display = 'block';
            if (card) card.style.display = 'none';
            if (fi) fi.value = '';
            if (ci) ci.value = '';
        });
    }

    if (btnSaveKey) {
        btnSaveKey.addEventListener('click', () => {
            const val = (document.getElementById('reception-quick-api-key').value || '').trim();
            if (!state.settings) state.settings = {};
            state.settings.geminiApiKey = val;
            const setGen = document.getElementById('set-gemini-api-key');
            if (setGen) setGen.value = val;
            saveDatabase();
            const keyStatusText = document.getElementById('reception-ai-key-status-text');
            if (keyStatusText) {
                if (val) {
                    keyStatusText.innerHTML = '<span style="color: var(--success); font-weight: 600;">✓ Clave Gemini guardada con éxito</span>';
                } else {
                    keyStatusText.innerHTML = '<span style="color: var(--warning); font-weight: 600;">⚠ Clave eliminada</span>';
                }
            }
            playScanSound('success');
        });
    }

    if (btnDemo) {
        btnDemo.addEventListener('click', async () => {
            const loading = document.getElementById('reception-loading-container');
            const drop = document.getElementById('reception-dropzone');
            const card = document.getElementById('reception-file-preview-card');
            if (loading) loading.style.display = 'block';
            if (drop) drop.style.display = 'none';
            if (card) card.style.display = 'none';

            await new Promise(r => setTimeout(r, 650));
            if (loading) loading.style.display = 'none';
            processExtractedReceiptData(DEMO_RECEIPT_DATA);
            playScanSound('success');
        });
    }

    if (btnProcess) {
        btnProcess.addEventListener('click', async () => {
            if (!tempReceptionFileBase64) {
                alert("Por favor selecciona primero una imagen o documento PDF de tu remito o factura.");
                return;
            }

            const apiKey = (state.settings && state.settings.geminiApiKey) || (document.getElementById('reception-quick-api-key').value || '').trim();
            if (!apiKey) {
                const wantsDemo = confirm("No tienes configurada una clave de Gemini API.\n\n¿Deseas probar con el 'Remito de Demostración' para ver el funcionamiento de la Carga Prevista?");
                if (wantsDemo) {
                    processExtractedReceiptData(DEMO_RECEIPT_DATA);
                    playScanSound('success');
                    return;
                }
                const promptKey = prompt("Ingresa tu API Key de Google Gemini (puedes obtenerla gratis en aistudio.google.com):");
                if (promptKey && promptKey.trim()) {
                    state.settings.geminiApiKey = promptKey.trim();
                    const setGen = document.getElementById('set-gemini-api-key');
                    if (setGen) setGen.value = promptKey.trim();
                    const qk = document.getElementById('reception-quick-api-key');
                    if (qk) qk.value = promptKey.trim();
                    saveDatabase();
                } else {
                    return;
                }
            }

            const activeKey = (state.settings && state.settings.geminiApiKey) || '';
            const loading = document.getElementById('reception-loading-container');
            const card = document.getElementById('reception-file-preview-card');
            const drop = document.getElementById('reception-dropzone');
            if (loading) loading.style.display = 'block';
            if (card) card.style.display = 'none';
            if (drop) drop.style.display = 'none';

            try {
                const extracted = await callGeminiReceiptExtractor(tempReceptionFileBase64, tempReceptionMimeType, activeKey);
                if (loading) loading.style.display = 'none';
                if (!extracted || !extracted.items || extracted.items.length === 0) {
                    throw new Error("No se detectaron líneas de productos legibles en el comprobante. Verifica que la imagen sea nítida.");
                }
                processExtractedReceiptData(extracted);
                playScanSound('success');
            } catch (err) {
                console.error("Gemini Extraction Error:", err);
                if (loading) loading.style.display = 'none';
                if (card) card.style.display = 'flex';
                alert("Error al procesar el remito con IA: " + err.message);
            }
        });
    }

    if (btnBack) {
        btnBack.addEventListener('click', () => {
            const stepUpload = document.getElementById('reception-step-upload');
            const stepStaging = document.getElementById('reception-step-staging');
            const btnBackEl = document.getElementById('btn-reception-back');
            const btnProcessEl = document.getElementById('btn-reception-process-ai');
            const btnAuthorizeEl = document.getElementById('btn-reception-authorize');
            const drop = document.getElementById('reception-dropzone');
            const card = document.getElementById('reception-file-preview-card');

            if (stepUpload) stepUpload.style.display = 'block';
            if (stepStaging) stepStaging.style.display = 'none';
            if (btnBackEl) btnBackEl.style.display = 'none';
            if (btnProcessEl) btnProcessEl.style.display = 'inline-flex';
            if (btnAuthorizeEl) btnAuthorizeEl.style.display = 'none';

            if (tempReceptionFileBase64) {
                if (card) card.style.display = 'flex';
                if (drop) drop.style.display = 'none';
            } else {
                if (drop) drop.style.display = 'block';
                if (card) card.style.display = 'none';
            }
            if (window.lucide) lucide.createIcons();
        });
    }

    if (btnAddRow) {
        btnAddRow.addEventListener('click', () => {
            if (typeof addManualStagingRow === 'function') addManualStagingRow();
        });
    }

    if (btnApplyMargin) {
        btnApplyMargin.addEventListener('click', () => {
            if (typeof applyGlobalMarginToStaging === 'function') applyGlobalMarginToStaging();
        });
    }

    if (btnAuthorize) {
        btnAuthorize.addEventListener('click', () => {
            if (typeof authorizeStockReception === 'function') authorizeStockReception();
        });
    }
}

function handleReceptionFileSelected(file) {
    if (!file) return;
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg', 'application/pdf'];
    if (!allowed.some(t => file.type.toLowerCase().includes(t.replace('image/', '')) || file.type.toLowerCase() === t)) {
        alert("Formato de archivo no compatible. Por favor sube una imagen (JPG, PNG, WEBP) o un documento PDF.");
        return;
    }

    tempReceptionFile = file;
    tempReceptionMimeType = file.type || 'image/jpeg';

    const reader = new FileReader();
    reader.onload = function(e) {
        tempReceptionFileBase64 = e.target.result;

        const drop = document.getElementById('reception-dropzone');
        const card = document.getElementById('reception-file-preview-card');
        const fname = document.getElementById('reception-preview-filename');
        const fsize = document.getElementById('reception-preview-filesize');
        const pimg = document.getElementById('reception-preview-img');
        const picon = document.getElementById('reception-preview-default-icon');

        if (drop) drop.style.display = 'none';
        if (card) card.style.display = 'flex';
        if (fname) fname.textContent = file.name;
        if (fsize) fsize.textContent = `${(file.size / 1024).toFixed(1)} KB`;

        if (file.type.startsWith('image/')) {
            if (pimg) {
                pimg.src = tempReceptionFileBase64;
                pimg.style.display = 'block';
            }
            if (picon) picon.style.display = 'none';
        } else {
            if (pimg) pimg.style.display = 'none';
            if (picon) picon.style.display = 'block';
        }
    };
    reader.readAsDataURL(file);
}

async function callGeminiReceiptExtractor(dataUrl, mimeType, apiKey) {
    const rawBase64 = dataUrl.split(',')[1] || dataUrl;
    const cleanMime = mimeType || 'image/jpeg';

    const promptText = `Eres un asistente experto en digitalización de remitos, facturas y comprobantes de compra de repuestos para motocicletas, accesorios y herramientas de talleres.
Analiza la imagen o PDF adjunto y extrae todos los productos o repuestos incluidos en la lista o tabla del comprobante.

Devuelve estrictamente un JSON con este formato exacto:
{
  "proveedor": "Nombre de la distribuidora o proveedor si figura en el encabezado (ej: WStandard, Distribuidora Motos, etc., o null)",
  "numero_comprobante": "Número de remito o factura (ej: 0001-00049281, o null)",
  "items": [
    {
      "codigo": "Código o SKU del artículo según figura en el remito",
      "descripcion": "Nombre o descripción clara del repuesto",
      "cantidad": 10,
      "costo_unitario": 1250.00
    }
  ]
}

Reglas obligatorias:
1. 'cantidad' debe ser un número positivo (no string).
2. 'costo_unitario' debe ser el precio unitario de costo o compra según figure en el comprobante (número flotante, no string). Si no tiene costo o sólo es remito de traslado sin precio, usa 0.
3. Si un artículo no tiene código explícito, genera un código alfanumérico corto y limpio representativo basado en el tipo de repuesto (ej: REP-BUJIA-110).
4. No incluyas subtotales ni impuestos como filas de productos.
5. Devuelve solo el JSON válido sin texto previo ni posterior.`;

    const body = {
        contents: [
            {
                parts: [
                    {
                        inlineData: {
                            mimeType: cleanMime,
                            data: rawBase64
                        }
                    },
                    {
                        text: promptText
                    }
                ]
            }
        ],
        generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json"
        }
    };

    const models = ['gemini-1.5-flash', 'gemini-2.0-flash', 'gemini-2.5-flash'];
    let lastError = null;

    for (const model of models) {
        try {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            if (!response.ok) {
                const errData = await response.json().catch(() => ({}));
                const msg = (errData.error && errData.error.message) || `HTTP ${response.status}`;
                lastError = new Error(msg);
                continue;
            }

            const result = await response.json();
            const textResponse = result.candidates?.[0]?.content?.parts?.[0]?.text;
            if (!textResponse) throw new Error("Respuesta vacía del modelo Gemini");

            const parsed = JSON.parse(textResponse.trim());
            return parsed;
        } catch (e) {
            lastError = e;
        }
    }

    throw lastError || new Error("No se pudo conectar con el servicio Gemini Vision.");
}

function guessCategoryFromText(text) {
    if (!text) return 'Repuestos de Motor';
    const t = text.toLowerCase();
    if (t.includes('aceite') || t.includes('lubricante') || t.includes('grasa') || t.includes('motul') || t.includes('castrol') || t.includes('valvoline')) {
        return 'Aceites';
    }
    if (t.includes('freno') || t.includes('pastilla') || t.includes('disco') || t.includes('zapata') || t.includes('caliper') || t.includes('bomba freno')) {
        return 'Frenos';
    }
    if (t.includes('cadena') || t.includes('corona') || t.includes('piñon') || t.includes('pinon') || t.includes('transmision') || t.includes('correa')) {
        return 'Transmisión';
    }
    if (t.includes('bujia') || t.includes('relay') || t.includes('bateria') || t.includes('bobina') || t.includes('cdi') || t.includes('estator') || t.includes('regulador') || t.includes('lampara') || t.includes('faro') || t.includes('giro')) {
        return 'Sistema Eléctrico';
    }
    if (t.includes('herramienta') || t.includes('llave') || t.includes('extractor') || t.includes('tubo') || t.includes('pinza')) {
        return 'Herramientas';
    }
    if (t.includes('casco') || t.includes('guante') || t.includes('candado') || t.includes('funda') || t.includes('parabrisa') || t.includes('espejo')) {
        return 'Accesorios';
    }
    return 'Repuestos de Motor';
}

function processExtractedReceiptData(receiptData) {
    if (!receiptData || !receiptData.items || receiptData.items.length === 0) {
        alert("El comprobante procesado no contiene artículos válidos.");
        return;
    }

    const supplierSelect = document.getElementById('staging-supplier-select');
    if (supplierSelect) {
        let optionsHtml = '<option value="">Proveedor general / No especificado</option>';
        (state.suppliers || []).forEach(s => {
            optionsHtml += `<option value="${s.id}">${s.name} ${s.phone ? `(${s.phone})` : ''}</option>`;
        });
        supplierSelect.innerHTML = optionsHtml;

        if (receiptData.proveedor) {
            const normP = receiptData.proveedor.toLowerCase();
            const matchedSupp = (state.suppliers || []).find(s => 
                s.name.toLowerCase().includes(normP) || normP.includes(s.name.toLowerCase())
            );
            if (matchedSupp) {
                supplierSelect.value = matchedSupp.id;
            }
        }
    }

    const invInput = document.getElementById('staging-invoice-num');
    if (invInput) {
        invInput.value = receiptData.numero_comprobante || '';
    }

    const defaultMargin = parseFloat(document.getElementById('staging-global-margin')?.value) || 40;

    tempStagingItems = receiptData.items.map((item, index) => {
        const itemCode = (item.codigo || `REP-${Date.now()}-${index + 1}`).trim().toUpperCase();
        const itemName = (item.descripcion || 'Repuesto sin descripción').trim();
        const itemQty = Math.max(1, parseFloat(item.cantidad) || 1);
        const itemCost = Math.max(0, parseFloat(item.costo_unitario) || 0);

        let existingProd = state.products.find(p => p.sku && p.sku.toUpperCase() === itemCode);
        
        if (!existingProd && itemName.length >= 6) {
            const normName = itemName.toLowerCase();
            existingProd = state.products.find(p => {
                const pNorm = (p.name || '').toLowerCase();
                return pNorm.includes(normName) || normName.includes(pNorm);
            });
        }

        const isNew = !existingProd;
        const category = existingProd ? existingProd.category : guessCategoryFromText(itemName);

        let price = 0;
        let priceWholesale = 0;

        if (existingProd) {
            if (itemCost > 0 && Math.abs(itemCost - (existingProd.cost || 0)) > 1) {
                price = Math.round(itemCost * (1 + (defaultMargin / 100)));
                priceWholesale = Math.round(itemCost * (1 + ((defaultMargin * 0.5) / 100)));
            } else {
                price = existingProd.price || Math.round(itemCost * (1 + (defaultMargin / 100)));
                priceWholesale = existingProd.priceWholesale || Math.round(price * 0.85);
            }
        } else {
            price = itemCost > 0 ? Math.round(itemCost * (1 + (defaultMargin / 100))) : 0;
            priceWholesale = itemCost > 0 ? Math.round(itemCost * (1 + ((defaultMargin * 0.5) / 100))) : 0;
        }

        return {
            id: isNew ? null : existingProd.id,
            isNew,
            sku: existingProd ? existingProd.sku : itemCode,
            name: existingProd ? existingProd.name : itemName,
            category,
            quantity: itemQty,
            cost: itemCost,
            price,
            priceWholesale,
            existingStock: existingProd ? (existingProd.stock || 0) : 0,
            targetLocation: 'local'
        };
    });

    const stepUpload = document.getElementById('reception-step-upload');
    const stepStaging = document.getElementById('reception-step-staging');
    const btnBack = document.getElementById('btn-reception-back');
    const btnProcess = document.getElementById('btn-reception-process-ai');
    const btnAuthorize = document.getElementById('btn-reception-authorize');

    if (stepUpload) stepUpload.style.display = 'none';
    if (stepStaging) stepStaging.style.display = 'block';
    if (btnBack) btnBack.style.display = 'inline-flex';
    if (btnProcess) btnProcess.style.display = 'none';
    if (btnAuthorize) btnAuthorize.style.display = 'inline-flex';

    renderStagingTable();
    if (window.lucide) lucide.createIcons();
}

function renderStagingTable() {
    const tbody = document.getElementById('staging-table-body');
    if (!tbody) return;

    if (tempStagingItems.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-muted" style="padding: 30px;">
                    No hay productos en la lista previa. Pulsa "+ Añadir Repuesto Manual" o vuelve al paso de escaneo.
                </td>
            </tr>
        `;
        updateStagingMetrics();
        return;
    }

    const categories = (state.settings && state.settings.categories) || ['Sistema Eléctrico', 'Repuestos de Motor', 'Frenos', 'Transmisión', 'Herramientas', 'Accesorios', 'Aceites'];

    let rowsHtml = '';
    tempStagingItems.forEach((item, index) => {
        let catOptions = '';
        categories.forEach(cat => {
            catOptions += `<option value="${cat}" ${cat === item.category ? 'selected' : ''}>${cat}</option>`;
        });

        const statusBadge = item.isNew
            ? `<span class="staging-badge-new" title="Producto nuevo. Se creará en el catálogo al autorizar."><i data-lucide="plus-circle" style="width: 12px; height: 12px;"></i> Nuevo</span>`
            : `<span class="staging-badge-existing" title="Producto ya existente. Se sumará al stock actual (${item.existingStock})."><i data-lucide="check-circle-2" style="width: 12px; height: 12px;"></i> Stock: ${item.existingStock}</span>`;

        rowsHtml += `
            <tr data-index="${index}">
                <td>${statusBadge}</td>
                <td>
                    <input type="text" class="staging-input" value="${item.sku || ''}" onchange="updateStagingItem(${index}, 'sku', this.value)" style="text-transform: uppercase; font-family: monospace; font-weight: 700;">
                </td>
                <td>
                    <input type="text" class="staging-input" value="${item.name || ''}" onchange="updateStagingItem(${index}, 'name', this.value)" placeholder="Descripción...">
                </td>
                <td>
                    <select class="staging-input" onchange="updateStagingItem(${index}, 'category', this.value)">
                        ${catOptions}
                    </select>
                </td>
                <td class="text-center">
                    <input type="number" class="staging-input staging-input-number" min="0.1" step="any" value="${item.quantity}" onchange="updateStagingItem(${index}, 'quantity', this.value)" style="width: 70px;">
                </td>
                <td class="text-right">
                    <input type="number" class="staging-input staging-input-number" min="0" step="any" value="${item.cost}" onchange="updateStagingItem(${index}, 'cost', this.value)" style="width: 95px;">
                </td>
                <td class="text-right">
                    <input type="number" class="staging-input staging-input-number" min="0" step="any" value="${item.price}" onchange="updateStagingItem(${index}, 'price', this.value)" style="width: 95px; color: var(--primary); font-weight: 700;">
                </td>
                <td class="text-right">
                    <input type="number" class="staging-input staging-input-number" min="0" step="any" value="${item.priceWholesale}" onchange="updateStagingItem(${index}, 'priceWholesale', this.value)" style="width: 95px;">
                </td>
                <td class="text-center">
                    <button type="button" class="btn-remove-staging" onclick="removeStagingRow(${index})" title="Eliminar fila">
                        <i data-lucide="trash-2" style="width: 15px; height: 15px;"></i>
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = rowsHtml;
    updateStagingMetrics();
    if (window.lucide) lucide.createIcons();
}

function updateStagingMetrics() {
    const totalCount = tempStagingItems.length;
    const newCount = tempStagingItems.filter(i => i.isNew).length;
    const existingCount = tempStagingItems.filter(i => !i.isNew).length;
    const totalCost = tempStagingItems.reduce((acc, i) => acc + (i.quantity * i.cost), 0);
    const currency = (state.settings && state.settings.currency) || '$';

    const elTotal = document.getElementById('staging-metric-total');
    const elNew = document.getElementById('staging-metric-new');
    const elExisting = document.getElementById('staging-metric-existing');
    const elCost = document.getElementById('staging-metric-cost');

    if (elTotal) elTotal.textContent = totalCount;
    if (elNew) elNew.textContent = newCount;
    if (elExisting) elExisting.textContent = existingCount;
    if (elCost) elCost.textContent = `${currency}${totalCost.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

window.updateStagingItem = function(index, field, value) {
    if (!tempStagingItems[index]) return;
    const item = tempStagingItems[index];

    if (field === 'quantity') {
        item.quantity = Math.max(0.1, parseFloat(value) || 1);
        updateStagingMetrics();
    } else if (field === 'cost') {
        item.cost = Math.max(0, parseFloat(value) || 0);
        const defaultMargin = parseFloat(document.getElementById('staging-global-margin')?.value) || 40;
        item.price = Math.round(item.cost * (1 + (defaultMargin / 100)));
        item.priceWholesale = Math.round(item.cost * (1 + ((defaultMargin * 0.5) / 100)));
        renderStagingTable();
    } else if (field === 'price') {
        item.price = Math.max(0, parseFloat(value) || 0);
    } else if (field === 'priceWholesale') {
        item.priceWholesale = Math.max(0, parseFloat(value) || 0);
    } else if (field === 'sku') {
        item.sku = (value || '').trim().toUpperCase();
        const matched = state.products.find(p => p.sku && p.sku.toUpperCase() === item.sku);
        if (matched) {
            item.isNew = false;
            item.id = matched.id;
            item.existingStock = matched.stock || 0;
            item.category = matched.category;
        } else {
            item.isNew = true;
            item.id = null;
            item.existingStock = 0;
        }
        renderStagingTable();
    } else if (field === 'name') {
        item.name = (value || '').trim();
    } else if (field === 'category') {
        item.category = value;
    }
};

window.removeStagingRow = function(index) {
    tempStagingItems.splice(index, 1);
    renderStagingTable();
};

window.addManualStagingRow = function() {
    const defaultMargin = parseFloat(document.getElementById('staging-global-margin')?.value) || 40;
    const categories = (state.settings && state.settings.categories) || ['Repuestos de Motor'];
    tempStagingItems.push({
        id: null,
        isNew: true,
        sku: `REP-${Date.now().toString().slice(-6)}`,
        name: 'Nuevo Repuesto',
        category: categories[0] || 'Repuestos de Motor',
        quantity: 1,
        cost: 0,
        price: 0,
        priceWholesale: 0,
        existingStock: 0,
        targetLocation: 'local'
    });
    renderStagingTable();
};

window.applyGlobalMarginToStaging = function() {
    const margin = parseFloat(document.getElementById('staging-global-margin')?.value) || 40;
    tempStagingItems.forEach(item => {
        if (item.cost > 0) {
            item.price = Math.round(item.cost * (1 + (margin / 100)));
            item.priceWholesale = Math.round(item.cost * (1 + ((margin * 0.5) / 100)));
        }
    });
    renderStagingTable();
    playScanSound('success');
};

window.authorizeStockReception = function() {
    if (!tempStagingItems || tempStagingItems.length === 0) {
        alert("No hay ningún producto en la lista de Carga Prevista para autorizar.");
        return;
    }

    // Validate that items have SKU and description
    for (let i = 0; i < tempStagingItems.length; i++) {
        const it = tempStagingItems[i];
        if (!it.sku || !it.sku.trim()) {
            alert(`El artículo #${i + 1} no tiene un Código/SKU válido. Por favor complétalo.`);
            return;
        }
        if (!it.name || !it.name.trim()) {
            alert(`El artículo con SKU ${it.sku} no tiene descripción. Por favor complétala.`);
            return;
        }
    }

    let created = 0;
    let updated = 0;
    let totalUnits = 0;
    let totalCost = 0;

    tempStagingItems.forEach(item => {
        const qty = Math.max(0.1, parseFloat(item.quantity) || 1);
        const cost = Math.max(0, parseFloat(item.cost) || 0);
        const price = Math.max(0, parseFloat(item.price) || 0);
        const priceWholesale = Math.max(0, parseFloat(item.priceWholesale) || 0);
        const skuUpper = item.sku.trim().toUpperCase();

        let prod = null;
        if (!item.isNew && item.id) {
            prod = state.products.find(p => p.id === item.id);
        }
        if (!prod) {
            prod = state.products.find(p => p.sku && p.sku.toUpperCase() === skuUpper);
        }

        if (prod) {
            // Update existing product
            prod.stock = (parseFloat(prod.stock) || 0) + qty;
            prod.cost = cost;
            prod.price = price;
            prod.priceWholesale = priceWholesale;
            prod.priceDiscount = priceWholesale;
            if (item.category) prod.category = item.category;
            updated++;
        } else {
            // Create new product
            state.products.push({
                id: `p_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
                sku: skuUpper,
                name: item.name.trim(),
                category: item.category || 'Repuestos de Motor',
                cost: cost,
                price: price,
                priceWholesale: priceWholesale,
                priceDiscount: priceWholesale,
                stock: qty,
                stockMin: 5,
                stockWholesale: 0,
                stockMinWholesale: 5,
                isCombo: false,
                components: [],
                image: '',
                isFractional: false
            });
            created++;
        }

        totalUnits += qty;
        totalCost += (qty * cost);
    });

    const supplierId = document.getElementById('staging-supplier-select')?.value || null;
    const supplierObj = (state.suppliers || []).find(s => s.id === supplierId);
    const supplierName = supplierObj ? supplierObj.name : 'Distribuidor General';
    const invoiceNum = (document.getElementById('staging-invoice-num')?.value || '').trim() || 'S/N';

    // Log the reception in state.receptions
    if (!state.receptions) state.receptions = [];
    state.receptions.push({
        id: `rec_${Date.now()}`,
        date: new Date().toISOString(),
        invoiceNum,
        supplierId,
        supplierName,
        itemsCount: tempStagingItems.length,
        totalUnits,
        totalCost,
        items: tempStagingItems.map(i => ({
            sku: i.sku,
            name: i.name,
            quantity: i.quantity,
            cost: i.cost,
            price: i.price,
            isNew: i.isNew
        }))
    });

    // Register cash outflow if checkbox is active
    const registerCash = document.getElementById('staging-register-cash-outflow')?.checked;
    if (registerCash && totalCost > 0) {
        if (!state.cashMovements) state.cashMovements = [];
        state.cashMovements.push({
            id: `cm_${Date.now()}`,
            date: new Date().toISOString(),
            type: 'outflow',
            amount: totalCost,
            concept: `Compra mercadería - Remito ${invoiceNum} (${supplierName})`
        });
    }

    saveDatabase();
    closeModal('modal-reception-ai');

    // Reset temporary variables
    tempStagingItems = [];
    tempReceptionFileBase64 = null;
    tempReceptionFile = null;

    // Refresh UI views
    inventoryPage = 1;
    renderInventory();
    if (typeof renderCajaDashboard === 'function') renderCajaDashboard();
    playScanSound('success');

    const currency = (state.settings && state.settings.currency) || '$';
    alert(`¡Carga de Stock Autorizada e Impactada con Éxito!\n\n` +
          `• ${created} repuestos nuevos creados en catálogo.\n` +
          `• ${updated} repuestos existentes con stock actualizado.\n` +
          `• Total de unidades ingresadas: ${totalUnits}\n` +
          `• Costo total de compra: ${currency}${totalCost.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
};

/* ==========================================================================
   9. SUPERADMIN CASHIER MANAGEMENT PANEL
   ========================================================================== */
async function renderCajerosList() {
    if (!supabaseInitialized || currentUserRole !== 'superadmin') return;

    const tbody = document.getElementById('cajeros-table-body');
    if (!tbody) return;

    tbody.innerHTML = `
        <tr>
            <td colspan="5" class="text-center text-muted" style="padding: 20px;">
                <i data-lucide="loader" class="animate-spin" style="animation: spin 1s linear infinite;"></i> Cargando personal...
            </td>
        </tr>
    `;
    if (window.lucide) lucide.createIcons();

    try {
        const { data: profiles, error } = await supabaseClient
            .from('user_profiles')
            .select('*')
            .order('email', { ascending: true });

        if (error) throw error;

        if (!profiles || profiles.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center text-muted" style="padding: 20px;">
                        No hay personal registrado.
                    </td>
                </tr>
            `;
            return;
        }

        const session = (await supabaseClient.auth.getSession()).data.session;
        const currentUid = session ? session.user.id : null;

        let rowsHtml = '';
        profiles.forEach(p => {
            const isSelf = p.id === currentUid;
            const selectDisabled = isSelf ? 'disabled' : '';

            rowsHtml += `
                <tr>
                    <td style="font-weight: 600;">${p.email}</td>
                    <td>${p.dni || '-'}</td>
                    <td>${p.first_name || ''} ${p.last_name || ''}</td>
                    <td>
                        <select onchange="updateCajeroRole('${p.id}', this.value)" ${selectDisabled} style="padding: 4px 8px; font-size: 12px; width: auto; height: auto;">
                            <option value="usuario" ${p.role === 'usuario' ? 'selected' : ''}>Usuario / Cliente</option>
                            <option value="admin" ${p.role === 'admin' ? 'selected' : ''}>Cajero (Admin)</option>
                            <option value="superadmin" ${p.role === 'superadmin' ? 'selected' : ''}>Superadmin</option>
                        </select>
                    </td>
                    <td class="text-center">
                        <button class="btn btn-danger btn-outline btn-icon-only" onclick="deleteCajero('${p.id}')" ${selectDisabled} title="Eliminar Cajero" style="width: 28px; height: 28px;">
                            <i data-lucide="trash-2" style="width:12px; height:12px;"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        tbody.innerHTML = rowsHtml;
        if (window.lucide) lucide.createIcons();
    } catch (err) {
        console.error("Error rendering cajeros:", err);
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-danger" style="padding: 20px;">
                    Error al cargar personal: ${err.message}
                </td>
            </tr>
        `;
    }
}

window.updateCajeroRole = async function (userId, newRole) {
    if (!supabaseInitialized || currentUserRole !== 'superadmin') return;

    try {
        const { error } = await supabaseClient
            .from('user_profiles')
            .update({ role: newRole })
            .eq('id', userId);

        if (error) throw error;

        playScanSound('success');
        alert("Rol de usuario actualizado correctamente.");
        renderCajerosList();
    } catch (err) {
        console.error("Error updating role:", err);
        alert("Error al actualizar rol: " + err.message);
        renderCajerosList();
    }
};

window.deleteCajero = async function (userId) {
    if (!supabaseInitialized || currentUserRole !== 'superadmin') return;

    if (confirm("¿Estás seguro de que deseas eliminar este usuario del sistema? Se eliminará de la base de datos y de la autenticación.")) {
        try {
            if (supabaseAdmin) {
                const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(userId);
                if (authError) throw authError;
            } else {
                const { error: dbError } = await supabaseClient
                    .from('user_profiles')
                    .delete()
                    .eq('id', userId);
                if (dbError) throw dbError;
            }

            playScanSound('fail');
            alert("Usuario eliminado correctamente.");
            renderCajerosList();
        } catch (err) {
            console.error("Error deleting cashier:", err);
            alert("Error al eliminar cajero: " + err.message);
            renderCajerosList();
        }
    }
};

function setupCajeroRegistration() {
    const form = document.getElementById('new-cajero-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (!supabaseInitialized || currentUserRole !== 'superadmin') {
            alert("Acción no permitida.");
            return;
        }

        alert("🔒 REGISTRO SEGURO ACTIVO:\n\nPara registrar un nuevo cajero en producción de forma segura (sin exponer claves secretas ni de administración en el navegador):\n\n1. Invita al usuario a tu proyecto desde el panel de Supabase (Authentication -> Users -> Invite User) enviándole un correo de acceso.\n2. Una vez que el usuario cree su cuenta, aparecerá en el listado inferior automáticamente y podrás cambiar su rol a 'Cajero' y asignarle la tienda.");
    });
}

/* ==========================================================================
   10. SAAS GLOBAL ADMIN CONTROLLERS
   ========================================================================== */
async function loadSaasStores() {
    if (!supabaseInitialized || currentUserRole !== 'saas_admin') return;

    const tbody = document.getElementById('saas-stores-table-body');
    if (!tbody) return;

    tbody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center text-muted" style="padding: 20px;">
                <i data-lucide="loader" class="animate-spin" style="animation: spin 1s linear infinite;"></i> Cargando empresas...
            </td>
        </tr>
    `;
    if (window.lucide) lucide.createIcons();

    try {
        const { data: stores, error } = await supabaseClient
            .from('stores')
            .select('*')
            .order('created_at', { ascending: false });

        if (error) throw error;

        if (!stores || stores.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center text-muted" style="padding: 20px;">
                        No hay empresas registradas en la plataforma.
                    </td>
                </tr>
            `;
            return;
        }

        let rowsHtml = '';
        stores.forEach(s => {
            rowsHtml += `
                <tr>
                    <td style="font-family: monospace; font-size: 12px;" class="text-muted">${s.id}</td>
                    <td style="font-weight: 600;">${s.name}</td>
                    <td>${new Date(s.created_at).toLocaleDateString('es-ES')}</td>
                    <td class="text-center">
                        <button class="btn btn-secondary btn-icon-only" onclick="navigator.clipboard.writeText('${s.id}')" title="Copiar ID" style="width: 28px; height: 28px;">
                            <i data-lucide="copy" style="width:12px; height:12px;"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        tbody.innerHTML = rowsHtml;
        if (window.lucide) lucide.createIcons();
    } catch (err) {
        console.error("Error loading stores:", err);
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger" style="padding: 20px;">
                    Error al cargar empresas: ${err.message}
                </td>
            </tr>
        `;
    }
}

window.createNewSaasStore = async function () {
    if (!supabaseInitialized || currentUserRole !== 'saas_admin') return;

    const storeName = document.getElementById('saas-store-name').value.trim();
    if (!storeName) {
        alert("El nombre comercial es requerido.");
        return;
    }

    try {
        const { data, error } = await supabaseClient
            .from('stores')
            .insert([{ name: storeName }])
            .select();

        if (error) throw error;

        playScanSound('success');
        alert("Empresa creada exitosamente. El ID se mostrará en la tabla.");
        document.getElementById('saas-new-store-form').reset();
        closeModal('modal-saas-store');
        loadSaasStores();
    } catch (err) {
        console.error("Error creating store:", err);
        alert("Error al crear empresa: " + err.message);
    }
};

/* ==========================================================================
   Catalog Shopping Cart Logic
   ========================================================================== */
let catalogCart = [];

window.addCatalogCartItem = function (productId) {
    const product = state.products.find(p => p.id === productId);
    if (!product) return;

    if (product.stock <= 0) {
        playScanSound('fail');
        alert(`El artículo "${product.name}" no tiene stock disponible.`);
        return;
    }

    const existing = catalogCart.find(item => item.id === productId);
    if (existing) {
        if (existing.quantity >= product.stock) {
            playScanSound('warning');
            alert(`No puedes agregar más unidades. Stock máximo disponible: ${product.stock}`);
            return;
        }
        existing.quantity += 1;
    } else {
        catalogCart.push({
            id: product.id,
            sku: product.sku,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }

    playScanSound('success');
    renderCatalogCart();

    // Add pulse animation feedback to cart button
    const fabBtn = document.getElementById('catalog-cart-btn');
    if (fabBtn) {
        fabBtn.classList.add('pulse-animation');
        setTimeout(() => fabBtn.classList.remove('pulse-animation'), 500);
    }
};

window.updateCatalogCartItemQty = function (productId, delta) {
    const item = catalogCart.find(i => i.id === productId);
    if (!item) return;

    const product = state.products.find(p => p.id === productId);
    if (!product) return;

    const newQty = item.quantity + delta;
    if (newQty <= 0) {
        window.removeCatalogCartItem(productId);
        return;
    }

    if (newQty > product.stock) {
        playScanSound('warning');
        alert(`Stock máximo disponible: ${product.stock}`);
        return;
    }

    item.quantity = newQty;
    playScanSound('success');
    renderCatalogCart();
};

window.removeCatalogCartItem = function (productId) {
    catalogCart = catalogCart.filter(i => i.id !== productId);
    playScanSound('warning');
    renderCatalogCart();
};

window.renderCatalogCart = function () {
    const container = document.getElementById('catalog-cart-items-container');
    const badge = document.getElementById('catalog-cart-badge');
    const totalDisplay = document.getElementById('catalog-cart-total');
    const checkoutBtn = document.getElementById('catalog-cart-checkout-btn');
    const currency = state.settings.currency || '$';

    if (!container) return;

    const totalItems = catalogCart.reduce((sum, item) => sum + item.quantity, 0);

    let totalPrice = 0;
    catalogCart.forEach(item => {
        const prod = state.products.find(p => p.id === item.id);
        const retailPrice = prod ? prod.price : item.price;
        const wholesalePrice = prod ? (parseFloat(prod.priceWholesale !== undefined ? prod.priceWholesale : prod.priceDiscount) || 0) : 0;
        const isWholesaleActive = item.quantity >= 5 && wholesalePrice > 0 && wholesalePrice < retailPrice;
        const unitPrice = isWholesaleActive ? wholesalePrice : retailPrice;
        totalPrice += unitPrice * item.quantity;
    });

    if (badge) {
        if (totalItems > 0) {
            badge.textContent = totalItems;
            badge.style.display = 'block';
        } else {
            badge.style.display = 'none';
        }
    }

    if (totalDisplay) {
        totalDisplay.textContent = `${currency}${totalPrice.toFixed(2)}`;
    }

    if (catalogCart.length === 0) {
        container.innerHTML = `
            <div class="cart-empty-state">
                <i data-lucide="shopping-cart" class="cart-empty-icon" style="width: 48px; height: 48px; opacity: 0.3; margin-bottom: 10px;"></i>
                <p>Tu carrito está vacío.</p>
                <span style="font-size: 12px; color: var(--text-muted);">Agrega productos del catálogo para comenzar.</span>
            </div>
        `;
        if (checkoutBtn) checkoutBtn.disabled = true;
    } else {
        if (checkoutBtn) checkoutBtn.disabled = false;
        let itemsHtml = '';
        catalogCart.forEach(item => {
            const prod = state.products.find(p => p.id === item.id);
            const retailPrice = prod ? prod.price : item.price;
            const wholesalePrice = prod ? (parseFloat(prod.priceWholesale !== undefined ? prod.priceWholesale : prod.priceDiscount) || 0) : 0;
            const hasWholesaleOption = wholesalePrice > 0 && wholesalePrice < retailPrice;
            const isWholesaleActive = item.quantity >= 5 && hasWholesaleOption;
            const unitPrice = isWholesaleActive ? wholesalePrice : retailPrice;
            const itemSubtotal = unitPrice * item.quantity;

            let priceDisplayHtml = `<div class="catalog-cart-item-price">${currency}${unitPrice.toFixed(2)} c/u</div>`;
            if (isWholesaleActive) {
                priceDisplayHtml = `
                    <div class="catalog-cart-item-price">
                        <span style="text-decoration: line-through; font-size: 11px; color: var(--text-muted); margin-right: 4px;">${currency}${retailPrice.toFixed(2)}</span>
                        <strong>${currency}${unitPrice.toFixed(2)} c/u</strong>
                    </div>
                    <div class="cart-wholesale-badge"><i data-lucide="sparkles" style="width:10px; height:10px;"></i> Precio Mayorista Aplicado</div>
                `;
            } else if (hasWholesaleOption) {
                const needed = 5 - item.quantity;
                priceDisplayHtml += `<div class="cart-wholesale-hint">💡 Faltan ${needed} un. para precio mayorista (${currency}${wholesalePrice.toFixed(2)})</div>`;
            }

            itemsHtml += `
                <div class="catalog-cart-item">
                    <div class="catalog-cart-item-details">
                        <div class="catalog-cart-item-title">${item.name}</div>
                        ${priceDisplayHtml}
                    </div>
                    <div class="catalog-cart-item-qty-actions">
                        <button class="qty-btn" onclick="updateCatalogCartItemQty('${item.id}', -1)">-</button>
                        <span class="qty-val">${item.quantity}</span>
                        <button class="qty-btn" onclick="updateCatalogCartItemQty('${item.id}', 1)">+</button>
                    </div>
                    <div class="catalog-cart-item-total">
                        ${currency}${itemSubtotal.toFixed(2)}
                    </div>
                    <button class="btn btn-icon" onclick="removeCatalogCartItem('${item.id}')" style="color: var(--danger); margin-left: 10px;" title="Eliminar del carrito">
                        <i data-lucide="trash-2" style="width: 16px; height: 16px;"></i>
                    </button>
                </div>
            `;
        });
        container.innerHTML = itemsHtml;
    }

    if (window.lucide) lucide.createIcons();
};

window.openCatalogCartModal = function () {
    renderCatalogCart();
    openModal('modal-catalog-cart');
};

window.openCatalogCheckoutModal = function () {
    closeModal('modal-catalog-cart');

    const summaryContainer = document.getElementById('cat-checkout-items-summary');
    const totalDisplay = document.getElementById('cat-checkout-total-display');
    const currency = state.settings.currency || '$';

    let totalPrice = 0;
    if (summaryContainer) {
        let summaryHtml = '';
        catalogCart.forEach(item => {
            const prod = state.products.find(p => p.id === item.id);
            const retailPrice = prod ? prod.price : item.price;
            const wholesalePrice = prod ? (parseFloat(prod.priceWholesale !== undefined ? prod.priceWholesale : prod.priceDiscount) || 0) : 0;
            const isWholesaleActive = item.quantity >= 5 && wholesalePrice > 0 && wholesalePrice < retailPrice;
            const unitPrice = isWholesaleActive ? wholesalePrice : retailPrice;
            const itemSubtotal = unitPrice * item.quantity;
            totalPrice += itemSubtotal;

            const badgeHtml = isWholesaleActive ? `<small style="color: var(--primary); font-weight: bold; margin-left: 4px;">(Mayorista 5+ un.)</small>` : '';

            summaryHtml += `
                <div style="display: flex; justify-content: space-between; margin-bottom: 4px; font-size: 13px;">
                    <span>${item.quantity}x ${item.name}${badgeHtml}</span>
                    <span>${currency}${itemSubtotal.toFixed(2)}</span>
                </div>
            `;
        });
        summaryContainer.innerHTML = summaryHtml;
    } else {
        catalogCart.forEach(item => {
            const prod = state.products.find(p => p.id === item.id);
            const retailPrice = prod ? prod.price : item.price;
            const wholesalePrice = prod ? (parseFloat(prod.priceWholesale !== undefined ? prod.priceWholesale : prod.priceDiscount) || 0) : 0;
            const isWholesaleActive = item.quantity >= 5 && wholesalePrice > 0 && wholesalePrice < retailPrice;
            const unitPrice = isWholesaleActive ? wholesalePrice : retailPrice;
            totalPrice += unitPrice * item.quantity;
        });
    }

    if (totalDisplay) {
        totalDisplay.textContent = `${currency}${totalPrice.toFixed(2)}`;
    }

    const catDisplayAlias = document.getElementById('cat-display-alias');
    if (catDisplayAlias) {
        catDisplayAlias.textContent = state.settings.storeAlias || 'DHMOTOPARTES';
    }
    const catDisplayHolder = document.getElementById('cat-display-holder');
    if (catDisplayHolder) {
        catDisplayHolder.textContent = state.settings.storeHolder || 'DANIEL OSCAR HIDALGO';
    }

    const paymentSelect = document.getElementById('cat-cust-payment');
    const transferInfo = document.getElementById('catalog-checkout-transfer-info');
    if (paymentSelect && transferInfo) {
        const toggleTransferInfo = () => {
            const val = paymentSelect.value;
            if (val.includes('Transferencia') || val.includes('Mercado Pago')) {
                transferInfo.style.display = 'block';
            } else {
                transferInfo.style.display = 'none';
            }
        };
        toggleTransferInfo();
        paymentSelect.onchange = toggleTransferInfo;
    }

    openModal('modal-catalog-checkout');
};

window.copyStoreAlias = function () {
    const alias = (state.settings && state.settings.storeAlias) || 'DHMOTOPARTES';
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(alias).then(() => {
            const textSpan = document.getElementById('copy-alias-text');
            if (textSpan) {
                const orig = textSpan.textContent;
                textSpan.textContent = '¡Copiado!';
                setTimeout(() => { textSpan.textContent = orig; }, 2000);
            }
        }).catch(err => {
            console.error('Failed to copy alias:', err);
        });
    } else {
        alert(`Alias: ${alias}`);
    }
};

window.backToCatalogCart = function () {
    closeModal('modal-catalog-checkout');
    openModal('modal-catalog-cart');
};

window.sendCatalogOrder = function (e) {
    if (e) e.preventDefault();

    const name = document.getElementById('cat-cust-name').value.trim();
    const phone = document.getElementById('cat-cust-phone').value.trim();
    const address = document.getElementById('cat-cust-address').value.trim();
    const payment = document.getElementById('cat-cust-payment').value;

    if (!name || !phone || !address || !payment) {
        alert("Por favor completa todos los campos obligatorios.");
        return;
    }

    const currency = state.settings.currency || '$';
    let totalPrice = 0;
    const storeName = state.settings.storeName || "DHMotopartes";

    let message = `*¡Hola ${storeName}!* Me gustaría realizar el siguiente pedido:\n\n`;
    message += `*🛒 DETALLE DEL PEDIDO:*\n`;
    catalogCart.forEach(item => {
        const prod = state.products.find(p => p.id === item.id);
        const retailPrice = prod ? prod.price : item.price;
        const wholesalePrice = prod ? (parseFloat(prod.priceWholesale !== undefined ? prod.priceWholesale : prod.priceDiscount) || 0) : 0;
        const isWholesaleActive = item.quantity >= 5 && wholesalePrice > 0 && wholesalePrice < retailPrice;
        const unitPrice = isWholesaleActive ? wholesalePrice : retailPrice;
        const itemSubtotal = unitPrice * item.quantity;
        totalPrice += itemSubtotal;

        const wsTag = isWholesaleActive ? ' - _Mayorista 5+ un._' : '';
        message += `- ${item.quantity}x _${item.name}_ (${currency}${unitPrice.toFixed(2)} c/u${wsTag}) -> *Total: ${currency}${itemSubtotal.toFixed(2)}*\n`;
    });
    message += `\n*💰 TOTAL A PAGAR:* *${currency}${totalPrice.toFixed(2)}*\n\n`;

    message += `*👤 DATOS DEL CLIENTE:*\n`;
    message += `- *Nombre:* ${name}\n`;
    message += `- *WhatsApp/Teléfono:* ${phone}\n`;
    message += `- *Dirección / Notas:* ${address}\n`;
    message += `- *Método de Pago:* ${payment}\n`;
    if (payment.includes('Transferencia') || payment.includes('Mercado Pago')) {
        const alias = state.settings.storeAlias || 'DHMOTOPARTES';
        const holder = state.settings.storeHolder || 'DANIEL OSCAR HIDALGO';
        message += `- *Alias para Transferir:* ${alias}\n`;
        message += `- *Titular de la Cuenta:* ${holder}\n`;
    }
    message += `\n`;

    message += `Quedo atento/a para coordinar la entrega y el pago. ¡Muchas gracias!`;

    let waNumber = state.settings.whatsapp || "+5491155551234";
    waNumber = waNumber.replace(/[^\d]/g, '');

    const waUrl = `https://api.whatsapp.com/send?phone=${waNumber}&text=${encodeURIComponent(message)}`;

    window.open(waUrl, '_blank');

    catalogCart = [];
    renderCatalogCart();
    closeModal('modal-catalog-checkout');
    document.getElementById('catalog-checkout-form').reset();

    alert("¡Pedido generado con éxito! Se ha abierto una pestaña para enviar el mensaje por WhatsApp.");
};

// ==========================================================================
// COMBOS & BUNDLES UTILITIES & EVENT HANDLERS
// ==========================================================================
let tempComboComponents = [];

window.getComboStock = function(comboProduct, stockSource = 'local') {
    if (!comboProduct.components || comboProduct.components.length === 0) return 0;
    let minStock = Infinity;
    comboProduct.components.forEach(comp => {
        const realProduct = state.products.find(p => p.id === comp.id);
        if (realProduct) {
            const currentStock = stockSource === 'wholesale' ? (realProduct.stockWholesale || 0) : realProduct.stock;
            const maxCombosFromComp = Math.floor(currentStock / comp.quantity);
            if (maxCombosFromComp < minStock) {
                minStock = maxCombosFromComp;
            }
        } else {
            minStock = 0; // component product missing
        }
    });
    return minStock === Infinity ? 0 : minStock;
};

window.updateComboComponentsTable = function() {
    const tbody = document.getElementById('combo-components-tbody');
    const currency = state.settings.currency || '$';
    if (!tbody) return;

    if (tempComboComponents.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-muted" style="padding: 15px;">
                    No hay componentes agregados a este combo.
                </td>
            </tr>
        `;
        document.getElementById('combo-suggested-prices').textContent = "Componentes sumados: L2 Costo $0.00 | L1 Público $0.00";
        return;
    }

    let html = '';
    let totalCost = 0;
    let totalPrice = 0;

    tempComboComponents.forEach((comp, idx) => {
        const itemTotalCost = comp.cost * comp.quantity;
        const itemTotalPrice = comp.price * comp.quantity;
        totalCost += itemTotalCost;
        totalPrice += itemTotalPrice;

        html += `
            <tr>
                <td style="font-weight: 700;">${comp.sku}</td>
                <td>${comp.name}</td>
                <td class="text-center">
                    <input type="number" min="1" value="${comp.quantity}" style="width: 60px; padding: 4px; text-align: center; margin: 0;" onchange="updateComboComponentQty(${idx}, this.value)">
                </td>
                <td class="text-right">${currency}${comp.price.toFixed(2)}</td>
                <td class="text-center">
                    <button type="button" class="btn btn-icon" style="color: var(--danger); padding: 4px;" onclick="removeComboComponent(${idx})">
                        <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
    document.getElementById('combo-suggested-prices').textContent = `Componentes sumados: L2 Costo ${currency}${totalCost.toFixed(2)} | L1 Público ${currency}${totalPrice.toFixed(2)}`;
    
    const applyBtn = document.getElementById('combo-apply-suggested-btn');
    if (applyBtn) {
        applyBtn.dataset.cost = totalCost;
        applyBtn.dataset.price = totalPrice;
        applyBtn.dataset.wholesale = totalPrice * 0.9;
    }

    if (window.lucide) lucide.createIcons();
};

window.updateComboComponentQty = function(idx, val) {
    const qty = parseInt(val) || 1;
    if (tempComboComponents[idx]) {
        tempComboComponents[idx].quantity = qty;
        window.updateComboComponentsTable();
    }
};

window.removeComboComponent = function(idx) {
    tempComboComponents.splice(idx, 1);
    window.updateComboComponentsTable();
};

window.handleComboSearch = function(e) {
    const query = e.target.value.toLowerCase().trim();
    const resultsContainer = document.getElementById('combo-search-results');
    if (!resultsContainer) return;

    if (!query) {
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';
        return;
    }

    const currentProdId = document.getElementById('product-id-field').value;

    const matches = state.products.filter(p => {
        return !p.isCombo && 
               p.id !== currentProdId && 
               (p.name.toLowerCase().includes(query) || p.sku.toLowerCase().includes(query));
    });

    if (matches.length === 0) {
        resultsContainer.innerHTML = '<div style="padding: 10px; color: var(--text-muted); font-size: 13px;">No se encontraron productos simples.</div>';
        resultsContainer.style.display = 'block';
        return;
    }

    let html = '';
    matches.slice(0, 5).forEach(p => {
        html += `
            <div class="search-result-item" style="padding: 10px; cursor: pointer; border-bottom: 1px solid var(--border-color); font-size: 13px; display: flex; justify-content: space-between; align-items: center;" onclick="addComboComponentById('${p.id}')" onmouseover="this.style.background='rgba(31,41,55,0.8)'" onmouseout="this.style.background='transparent'">
                <div>
                    <span style="font-weight: 700;">${p.sku}</span> - <span>${p.name}</span>
                </div>
                <span style="font-weight: 600; color: var(--primary);">${state.settings.currency}${p.price.toFixed(2)}</span>
            </div>
        `;
    });
    
    resultsContainer.innerHTML = html;
    resultsContainer.style.display = 'block';
};

window.addComboComponentById = function(prodId) {
    const p = state.products.find(prod => prod.id === prodId);
    if (!p) return;

    const exists = tempComboComponents.find(comp => comp.id === prodId);
    if (exists) {
        exists.quantity += 1;
    } else {
        tempComboComponents.push({
            id: p.id,
            sku: p.sku,
            name: p.name,
            price: p.price,
            cost: p.cost,
            quantity: 1
        });
    }

    const searchInput = document.getElementById('combo-search-input');
    if (searchInput) searchInput.value = '';
    const resultsContainer = document.getElementById('combo-search-results');
    if (resultsContainer) {
        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'none';
    }

    window.updateComboComponentsTable();
};
