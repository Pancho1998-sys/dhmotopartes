@echo off
title DHMotopartes - Instalador
echo.
echo ======================================================
echo   DHMotopartes - Instalador
echo ======================================================
echo.
echo Esto instalara DHMotopartes en tu PC y creara un
echo acceso directo en el Escritorio.
echo.
set DEST=C:\DHMotopartes
set SRC=%~dp0

echo Copiando archivos a %DEST% ...
if not exist "%DEST%" mkdir "%DEST%"

for %%f in (DHMotopartes-Server.exe index.html app.js components.js fiscal.js style.css supabase-config.js xlsx.full.min.js) do (
    if exist "%SRC%%%f" (
        copy /y "%SRC%%%f" "%DEST%\%%f" >nul
        echo   OK  %%f
    )
)

if not exist "%DEST%\dhmotopartes_db.json" (
    copy /y "%SRC%dhmotopartes_db.json" "%DEST%\dhmotopartes_db.json" >nul
    echo   OK  dhmotopartes_db.json (base de datos nueva)
) else (
    echo   OK  dhmotopartes_db.json (conservada - ya existe)
)

echo.
echo Creando acceso directo en el Escritorio...
powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut([System.IO.Path]::Combine([System.Environment]::GetFolderPath('Desktop'), 'DHMotopartes.lnk')); $SC.TargetPath = '%DEST%\DHMotopartes-Server.exe'; $SC.WorkingDirectory = '%DEST%'; $SC.Description = 'DHMotopartes - Sistema de Gestion'; $SC.Save()"
echo   OK  Acceso directo creado en el Escritorio

echo.
set /p INICIO=Deseas que DHMotopartes inicie automaticamente con Windows? (s/n): 
if /i "%INICIO%"=="s" (
    powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut([System.IO.Path]::Combine([System.Environment]::GetFolderPath('Startup'), 'DHMotopartes.lnk')); $SC.TargetPath = '%DEST%\DHMotopartes-Server.exe'; $SC.WorkingDirectory = '%DEST%'; $SC.Description = 'DHMotopartes - Sistema de Gestion'; $SC.Save()"
    echo   OK  DHMotopartes arrancara automaticamente con Windows
) else (
    echo   OK  Inicio automatico omitido
)

echo.
echo ======================================================
echo   Instalacion completada!
echo   Usa el acceso directo "DHMotopartes" del Escritorio
echo ======================================================
echo.
pause
