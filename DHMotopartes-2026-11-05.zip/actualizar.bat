@echo off
title DHMotopartes - Actualizador
echo.
echo ======================================================
echo   DHMotopartes - Actualizador de version
echo ======================================================
echo.
echo Este script actualiza los archivos del sistema
echo SIN borrar tu base de datos (ventas, productos, etc).
echo.
set /p DEST=Escribe la ruta donde esta instalado DHMotopartes (ej: C:\DHMotopartes): 
echo.

if not exist "%DEST%" (
    echo ERROR: La carpeta "%DEST%" no existe.
    pause
    exit /b 1
)

if not exist "%DEST%\DHMotopartes-Server.exe" (
    echo ERROR: No se encontro DHMotopartes-Server.exe en "%DEST%".
    echo Verifica que sea la carpeta correcta de instalacion.
    pause
    exit /b 1
)

echo Actualizando archivos...
set SRC=%~dp0

for %%f in (DHMotopartes-Server.exe index.html app.js components.js fiscal.js style.css supabase-config.js xlsx.full.min.js) do (
    if exist "%SRC%%%f" (
        copy /y "%SRC%%%f" "%DEST%\%%f" >nul
        echo   OK  %%f
    )
)

echo.
echo ======================================================
echo   Actualizacion completada exitosamente!
echo   Tu base de datos NO fue modificada.
echo   Ya podes abrir DHMotopartes-Server.exe normalmente.
echo ======================================================
echo.
pause
